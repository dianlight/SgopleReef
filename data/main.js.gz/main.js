/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 13);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

/* MIT https://github.com/kenwheeler/cash */
(function(){
"use strict";

var propMap = {
  /* GENERAL */
  "class": 'className',
  contenteditable: 'contentEditable',

  /* LABEL */
  "for": 'htmlFor',

  /* INPUT */
  readonly: 'readOnly',
  maxlength: 'maxLength',
  tabindex: 'tabIndex',

  /* TABLE */
  colspan: 'colSpan',
  rowspan: 'rowSpan',

  /* IMAGE */
  usemap: 'useMap'
};

function attempt(fn, arg) {
  try {
    return fn(arg);
  } catch (_a) {
    return arg;
  }
}

var doc = document,
    win = window,
    docEle = doc.documentElement,
    createElement = doc.createElement.bind(doc),
    div = createElement('div'),
    table = createElement('table'),
    tbody = createElement('tbody'),
    tr = createElement('tr'),
    isArray = Array.isArray,
    ArrayPrototype = Array.prototype,
    concat = ArrayPrototype.concat,
    filter = ArrayPrototype.filter,
    indexOf = ArrayPrototype.indexOf,
    map = ArrayPrototype.map,
    push = ArrayPrototype.push,
    slice = ArrayPrototype.slice,
    some = ArrayPrototype.some,
    splice = ArrayPrototype.splice;
var idRe = /^#[\w-]*$/,
    classRe = /^\.[\w-]*$/,
    htmlRe = /<.+>/,
    tagRe = /^\w+$/; // @require ./variables.ts

function find(selector, context) {
  return !selector || !isDocument(context) && !isElement(context) ? [] : classRe.test(selector) ? context.getElementsByClassName(selector.slice(1)) : tagRe.test(selector) ? context.getElementsByTagName(selector) : context.querySelectorAll(selector);
} // @require ./find.ts
// @require ./variables.ts


var Cash =
/** @class */
function () {
  function Cash(selector, context) {
    if (!selector) return;
    if (isCash(selector)) return selector;
    var eles = selector;

    if (isString(selector)) {
      var ctx = (isCash(context) ? context[0] : context) || doc;
      eles = idRe.test(selector) ? ctx.getElementById(selector.slice(1)) : htmlRe.test(selector) ? parseHTML(selector) : find(selector, ctx);
      if (!eles) return;
    } else if (isFunction(selector)) {
      return this.ready(selector); //FIXME: `fn.ready` is not included in `core`, but it's actually a core functionality
    }

    if (eles.nodeType || eles === win) eles = [eles];
    this.length = eles.length;

    for (var i = 0, l = this.length; i < l; i++) {
      this[i] = eles[i];
    }
  }

  Cash.prototype.init = function (selector, context) {
    return new Cash(selector, context);
  };

  return Cash;
}();

var fn = Cash.prototype,
    cash = fn.init;
cash.fn = cash.prototype = fn; // Ensuring that `cash () instanceof cash`

fn.length = 0;
fn.splice = splice; // Ensuring a cash collection gets printed as array-like in Chrome's devtools

if (typeof Symbol === 'function') {
  // Ensuring a cash collection is iterable
  fn[Symbol['iterator']] = ArrayPrototype[Symbol['iterator']];
}

fn.map = function (callback) {
  return cash(concat.apply([], map.call(this, function (ele, i) {
    return callback.call(ele, i, ele);
  })));
};

fn.slice = function (start, end) {
  return cash(slice.call(this, start, end));
}; // @require ./cash.ts


var dashAlphaRe = /-([a-z])/g;

function camelCase(str) {
  return str.replace(dashAlphaRe, function (match, letter) {
    return letter.toUpperCase();
  });
}

function each(arr, callback, _reverse) {
  if (_reverse) {
    var i = arr.length;

    while (i--) {
      if (callback.call(arr[i], i, arr[i]) === false) return arr;
    }
  } else {
    for (var i = 0, l = arr.length; i < l; i++) {
      if (callback.call(arr[i], i, arr[i]) === false) return arr;
    }
  }

  return arr;
}

cash.each = each;

fn.each = function (callback) {
  return each(this, callback);
};

fn.removeProp = function (prop) {
  return this.each(function (i, ele) {
    delete ele[propMap[prop] || prop];
  });
};

function extend(target) {
  var objs = [];

  for (var _i = 1; _i < arguments.length; _i++) {
    objs[_i - 1] = arguments[_i];
  }

  var length = arguments.length;
  if (!length) return {};
  if (length === 1) return extend(cash, target);

  for (var i = 1; i < length; i++) {
    for (var key in arguments[i]) {
      target[key] = arguments[i][key];
    }
  }

  return target;
}

cash.extend = extend;

fn.extend = function (plugins) {
  return extend(fn, plugins);
};

cash.guid = 1; // @require ./cash.ts

function matches(ele, selector) {
  var matches = ele && (ele['matches'] || ele['webkitMatchesSelector'] || ele['msMatchesSelector']);
  return !!matches && !!selector && matches.call(ele, selector);
}

function isCash(x) {
  return x instanceof Cash;
}

function isWindow(x) {
  return !!x && x === x.window;
}

function isDocument(x) {
  return !!x && x.nodeType === 9;
}

function isElement(x) {
  return !!x && x.nodeType === 1;
}

function isFunction(x) {
  return typeof x === 'function';
}

function isString(x) {
  return typeof x === 'string';
}

function isUndefined(x) {
  return x === undefined;
}

function isNull(x) {
  return x === null;
}

function isNumeric(x) {
  return !isNaN(parseFloat(x)) && isFinite(x);
}

cash.isWindow = isWindow;
cash.isFunction = isFunction;
cash.isNumeric = isNumeric;
cash.isArray = isArray;

fn.prop = function (prop, value) {
  if (!prop) return;

  if (isString(prop)) {
    prop = propMap[prop] || prop;
    if (arguments.length < 2) return this[0] && this[0][prop];
    return this.each(function (i, ele) {
      ele[prop] = value;
    });
  }

  for (var key in prop) {
    this.prop(key, prop[key]);
  }

  return this;
};

fn.get = function (index) {
  if (isUndefined(index)) return slice.call(this);
  index = Number(index);
  return this[index < 0 ? index + this.length : index];
};

fn.eq = function (index) {
  return cash(this.get(index));
};

fn.first = function () {
  return this.eq(0);
};

fn.last = function () {
  return this.eq(-1);
}; // @require ./matches.ts
// @require ./type_checking.ts


function getCompareFunction(comparator) {
  return isString(comparator) ? function (i, ele) {
    return matches(ele, comparator);
  } : isFunction(comparator) ? comparator : isCash(comparator) ? function (i, ele) {
    return comparator.is(ele);
  } : !comparator ? function () {
    return false;
  } : function (i, ele) {
    return ele === comparator;
  };
}

fn.filter = function (comparator) {
  var compare = getCompareFunction(comparator);
  return cash(filter.call(this, function (ele, i) {
    return compare.call(ele, i, ele);
  }));
}; // @require collection/filter.ts


function filtered(collection, comparator) {
  return !comparator ? collection : collection.filter(comparator);
} // @require ./type_checking.ts


var splitValuesRe = /\S+/g;

function getSplitValues(str) {
  return isString(str) ? str.match(splitValuesRe) || [] : [];
}

fn.hasClass = function (cls) {
  return !!cls && some.call(this, function (ele) {
    return isElement(ele) && ele.classList.contains(cls);
  });
};

fn.removeAttr = function (attr) {
  var attrs = getSplitValues(attr);
  return this.each(function (i, ele) {
    if (!isElement(ele)) return;
    each(attrs, function (i, a) {
      ele.removeAttribute(a);
    });
  });
};

function attr(attr, value) {
  if (!attr) return;

  if (isString(attr)) {
    if (arguments.length < 2) {
      if (!this[0] || !isElement(this[0])) return;
      var value_1 = this[0].getAttribute(attr);
      return isNull(value_1) ? undefined : value_1;
    }

    if (isUndefined(value)) return this;
    if (isNull(value)) return this.removeAttr(attr);
    return this.each(function (i, ele) {
      if (!isElement(ele)) return;
      ele.setAttribute(attr, value);
    });
  }

  for (var key in attr) {
    this.attr(key, attr[key]);
  }

  return this;
}

fn.attr = attr;

fn.toggleClass = function (cls, force) {
  var classes = getSplitValues(cls),
      isForce = !isUndefined(force);
  return this.each(function (i, ele) {
    if (!isElement(ele)) return;
    each(classes, function (i, c) {
      if (isForce) {
        force ? ele.classList.add(c) : ele.classList.remove(c);
      } else {
        ele.classList.toggle(c);
      }
    });
  });
};

fn.addClass = function (cls) {
  return this.toggleClass(cls, true);
};

fn.removeClass = function (cls) {
  if (arguments.length) return this.toggleClass(cls, false);
  return this.attr('class', '');
};

function pluck(arr, prop, deep, until) {
  var plucked = [],
      isCallback = isFunction(prop),
      compare = until && getCompareFunction(until);

  for (var i = 0, l = arr.length; i < l; i++) {
    if (isCallback) {
      var val_1 = prop(arr[i]);
      if (val_1.length) push.apply(plucked, val_1);
    } else {
      var val_2 = arr[i][prop];

      while (val_2 != null) {
        if (until && compare(-1, val_2)) break;
        plucked.push(val_2);
        val_2 = deep ? val_2[prop] : null;
      }
    }
  }

  return plucked;
}

function unique(arr) {
  return arr.length > 1 ? filter.call(arr, function (item, index, self) {
    return indexOf.call(self, item) === index;
  }) : arr;
}

cash.unique = unique;

fn.add = function (selector, context) {
  return cash(unique(this.get().concat(cash(selector, context).get())));
}; // @require core/type_checking.ts
// @require core/variables.ts


function computeStyle(ele, prop, isVariable) {
  if (!isElement(ele)) return;
  var style = win.getComputedStyle(ele, null);
  return isVariable ? style.getPropertyValue(prop) || undefined : style[prop];
} // @require ./compute_style.ts


function computeStyleInt(ele, prop) {
  return parseInt(computeStyle(ele, prop), 10) || 0;
}

var cssVariableRe = /^--/; // @require ./variables.ts

function isCSSVariable(prop) {
  return cssVariableRe.test(prop);
} // @require core/camel_case.ts
// @require core/cash.ts
// @require core/each.ts
// @require core/variables.ts
// @require ./is_css_variable.ts


var prefixedProps = {},
    style = div.style,
    vendorsPrefixes = ['webkit', 'moz', 'ms'];

function getPrefixedProp(prop, isVariable) {
  if (isVariable === void 0) {
    isVariable = isCSSVariable(prop);
  }

  if (isVariable) return prop;

  if (!prefixedProps[prop]) {
    var propCC = camelCase(prop),
        propUC = "" + propCC[0].toUpperCase() + propCC.slice(1),
        props = (propCC + " " + vendorsPrefixes.join(propUC + " ") + propUC).split(' ');
    each(props, function (i, p) {
      if (p in style) {
        prefixedProps[prop] = p;
        return false;
      }
    });
  }

  return prefixedProps[prop];
}

; // @require core/type_checking.ts
// @require ./is_css_variable.ts

var numericProps = {
  animationIterationCount: true,
  columnCount: true,
  flexGrow: true,
  flexShrink: true,
  fontWeight: true,
  gridArea: true,
  gridColumn: true,
  gridColumnEnd: true,
  gridColumnStart: true,
  gridRow: true,
  gridRowEnd: true,
  gridRowStart: true,
  lineHeight: true,
  opacity: true,
  order: true,
  orphans: true,
  widows: true,
  zIndex: true
};

function getSuffixedValue(prop, value, isVariable) {
  if (isVariable === void 0) {
    isVariable = isCSSVariable(prop);
  }

  return !isVariable && !numericProps[prop] && isNumeric(value) ? value + "px" : value;
}

function css(prop, value) {
  if (isString(prop)) {
    var isVariable_1 = isCSSVariable(prop);
    prop = getPrefixedProp(prop, isVariable_1);
    if (arguments.length < 2) return this[0] && computeStyle(this[0], prop, isVariable_1);
    if (!prop) return this;
    value = getSuffixedValue(prop, value, isVariable_1);
    return this.each(function (i, ele) {
      if (!isElement(ele)) return;

      if (isVariable_1) {
        ele.style.setProperty(prop, value);
      } else {
        ele.style[prop] = value;
      }
    });
  }

  for (var key in prop) {
    this.css(key, prop[key]);
  }

  return this;
}

;
fn.css = css; // @optional ./css.ts
// @require core/attempt.ts
// @require core/camel_case.ts

var JSONStringRe = /^\s+|\s+$/;

function getData(ele, key) {
  var value = ele.dataset[key] || ele.dataset[camelCase(key)];
  if (JSONStringRe.test(value)) return value;
  return attempt(JSON.parse, value);
} // @require core/attempt.ts
// @require core/camel_case.ts


function setData(ele, key, value) {
  value = attempt(JSON.stringify, value);
  ele.dataset[camelCase(key)] = value;
}

function data(name, value) {
  if (!name) {
    if (!this[0]) return;
    var datas = {};

    for (var key in this[0].dataset) {
      datas[key] = getData(this[0], key);
    }

    return datas;
  }

  if (isString(name)) {
    if (arguments.length < 2) return this[0] && getData(this[0], name);
    if (isUndefined(value)) return this;
    return this.each(function (i, ele) {
      setData(ele, name, value);
    });
  }

  for (var key in name) {
    this.data(key, name[key]);
  }

  return this;
}

fn.data = data; // @optional ./data.ts

function getDocumentDimension(doc, dimension) {
  var docEle = doc.documentElement;
  return Math.max(doc.body["scroll" + dimension], docEle["scroll" + dimension], doc.body["offset" + dimension], docEle["offset" + dimension], docEle["client" + dimension]);
} // @require css/helpers/compute_style_int.ts


function getExtraSpace(ele, xAxis) {
  return computeStyleInt(ele, "border" + (xAxis ? 'Left' : 'Top') + "Width") + computeStyleInt(ele, "padding" + (xAxis ? 'Left' : 'Top')) + computeStyleInt(ele, "padding" + (xAxis ? 'Right' : 'Bottom')) + computeStyleInt(ele, "border" + (xAxis ? 'Right' : 'Bottom') + "Width");
}

each([true, false], function (i, outer) {
  each(['Width', 'Height'], function (i, prop) {
    var name = "" + (outer ? 'outer' : 'inner') + prop;

    fn[name] = function (includeMargins) {
      if (!this[0]) return;
      if (isWindow(this[0])) return outer ? this[0]["inner" + prop] : this[0].document.documentElement["client" + prop];
      if (isDocument(this[0])) return getDocumentDimension(this[0], prop);
      return this[0]["" + (outer ? 'offset' : 'client') + prop] + (includeMargins && outer ? computeStyleInt(this[0], "margin" + (i ? 'Top' : 'Left')) + computeStyleInt(this[0], "margin" + (i ? 'Bottom' : 'Right')) : 0);
    };
  });
});
each(['Width', 'Height'], function (index, prop) {
  var propLC = prop.toLowerCase();

  fn[propLC] = function (value) {
    if (!this[0]) return isUndefined(value) ? undefined : this;

    if (!arguments.length) {
      if (isWindow(this[0])) return this[0].document.documentElement["client" + prop];
      if (isDocument(this[0])) return getDocumentDimension(this[0], prop);
      return this[0].getBoundingClientRect()[propLC] - getExtraSpace(this[0], !index);
    }

    var valueNumber = parseInt(value, 10);
    return this.each(function (i, ele) {
      if (!isElement(ele)) return;
      var boxSizing = computeStyle(ele, 'boxSizing');
      ele.style[propLC] = getSuffixedValue(propLC, valueNumber + (boxSizing === 'border-box' ? getExtraSpace(ele, !index) : 0));
    });
  };
}); // @optional ./inner_outer.ts
// @optional ./normal.ts
// @require css/helpers/compute_style.ts

var defaultDisplay = {};

function getDefaultDisplay(tagName) {
  if (defaultDisplay[tagName]) return defaultDisplay[tagName];
  var ele = createElement(tagName);
  doc.body.insertBefore(ele, null);
  var display = computeStyle(ele, 'display');
  doc.body.removeChild(ele);
  return defaultDisplay[tagName] = display !== 'none' ? display : 'block';
} // @require css/helpers/compute_style.ts


function isHidden(ele) {
  return computeStyle(ele, 'display') === 'none';
}

var displayProperty = '___cd';

fn.toggle = function (force) {
  return this.each(function (i, ele) {
    if (!isElement(ele)) return;
    var show = isUndefined(force) ? isHidden(ele) : force;

    if (show) {
      ele.style.display = ele[displayProperty] || '';

      if (isHidden(ele)) {
        ele.style.display = getDefaultDisplay(ele.tagName);
      }
    } else {
      ele[displayProperty] = computeStyle(ele, 'display');
      ele.style.display = 'none';
    }
  });
};

fn.hide = function () {
  return this.toggle(false);
};

fn.show = function () {
  return this.toggle(true);
}; // @optional ./hide.ts
// @optional ./show.ts
// @optional ./toggle.ts


function hasNamespaces(ns1, ns2) {
  return !ns2 || !some.call(ns2, function (ns) {
    return ns1.indexOf(ns) < 0;
  });
}

var eventsNamespace = '___ce',
    eventsNamespacesSeparator = '.',
    eventsFocus = {
  focus: 'focusin',
  blur: 'focusout'
},
    eventsHover = {
  mouseenter: 'mouseover',
  mouseleave: 'mouseout'
},
    eventsMouseRe = /^(mouse|pointer|contextmenu|drag|drop|click|dblclick)/i; // @require ./variables.ts

function getEventNameBubbling(name) {
  return eventsHover[name] || eventsFocus[name] || name;
} // @require ./variables.ts


function getEventsCache(ele) {
  return ele[eventsNamespace] = ele[eventsNamespace] || {};
} // @require core/guid.ts
// @require events/helpers/get_events_cache.ts


function addEvent(ele, name, namespaces, selector, callback) {
  var eventCache = getEventsCache(ele);
  eventCache[name] = eventCache[name] || [];
  eventCache[name].push([namespaces, selector, callback]);
  ele.addEventListener(name, callback);
} // @require ./variables.ts


function parseEventName(eventName) {
  var parts = eventName.split(eventsNamespacesSeparator);
  return [parts[0], parts.slice(1).sort()]; // [name, namespace[]]
} // @require ./get_events_cache.ts
// @require ./has_namespaces.ts
// @require ./parse_event_name.ts


function removeEvent(ele, name, namespaces, selector, callback) {
  var cache = getEventsCache(ele);

  if (!name) {
    for (name in cache) {
      removeEvent(ele, name, namespaces, selector, callback);
    }
  } else if (cache[name]) {
    cache[name] = cache[name].filter(function (_a) {
      var ns = _a[0],
          sel = _a[1],
          cb = _a[2];
      if (callback && cb.guid !== callback.guid || !hasNamespaces(ns, namespaces) || selector && selector !== sel) return true;
      ele.removeEventListener(name, cb);
    });
  }
}

fn.off = function (eventFullName, selector, callback) {
  var _this = this;

  if (isUndefined(eventFullName)) {
    this.each(function (i, ele) {
      if (!isElement(ele) && !isDocument(ele) && !isWindow(ele)) return;
      removeEvent(ele);
    });
  } else if (!isString(eventFullName)) {
    for (var key in eventFullName) {
      this.off(key, eventFullName[key]);
    }
  } else {
    if (isFunction(selector)) {
      callback = selector;
      selector = '';
    }

    each(getSplitValues(eventFullName), function (i, eventFullName) {
      var _a = parseEventName(getEventNameBubbling(eventFullName)),
          name = _a[0],
          namespaces = _a[1];

      _this.each(function (i, ele) {
        if (!isElement(ele) && !isDocument(ele) && !isWindow(ele)) return;
        removeEvent(ele, name, namespaces, selector, callback);
      });
    });
  }

  return this;
};

function on(eventFullName, selector, data, callback, _one) {
  var _this = this;

  if (!isString(eventFullName)) {
    for (var key in eventFullName) {
      this.on(key, selector, data, eventFullName[key], _one);
    }

    return this;
  }

  if (!isString(selector)) {
    if (isUndefined(selector) || isNull(selector)) {
      selector = '';
    } else if (isUndefined(data)) {
      data = selector;
      selector = '';
    } else {
      callback = data;
      data = selector;
      selector = '';
    }
  }

  if (!isFunction(callback)) {
    callback = data;
    data = undefined;
  }

  if (!callback) return this;
  each(getSplitValues(eventFullName), function (i, eventFullName) {
    var _a = parseEventName(getEventNameBubbling(eventFullName)),
        name = _a[0],
        namespaces = _a[1];

    if (!name) return;

    _this.each(function (i, ele) {
      if (!isElement(ele) && !isDocument(ele) && !isWindow(ele)) return;

      var finalCallback = function finalCallback(event) {
        if (event.namespace && !hasNamespaces(namespaces, event.namespace.split(eventsNamespacesSeparator))) return;
        var thisArg = ele;

        if (selector) {
          var target = event.target;

          while (!matches(target, selector)) {
            if (target === ele) return;
            target = target.parentNode;
            if (!target) return;
          }

          thisArg = target;
          event.___cd = true; // Delegate
        }

        if (event.___cd) {
          Object.defineProperty(event, 'currentTarget', {
            configurable: true,
            get: function get() {
              return thisArg;
            }
          });
        }

        Object.defineProperty(event, 'data', {
          configurable: true,
          get: function get() {
            return data;
          }
        });
        var returnValue = callback.call(thisArg, event, event.___td);

        if (_one) {
          removeEvent(ele, name, namespaces, selector, finalCallback);
        }

        if (returnValue === false) {
          event.preventDefault();
          event.stopPropagation();
        }
      };

      finalCallback.guid = callback.guid = callback.guid || cash.guid++;
      addEvent(ele, name, namespaces, selector, finalCallback);
    });
  });
  return this;
}

fn.on = on;

function one(eventFullName, selector, data, callback) {
  return this.on(eventFullName, selector, data, callback, true);
}

;
fn.one = one;

fn.ready = function (callback) {
  var cb = function cb() {
    return setTimeout(callback, 0, cash);
  };

  if (doc.readyState !== 'loading') {
    cb();
  } else {
    doc.addEventListener('DOMContentLoaded', cb);
  }

  return this;
};

fn.trigger = function (event, data) {
  if (isString(event)) {
    var _a = parseEventName(event),
        name_1 = _a[0],
        namespaces = _a[1];

    if (!name_1) return this;
    var type = eventsMouseRe.test(name_1) ? 'MouseEvents' : 'HTMLEvents';
    event = doc.createEvent(type);
    event.initEvent(name_1, true, true);
    event.namespace = namespaces.join(eventsNamespacesSeparator);
  }

  event.___td = data;
  var isEventFocus = event.type in eventsFocus;
  return this.each(function (i, ele) {
    if (isEventFocus && isFunction(ele[event.type])) {
      ele[event.type]();
    } else {
      ele.dispatchEvent(event);
    }
  });
}; // @optional ./off.ts
// @optional ./on.ts
// @optional ./one.ts
// @optional ./ready.ts
// @optional ./trigger.ts
// @require core/pluck.ts
// @require core/variables.ts


function getValue(ele) {
  if (ele.multiple && ele.options) return pluck(filter.call(ele.options, function (option) {
    return option.selected && !option.disabled && !option.parentNode.disabled;
  }), 'value');
  return ele.value || '';
}

var queryEncodeSpaceRe = /%20/g,
    queryEncodeCRLFRe = /\r?\n/g;

function queryEncode(prop, value) {
  return "&" + encodeURIComponent(prop) + "=" + encodeURIComponent(value.replace(queryEncodeCRLFRe, '\r\n')).replace(queryEncodeSpaceRe, '+');
}

var skippableRe = /file|reset|submit|button|image/i,
    checkableRe = /radio|checkbox/i;

fn.serialize = function () {
  var query = '';
  this.each(function (i, ele) {
    each(ele.elements || [ele], function (i, ele) {
      if (ele.disabled || !ele.name || ele.tagName === 'FIELDSET' || skippableRe.test(ele.type) || checkableRe.test(ele.type) && !ele.checked) return;
      var value = getValue(ele);

      if (!isUndefined(value)) {
        var values = isArray(value) ? value : [value];
        each(values, function (i, value) {
          query += queryEncode(ele.name, value);
        });
      }
    });
  });
  return query.slice(1);
};

function val(value) {
  if (!arguments.length) return this[0] && getValue(this[0]);
  return this.each(function (i, ele) {
    var isSelect = ele.multiple && ele.options;

    if (isSelect || checkableRe.test(ele.type)) {
      var eleValue_1 = isArray(value) ? map.call(value, String) : isNull(value) ? [] : [String(value)];

      if (isSelect) {
        each(ele.options, function (i, option) {
          option.selected = eleValue_1.indexOf(option.value) >= 0;
        }, true);
      } else {
        ele.checked = eleValue_1.indexOf(ele.value) >= 0;
      }
    } else {
      ele.value = isUndefined(value) || isNull(value) ? '' : value;
    }
  });
}

fn.val = val;

fn.clone = function () {
  return this.map(function (i, ele) {
    return ele.cloneNode(true);
  });
};

fn.detach = function (comparator) {
  filtered(this, comparator).each(function (i, ele) {
    if (ele.parentNode) {
      ele.parentNode.removeChild(ele);
    }
  });
  return this;
};

var fragmentRe = /^\s*<(\w+)[^>]*>/,
    singleTagRe = /^<(\w+)\s*\/?>(?:<\/\1>)?$/;
var containers = {
  '*': div,
  tr: tbody,
  td: tr,
  th: tr,
  thead: table,
  tbody: table,
  tfoot: table
}; //TODO: Create elements inside a document fragment, in order to prevent inline event handlers from firing
//TODO: Ensure the created elements have the fragment as their parent instead of null, this also ensures we can deal with detatched nodes more reliably

function parseHTML(html) {
  if (!isString(html)) return [];
  if (singleTagRe.test(html)) return [createElement(RegExp.$1)];
  var fragment = fragmentRe.test(html) && RegExp.$1,
      container = containers[fragment] || containers['*'];
  container.innerHTML = html;
  return cash(container.childNodes).detach().get();
}

cash.parseHTML = parseHTML;

fn.empty = function () {
  return this.each(function (i, ele) {
    while (ele.firstChild) {
      ele.removeChild(ele.firstChild);
    }
  });
};

function html(html) {
  if (!arguments.length) return this[0] && this[0].innerHTML;
  if (isUndefined(html)) return this;
  return this.each(function (i, ele) {
    if (!isElement(ele)) return;
    ele.innerHTML = html;
  });
}

fn.html = html;

fn.remove = function (comparator) {
  filtered(this, comparator).detach().off();
  return this;
};

function text(text) {
  if (isUndefined(text)) return this[0] ? this[0].textContent : '';
  return this.each(function (i, ele) {
    if (!isElement(ele)) return;
    ele.textContent = text;
  });
}

;
fn.text = text;

fn.unwrap = function () {
  this.parent().each(function (i, ele) {
    if (ele.tagName === 'BODY') return;
    var $ele = cash(ele);
    $ele.replaceWith($ele.children());
  });
  return this;
};

fn.offset = function () {
  var ele = this[0];
  if (!ele) return;
  var rect = ele.getBoundingClientRect();
  return {
    top: rect.top + win.pageYOffset,
    left: rect.left + win.pageXOffset
  };
};

fn.offsetParent = function () {
  return this.map(function (i, ele) {
    var offsetParent = ele.offsetParent;

    while (offsetParent && computeStyle(offsetParent, 'position') === 'static') {
      offsetParent = offsetParent.offsetParent;
    }

    return offsetParent || docEle;
  });
};

fn.position = function () {
  var ele = this[0];
  if (!ele) return;
  var isFixed = computeStyle(ele, 'position') === 'fixed',
      offset = isFixed ? ele.getBoundingClientRect() : this.offset();

  if (!isFixed) {
    var doc_1 = ele.ownerDocument;
    var offsetParent = ele.offsetParent || doc_1.documentElement;

    while ((offsetParent === doc_1.body || offsetParent === doc_1.documentElement) && computeStyle(offsetParent, 'position') === 'static') {
      offsetParent = offsetParent.parentNode;
    }

    if (offsetParent !== ele && isElement(offsetParent)) {
      var parentOffset = cash(offsetParent).offset();
      offset.top -= parentOffset.top + computeStyleInt(offsetParent, 'borderTopWidth');
      offset.left -= parentOffset.left + computeStyleInt(offsetParent, 'borderLeftWidth');
    }
  }

  return {
    top: offset.top - computeStyleInt(ele, 'marginTop'),
    left: offset.left - computeStyleInt(ele, 'marginLeft')
  };
};

fn.children = function (comparator) {
  return filtered(cash(unique(pluck(this, function (ele) {
    return ele.children;
  }))), comparator);
};

fn.contents = function () {
  return cash(unique(pluck(this, function (ele) {
    return ele.tagName === 'IFRAME' ? [ele.contentDocument] : ele.tagName === 'TEMPLATE' ? ele.content.childNodes : ele.childNodes;
  })));
};

fn.find = function (selector) {
  return cash(unique(pluck(this, function (ele) {
    return find(selector, ele);
  })));
}; // @require core/variables.ts
// @require collection/filter.ts
// @require traversal/find.ts


var HTMLCDATARe = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
    scriptTypeRe = /^$|^module$|\/(java|ecma)script/i,
    scriptAttributes = ['type', 'src', 'nonce', 'noModule'];

function evalScripts(node, doc) {
  var collection = cash(node);
  collection.filter('script').add(collection.find('script')).each(function (i, ele) {
    if (scriptTypeRe.test(ele.type) && docEle.contains(ele)) {
      // The script type is supported // The element is attached to the DOM // Using `documentElement` for broader browser support
      var script_1 = createElement('script');
      script_1.text = ele.textContent.replace(HTMLCDATARe, '');
      each(scriptAttributes, function (i, attr) {
        if (ele[attr]) script_1[attr] = ele[attr];
      });
      doc.head.insertBefore(script_1, null);
      doc.head.removeChild(script_1);
    }
  });
} // @require ./eval_scripts.ts


function insertElement(anchor, target, left, inside, evaluate) {
  if (inside) {
    // prepend/append
    anchor.insertBefore(target, left ? anchor.firstChild : null);
  } else {
    // before/after
    anchor.parentNode.insertBefore(target, left ? anchor : anchor.nextSibling);
  }

  if (evaluate) {
    evalScripts(target, anchor.ownerDocument);
  }
} // @require ./insert_element.ts


function insertSelectors(selectors, anchors, inverse, left, inside, reverseLoop1, reverseLoop2, reverseLoop3) {
  each(selectors, function (si, selector) {
    each(cash(selector), function (ti, target) {
      each(cash(anchors), function (ai, anchor) {
        var anchorFinal = inverse ? target : anchor,
            targetFinal = inverse ? anchor : target,
            indexFinal = inverse ? ti : ai;
        insertElement(anchorFinal, !indexFinal ? targetFinal : targetFinal.cloneNode(true), left, inside, !indexFinal);
      }, reverseLoop3);
    }, reverseLoop2);
  }, reverseLoop1);
  return anchors;
}

fn.after = function () {
  return insertSelectors(arguments, this, false, false, false, true, true);
};

fn.append = function () {
  return insertSelectors(arguments, this, false, false, true);
};

fn.appendTo = function (selector) {
  return insertSelectors(arguments, this, true, false, true);
};

fn.before = function () {
  return insertSelectors(arguments, this, false, true);
};

fn.insertAfter = function (selector) {
  return insertSelectors(arguments, this, true, false, false, false, false, true);
};

fn.insertBefore = function (selector) {
  return insertSelectors(arguments, this, true, true);
};

fn.prepend = function () {
  return insertSelectors(arguments, this, false, true, true, true, true);
};

fn.prependTo = function (selector) {
  return insertSelectors(arguments, this, true, true, true, false, false, true);
};

fn.replaceWith = function (selector) {
  return this.before(selector).remove();
};

fn.replaceAll = function (selector) {
  cash(selector).replaceWith(this);
  return this;
};

fn.wrapAll = function (selector) {
  var structure = cash(selector),
      wrapper = structure[0];

  while (wrapper.children.length) {
    wrapper = wrapper.firstElementChild;
  }

  this.first().before(structure);
  return this.appendTo(wrapper);
};

fn.wrap = function (selector) {
  return this.each(function (i, ele) {
    var wrapper = cash(selector)[0];
    cash(ele).wrapAll(!i ? wrapper : wrapper.cloneNode(true));
  });
};

fn.wrapInner = function (selector) {
  return this.each(function (i, ele) {
    var $ele = cash(ele),
        contents = $ele.contents();
    contents.length ? contents.wrapAll(selector) : $ele.append(selector);
  });
};

fn.has = function (selector) {
  var comparator = isString(selector) ? function (i, ele) {
    return find(selector, ele).length;
  } : function (i, ele) {
    return ele.contains(selector);
  };
  return this.filter(comparator);
};

fn.is = function (comparator) {
  var compare = getCompareFunction(comparator);
  return some.call(this, function (ele, i) {
    return compare.call(ele, i, ele);
  });
};

fn.next = function (comparator, _all, _until) {
  return filtered(cash(unique(pluck(this, 'nextElementSibling', _all, _until))), comparator);
};

fn.nextAll = function (comparator) {
  return this.next(comparator, true);
};

fn.nextUntil = function (until, comparator) {
  return this.next(comparator, true, until);
};

fn.not = function (comparator) {
  var compare = getCompareFunction(comparator);
  return this.filter(function (i, ele) {
    return (!isString(comparator) || isElement(ele)) && !compare.call(ele, i, ele);
  });
};

fn.parent = function (comparator) {
  return filtered(cash(unique(pluck(this, 'parentNode'))), comparator);
};

fn.index = function (selector) {
  var child = selector ? cash(selector)[0] : this[0],
      collection = selector ? this : cash(child).parent().children();
  return indexOf.call(collection, child);
};

fn.closest = function (comparator) {
  var filtered = this.filter(comparator);
  if (filtered.length) return filtered;
  var $parent = this.parent();
  if (!$parent.length) return filtered;
  return $parent.closest(comparator);
};

fn.parents = function (comparator, _until) {
  return filtered(cash(unique(pluck(this, 'parentElement', true, _until))), comparator);
};

fn.parentsUntil = function (until, comparator) {
  return this.parents(comparator, until);
};

fn.prev = function (comparator, _all, _until) {
  return filtered(cash(unique(pluck(this, 'previousElementSibling', _all, _until))), comparator);
};

fn.prevAll = function (comparator) {
  return this.prev(comparator, true);
};

fn.prevUntil = function (until, comparator) {
  return this.prev(comparator, true, until);
};

fn.siblings = function (comparator) {
  return filtered(cash(unique(pluck(this, function (ele) {
    return cash(ele).parent().children().not(ele);
  }))), comparator);
}; // @optional ./children.ts
// @optional ./closest.ts
// @optional ./contents.ts
// @optional ./find.ts
// @optional ./has.ts
// @optional ./is.ts
// @optional ./next.ts
// @optional ./next_all.ts
// @optional ./next_until.ts
// @optional ./not.ts
// @optional ./parent.ts
// @optional ./parents.ts
// @optional ./parents_until.ts
// @optional ./prev.ts
// @optional ./prev_all.ts
// @optional ./prev_until.ts
// @optional ./siblings.ts
// @optional attributes/index.ts
// @optional collection/index.ts
// @optional css/index.ts
// @optional data/index.ts
// @optional dimensions/index.ts
// @optional effects/index.ts
// @optional events/index.ts
// @optional forms/index.ts
// @optional manipulation/index.ts
// @optional offset/index.ts
// @optional traversal/index.ts
// @require core/index.ts
// @priority -100
// @require ./cash.ts
// @require ./variables.ts


if (true) {
  // Node.js
  module.exports = cash;
} else {}
})();

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var isOldIE = function isOldIE() {
  var memo;
  return function memorize() {
    if (typeof memo === 'undefined') {
      // Test for IE <= 9 as proposed by Browserhacks
      // @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
      // Tests for existence of standard globals is to allow style-loader
      // to operate correctly into non-standard environments
      // @see https://github.com/webpack-contrib/style-loader/issues/177
      memo = Boolean(window && document && document.all && !window.atob);
    }

    return memo;
  };
}();

var getTarget = function getTarget() {
  var memo = {};
  return function memorize(target) {
    if (typeof memo[target] === 'undefined') {
      var styleTarget = document.querySelector(target); // Special case to return head of iframe instead of iframe itself

      if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
        try {
          // This will throw an exception if access to iframe is blocked
          // due to cross-origin restrictions
          styleTarget = styleTarget.contentDocument.head;
        } catch (e) {
          // istanbul ignore next
          styleTarget = null;
        }
      }

      memo[target] = styleTarget;
    }

    return memo[target];
  };
}();

var stylesInDom = [];

function getIndexByIdentifier(identifier) {
  var result = -1;

  for (var i = 0; i < stylesInDom.length; i++) {
    if (stylesInDom[i].identifier === identifier) {
      result = i;
      break;
    }
  }

  return result;
}

function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];

  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var index = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3]
    };

    if (index !== -1) {
      stylesInDom[index].references++;
      stylesInDom[index].updater(obj);
    } else {
      stylesInDom.push({
        identifier: identifier,
        updater: addStyle(obj, options),
        references: 1
      });
    }

    identifiers.push(identifier);
  }

  return identifiers;
}

function insertStyleElement(options) {
  var style = document.createElement('style');
  var attributes = options.attributes || {};

  if (typeof attributes.nonce === 'undefined') {
    var nonce =  true ? __webpack_require__.nc : undefined;

    if (nonce) {
      attributes.nonce = nonce;
    }
  }

  Object.keys(attributes).forEach(function (key) {
    style.setAttribute(key, attributes[key]);
  });

  if (typeof options.insert === 'function') {
    options.insert(style);
  } else {
    var target = getTarget(options.insert || 'head');

    if (!target) {
      throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
    }

    target.appendChild(style);
  }

  return style;
}

function removeStyleElement(style) {
  // istanbul ignore if
  if (style.parentNode === null) {
    return false;
  }

  style.parentNode.removeChild(style);
}
/* istanbul ignore next  */


var replaceText = function replaceText() {
  var textStore = [];
  return function replace(index, replacement) {
    textStore[index] = replacement;
    return textStore.filter(Boolean).join('\n');
  };
}();

function applyToSingletonTag(style, index, remove, obj) {
  var css = remove ? '' : obj.media ? "@media ".concat(obj.media, " {").concat(obj.css, "}") : obj.css; // For old IE

  /* istanbul ignore if  */

  if (style.styleSheet) {
    style.styleSheet.cssText = replaceText(index, css);
  } else {
    var cssNode = document.createTextNode(css);
    var childNodes = style.childNodes;

    if (childNodes[index]) {
      style.removeChild(childNodes[index]);
    }

    if (childNodes.length) {
      style.insertBefore(cssNode, childNodes[index]);
    } else {
      style.appendChild(cssNode);
    }
  }
}

function applyToTag(style, options, obj) {
  var css = obj.css;
  var media = obj.media;
  var sourceMap = obj.sourceMap;

  if (media) {
    style.setAttribute('media', media);
  } else {
    style.removeAttribute('media');
  }

  if (sourceMap && btoa) {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  } // For old IE

  /* istanbul ignore if  */


  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    while (style.firstChild) {
      style.removeChild(style.firstChild);
    }

    style.appendChild(document.createTextNode(css));
  }
}

var singleton = null;
var singletonCounter = 0;

function addStyle(obj, options) {
  var style;
  var update;
  var remove;

  if (options.singleton) {
    var styleIndex = singletonCounter++;
    style = singleton || (singleton = insertStyleElement(options));
    update = applyToSingletonTag.bind(null, style, styleIndex, false);
    remove = applyToSingletonTag.bind(null, style, styleIndex, true);
  } else {
    style = insertStyleElement(options);
    update = applyToTag.bind(null, style, options);

    remove = function remove() {
      removeStyleElement(style);
    };
  }

  update(obj);
  return function updateStyle(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap) {
        return;
      }

      update(obj = newObj);
    } else {
      remove();
    }
  };
}

module.exports = function (list, options) {
  options = options || {}; // Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
  // tags it will allow on a page

  if (!options.singleton && typeof options.singleton !== 'boolean') {
    options.singleton = isOldIE();
  }

  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];

    if (Object.prototype.toString.call(newList) !== '[object Array]') {
      return;
    }

    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDom[index].references--;
    }

    var newLastIdentifiers = modulesToDom(newList, options);

    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];

      var _index = getIndexByIdentifier(_identifier);

      if (stylesInDom[_index].references === 0) {
        stylesInDom[_index].updater();

        stylesInDom.splice(_index, 1);
      }
    }

    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
// eslint-disable-next-line func-names
module.exports = function (useSourceMap) {
  var list = []; // return the list of modules as css string

  list.toString = function toString() {
    return this.map(function (item) {
      var content = cssWithMappingToString(item, useSourceMap);

      if (item[2]) {
        return "@media ".concat(item[2], " {").concat(content, "}");
      }

      return content;
    }).join('');
  }; // import a list of modules into the list
  // eslint-disable-next-line func-names


  list.i = function (modules, mediaQuery, dedupe) {
    if (typeof modules === 'string') {
      // eslint-disable-next-line no-param-reassign
      modules = [[null, modules, '']];
    }

    var alreadyImportedModules = {};

    if (dedupe) {
      for (var i = 0; i < this.length; i++) {
        // eslint-disable-next-line prefer-destructuring
        var id = this[i][0];

        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }

    for (var _i = 0; _i < modules.length; _i++) {
      var item = [].concat(modules[_i]);

      if (dedupe && alreadyImportedModules[item[0]]) {
        // eslint-disable-next-line no-continue
        continue;
      }

      if (mediaQuery) {
        if (!item[2]) {
          item[2] = mediaQuery;
        } else {
          item[2] = "".concat(mediaQuery, " and ").concat(item[2]);
        }
      }

      list.push(item);
    }
  };

  return list;
};

function cssWithMappingToString(item, useSourceMap) {
  var content = item[1] || ''; // eslint-disable-next-line prefer-destructuring

  var cssMapping = item[3];

  if (!cssMapping) {
    return content;
  }

  if (useSourceMap && typeof btoa === 'function') {
    var sourceMapping = toComment(cssMapping);
    var sourceURLs = cssMapping.sources.map(function (source) {
      return "/*# sourceURL=".concat(cssMapping.sourceRoot || '').concat(source, " */");
    });
    return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
  }

  return [content].join('\n');
} // Adapted from convert-source-map (MIT)


function toComment(sourceMap) {
  // eslint-disable-next-line no-undef
  var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
  var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
  return "/*# ".concat(data, " */");
}

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {


/**
 * Populate form fields from a JSON object.
 *
 * @param form object The form element containing your input fields.
 * @param data array JSON data to populate the fields with.
 * @param basename string Optional basename which is added to `name` attributes
 */
function populate(form, data, basename) {
	for (var key in data) {
		if (! data.hasOwnProperty(key)) {
			continue;
		}

		var name = key;
		var value = data[key];

        if ('undefined' === typeof value) {
            value = '';
        }

        if (null === value) {
            value = '';
        }

		// handle array name attributes
		if (typeof(basename) !== "undefined") {
			name = basename + "[" + key + "]";
		}

		if (value.constructor === Array) {
			name += '[]';
		} else if(typeof value == "object") {
			populate(form, value, name);
			continue;
		}

		// only proceed if element is set
		var element = form.elements.namedItem(name);
		if (! element) {
			continue;
		}

		var type = element.type || element[0].type;

		switch(type ) {
			default:
				element.value = value;
				break;

			case 'radio':
			case 'checkbox':
				for (var j=0; j < element.length; j++) {
					element[j].checked = (String(value) === String(element[j].value));
				}
				break;

			case 'select-multiple':
				var values = value.constructor == Array ? value : [value];

				for(var k = 0; k < element.options.length; k++) {
					element.options[k].selected = (values.indexOf(element.options[k].value) > -1 );
				}
				break;

			case 'select':
			case 'select-one':
				element.value = value.toString() || value;
				break;

			case 'date':
      			element.value = new Date(value).toISOString().split('T')[0];	
				break;
		}

	}
};

if ( true && module.exports) {
	module.exports = populate;
} 

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(1);
            var content = __webpack_require__(5);

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(2);
exports = ___CSS_LOADER_API_IMPORT___(true);
// Module
exports.push([module.i, ":root{--fore-color:#111;--secondary-fore-color:#444;--back-color:#f8f8f8;--secondary-back-color:#f0f0f0;--blockquote-color:#f57c00;--pre-color:#1565c0;--border-color:#aaa;--secondary-border-color:#ddd;--heading-ratio:1.19;--universal-margin:.5rem;--universal-padding:.5rem;--universal-border-radius:.125rem;--a-link-color:#0277bd;--a-visited-color:#01579b}html{font-size:16px}a,b,del,em,i,ins,q,span,strong,u{font-size:1em}html,*{font-family:-apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Ubuntu, \"Helvetica Neue\", Helvetica, sans-serif;line-height:1.5;-webkit-text-size-adjust:100%}*{font-size:1rem}body{margin:0;color:var(--fore-color);background:var(--back-color)}details{display:block}summary{display:list-item}abbr[title]{border-bottom:none;text-decoration:underline dotted}input{overflow:visible}img{max-width:100%;height:auto}h1,h2,h3,h4,h5,h6{line-height:1.2;margin:calc(1.5 * var(--universal-margin)) var(--universal-margin);font-weight:500}h1 small,h2 small,h3 small,h4 small,h5 small,h6 small{color:var(--secondary-fore-color);display:block;margin-top:-.25rem}h1{font-size:calc(1rem * var(--heading-ratio) * var(--heading-ratio) * var(--heading-ratio) * var(--heading-ratio))}h2{font-size:calc(1rem * var(--heading-ratio) * var(--heading-ratio) * var(--heading-ratio))}h3{font-size:calc(1rem * var(--heading-ratio) * var(--heading-ratio))}h4{font-size:calc(1rem * var(--heading-ratio))}h5{font-size:1rem}h6{font-size:calc(1rem / var(--heading-ratio))}p{margin:var(--universal-margin)}ol,ul{margin:var(--universal-margin);padding-left:calc(2 * var(--universal-margin))}b,strong{font-weight:700}hr{box-sizing:content-box;border:0;line-height:1.25em;margin:var(--universal-margin);height:.0625rem;background:linear-gradient(to right, transparent, var(--border-color) 20%, var(--border-color) 80%, transparent)}blockquote{display:block;position:relative;font-style:italic;color:var(--secondary-fore-color);margin:var(--universal-margin);padding:calc(3 * var(--universal-padding));border:.0625rem solid var(--secondary-border-color);border-left:.375rem solid var(--blockquote-color);border-radius:0 var(--universal-border-radius) var(--universal-border-radius) 0}blockquote:before{position:absolute;top:calc(0rem - var(--universal-padding));left:0;font-family:sans-serif;font-size:3rem;font-weight:700;content:\"\\201c\";color:var(--blockquote-color)}blockquote[cite]:after{font-style:normal;font-size:.75em;font-weight:700;content:\"\\a—  \" attr(cite);white-space:pre}code,kbd,pre,samp{font-family:Menlo, Consolas, monospace;font-size:.85em}code{background:var(--secondary-back-color);border-radius:var(--universal-border-radius);padding:calc(var(--universal-padding) / 4) calc(var(--universal-padding) / 2)}kbd{background:var(--fore-color);color:var(--back-color);border-radius:var(--universal-border-radius);padding:calc(var(--universal-padding) / 4) calc(var(--universal-padding) / 2)}pre{overflow:auto;background:var(--secondary-back-color);padding:calc(1.5 * var(--universal-padding));margin:var(--universal-margin);border:.0625rem solid var(--secondary-border-color);border-left:.25rem solid var(--pre-color);border-radius:0 var(--universal-border-radius) var(--universal-border-radius) 0}sup,sub,code,kbd{line-height:0;position:relative;vertical-align:baseline}small,sup,sub,figcaption{font-size:.75em}sup{top:-.5em}sub{bottom:-.25em}figure{margin:var(--universal-margin)}figcaption{color:var(--secondary-fore-color)}a{text-decoration:none}a:link{color:var(--a-link-color)}a:visited{color:var(--a-visited-color)}a:hover,a:focus{text-decoration:underline}.container{margin:0 auto;padding:0 calc(1.5 * var(--universal-padding))}.row{box-sizing:border-box;display:flex;flex:0 1 auto;flex-flow:row wrap}.col-sm,[class^='col-sm-'],[class^='col-sm-offset-'],.row[class*='cols-sm-']>*{box-sizing:border-box;flex:0 0 auto;padding:0 calc(var(--universal-padding) / 2)}.col-sm,.row.cols-sm>*{max-width:100%;flex-grow:1;flex-basis:0}.col-sm-1,.row.cols-sm-1>*{max-width:8.33333%;flex-basis:8.33333%}.col-sm-offset-0{margin-left:0}.col-sm-2,.row.cols-sm-2>*{max-width:16.66667%;flex-basis:16.66667%}.col-sm-offset-1{margin-left:8.33333%}.col-sm-3,.row.cols-sm-3>*{max-width:25%;flex-basis:25%}.col-sm-offset-2{margin-left:16.66667%}.col-sm-4,.row.cols-sm-4>*{max-width:33.33333%;flex-basis:33.33333%}.col-sm-offset-3{margin-left:25%}.col-sm-5,.row.cols-sm-5>*{max-width:41.66667%;flex-basis:41.66667%}.col-sm-offset-4{margin-left:33.33333%}.col-sm-6,.row.cols-sm-6>*{max-width:50%;flex-basis:50%}.col-sm-offset-5{margin-left:41.66667%}.col-sm-7,.row.cols-sm-7>*{max-width:58.33333%;flex-basis:58.33333%}.col-sm-offset-6{margin-left:50%}.col-sm-8,.row.cols-sm-8>*{max-width:66.66667%;flex-basis:66.66667%}.col-sm-offset-7{margin-left:58.33333%}.col-sm-9,.row.cols-sm-9>*{max-width:75%;flex-basis:75%}.col-sm-offset-8{margin-left:66.66667%}.col-sm-10,.row.cols-sm-10>*{max-width:83.33333%;flex-basis:83.33333%}.col-sm-offset-9{margin-left:75%}.col-sm-11,.row.cols-sm-11>*{max-width:91.66667%;flex-basis:91.66667%}.col-sm-offset-10{margin-left:83.33333%}.col-sm-12,.row.cols-sm-12>*{max-width:100%;flex-basis:100%}.col-sm-offset-11{margin-left:91.66667%}.col-sm-normal{order:initial}.col-sm-first{order:-999}.col-sm-last{order:999}@media screen and (min-width: 768px){.col-md,[class^='col-md-'],[class^='col-md-offset-'],.row[class*='cols-md-']>*{box-sizing:border-box;flex:0 0 auto;padding:0 calc(var(--universal-padding) / 2)}.col-md,.row.cols-md>*{max-width:100%;flex-grow:1;flex-basis:0}.col-md-1,.row.cols-md-1>*{max-width:8.33333%;flex-basis:8.33333%}.col-md-offset-0{margin-left:0}.col-md-2,.row.cols-md-2>*{max-width:16.66667%;flex-basis:16.66667%}.col-md-offset-1{margin-left:8.33333%}.col-md-3,.row.cols-md-3>*{max-width:25%;flex-basis:25%}.col-md-offset-2{margin-left:16.66667%}.col-md-4,.row.cols-md-4>*{max-width:33.33333%;flex-basis:33.33333%}.col-md-offset-3{margin-left:25%}.col-md-5,.row.cols-md-5>*{max-width:41.66667%;flex-basis:41.66667%}.col-md-offset-4{margin-left:33.33333%}.col-md-6,.row.cols-md-6>*{max-width:50%;flex-basis:50%}.col-md-offset-5{margin-left:41.66667%}.col-md-7,.row.cols-md-7>*{max-width:58.33333%;flex-basis:58.33333%}.col-md-offset-6{margin-left:50%}.col-md-8,.row.cols-md-8>*{max-width:66.66667%;flex-basis:66.66667%}.col-md-offset-7{margin-left:58.33333%}.col-md-9,.row.cols-md-9>*{max-width:75%;flex-basis:75%}.col-md-offset-8{margin-left:66.66667%}.col-md-10,.row.cols-md-10>*{max-width:83.33333%;flex-basis:83.33333%}.col-md-offset-9{margin-left:75%}.col-md-11,.row.cols-md-11>*{max-width:91.66667%;flex-basis:91.66667%}.col-md-offset-10{margin-left:83.33333%}.col-md-12,.row.cols-md-12>*{max-width:100%;flex-basis:100%}.col-md-offset-11{margin-left:91.66667%}.col-md-normal{order:initial}.col-md-first{order:-999}.col-md-last{order:999}}@media screen and (min-width: 1280px){.col-lg,[class^='col-lg-'],[class^='col-lg-offset-'],.row[class*='cols-lg-']>*{box-sizing:border-box;flex:0 0 auto;padding:0 calc(var(--universal-padding) / 2)}.col-lg,.row.cols-lg>*{max-width:100%;flex-grow:1;flex-basis:0}.col-lg-1,.row.cols-lg-1>*{max-width:8.33333%;flex-basis:8.33333%}.col-lg-offset-0{margin-left:0}.col-lg-2,.row.cols-lg-2>*{max-width:16.66667%;flex-basis:16.66667%}.col-lg-offset-1{margin-left:8.33333%}.col-lg-3,.row.cols-lg-3>*{max-width:25%;flex-basis:25%}.col-lg-offset-2{margin-left:16.66667%}.col-lg-4,.row.cols-lg-4>*{max-width:33.33333%;flex-basis:33.33333%}.col-lg-offset-3{margin-left:25%}.col-lg-5,.row.cols-lg-5>*{max-width:41.66667%;flex-basis:41.66667%}.col-lg-offset-4{margin-left:33.33333%}.col-lg-6,.row.cols-lg-6>*{max-width:50%;flex-basis:50%}.col-lg-offset-5{margin-left:41.66667%}.col-lg-7,.row.cols-lg-7>*{max-width:58.33333%;flex-basis:58.33333%}.col-lg-offset-6{margin-left:50%}.col-lg-8,.row.cols-lg-8>*{max-width:66.66667%;flex-basis:66.66667%}.col-lg-offset-7{margin-left:58.33333%}.col-lg-9,.row.cols-lg-9>*{max-width:75%;flex-basis:75%}.col-lg-offset-8{margin-left:66.66667%}.col-lg-10,.row.cols-lg-10>*{max-width:83.33333%;flex-basis:83.33333%}.col-lg-offset-9{margin-left:75%}.col-lg-11,.row.cols-lg-11>*{max-width:91.66667%;flex-basis:91.66667%}.col-lg-offset-10{margin-left:83.33333%}.col-lg-12,.row.cols-lg-12>*{max-width:100%;flex-basis:100%}.col-lg-offset-11{margin-left:91.66667%}.col-lg-normal{order:initial}.col-lg-first{order:-999}.col-lg-last{order:999}}:root{--card-back-color:#f8f8f8;--card-fore-color:#111;--card-border-color:#ddd}.card{display:flex;flex-direction:column;justify-content:space-between;align-self:center;position:relative;width:100%;background:var(--card-back-color);color:var(--card-fore-color);border:.0625rem solid var(--card-border-color);border-radius:var(--universal-border-radius);margin:var(--universal-margin);overflow:hidden}@media screen and (min-width: 320px){.card{max-width:320px}}.card>.section{background:var(--card-back-color);color:var(--card-fore-color);box-sizing:border-box;margin:0;border:0;border-radius:0;border-bottom:.0625rem solid var(--card-border-color);padding:var(--universal-padding);width:100%}.card>.section.media{height:200px;padding:0;-o-object-fit:cover;object-fit:cover}.card>.section:last-child{border-bottom:0}@media screen and (min-width: 240px){.card.small{max-width:240px}}@media screen and (min-width: 480px){.card.large{max-width:480px}}.card.fluid{max-width:100%;width:auto}.card.warning{--card-back-color:#ffca28;--card-border-color:#e8b825}.card.error{--card-back-color:#b71c1c;--card-fore-color:#f8f8f8;--card-border-color:#a71a1a}.card>.section.dark{--card-back-color:#e0e0e0}.card>.section.double-padded{padding:calc(1.5 * var(--universal-padding))}:root{--form-back-color:#f0f0f0;--form-fore-color:#111;--form-border-color:#ddd;--input-back-color:#f8f8f8;--input-fore-color:#111;--input-border-color:#ddd;--input-focus-color:#0288d1;--input-invalid-color:#d32f2f;--button-back-color:#e2e2e2;--button-hover-back-color:#dcdcdc;--button-fore-color:#212121;--button-border-color:rgba(0,0,0,0);--button-hover-border-color:rgba(0,0,0,0);--button-group-border-color:rgba(124,124,124,0.54)}form{background:var(--form-back-color);color:var(--form-fore-color);border:.0625rem solid var(--form-border-color);border-radius:var(--universal-border-radius);margin:var(--universal-margin);padding:calc(2 * var(--universal-padding)) var(--universal-padding)}fieldset{border:.0625rem solid var(--form-border-color);border-radius:var(--universal-border-radius);margin:calc(var(--universal-margin) / 4);padding:var(--universal-padding)}legend{box-sizing:border-box;display:table;max-width:100%;white-space:normal;font-weight:700;padding:calc(var(--universal-padding) / 2)}label{padding:calc(var(--universal-padding) / 2) var(--universal-padding)}.input-group{display:inline-block}.input-group.fluid{display:flex;align-items:center;justify-content:center}.input-group.fluid>input{max-width:100%;flex-grow:1;flex-basis:0px}@media screen and (max-width: 767px){.input-group.fluid{align-items:stretch;flex-direction:column}}.input-group.vertical{display:flex;align-items:stretch;flex-direction:column}.input-group.vertical>input{max-width:100%;flex-grow:1;flex-basis:0px}[type=\"number\"]::-webkit-inner-spin-button,[type=\"number\"]::-webkit-outer-spin-button{height:auto}[type=\"search\"]{-webkit-appearance:textfield;outline-offset:-2px}[type=\"search\"]::-webkit-search-cancel-button,[type=\"search\"]::-webkit-search-decoration{-webkit-appearance:none}input:not([type]),[type=\"text\"],[type=\"email\"],[type=\"number\"],[type=\"search\"],[type=\"password\"],[type=\"url\"],[type=\"tel\"],[type=\"checkbox\"],[type=\"radio\"],textarea,select{box-sizing:border-box;background:var(--input-back-color);color:var(--input-fore-color);border:.0625rem solid var(--input-border-color);border-radius:var(--universal-border-radius);margin:calc(var(--universal-margin) / 2);padding:var(--universal-padding) calc(1.5 * var(--universal-padding))}input:not([type=\"button\"]):not([type=\"submit\"]):not([type=\"reset\"]):hover,input:not([type=\"button\"]):not([type=\"submit\"]):not([type=\"reset\"]):focus,textarea:hover,textarea:focus,select:hover,select:focus{border-color:var(--input-focus-color);box-shadow:none}input:not([type=\"button\"]):not([type=\"submit\"]):not([type=\"reset\"]):invalid,input:not([type=\"button\"]):not([type=\"submit\"]):not([type=\"reset\"]):focus:invalid,textarea:invalid,textarea:focus:invalid,select:invalid,select:focus:invalid{border-color:var(--input-invalid-color);box-shadow:none}input:not([type=\"button\"]):not([type=\"submit\"]):not([type=\"reset\"])[readonly],textarea[readonly],select[readonly]{background:var(--secondary-back-color)}select{max-width:100%}option{overflow:hidden;text-overflow:ellipsis}[type=\"checkbox\"],[type=\"radio\"]{-webkit-appearance:none;-moz-appearance:none;appearance:none;position:relative;height:calc(1rem + var(--universal-padding) / 2);width:calc(1rem + var(--universal-padding) / 2);vertical-align:text-bottom;padding:0;flex-basis:calc(1rem + var(--universal-padding) / 2) !important;flex-grow:0 !important}[type=\"checkbox\"]:checked:before,[type=\"radio\"]:checked:before{position:absolute}[type=\"checkbox\"]:checked:before{content:'\\2713';font-family:sans-serif;font-size:calc(1rem + var(--universal-padding) / 2);top:calc(0rem - var(--universal-padding));left:calc(var(--universal-padding) / 4)}[type=\"radio\"]{border-radius:100%}[type=\"radio\"]:checked:before{border-radius:100%;content:'';top:calc(.0625rem + var(--universal-padding) / 2);left:calc(.0625rem + var(--universal-padding) / 2);background:var(--input-fore-color);width:0.5rem;height:0.5rem}:placeholder-shown{color:var(--input-fore-color)}::-ms-placeholder{color:var(--input-fore-color);opacity:0.54}button::-moz-focus-inner,[type=\"button\"]::-moz-focus-inner,[type=\"reset\"]::-moz-focus-inner,[type=\"submit\"]::-moz-focus-inner{border-style:none;padding:0}button,html [type=\"button\"],[type=\"reset\"],[type=\"submit\"]{-webkit-appearance:button}button{overflow:visible;text-transform:none}button,[type=\"button\"],[type=\"submit\"],[type=\"reset\"],a.button,label.button,.button,a[role=\"button\"],label[role=\"button\"],[role=\"button\"]{display:inline-block;background:var(--button-back-color);color:var(--button-fore-color);border:.0625rem solid var(--button-border-color);border-radius:var(--universal-border-radius);padding:var(--universal-padding) calc(1.5 * var(--universal-padding));margin:var(--universal-margin);text-decoration:none;cursor:pointer;transition:background 0.3s}button:hover,button:focus,[type=\"button\"]:hover,[type=\"button\"]:focus,[type=\"submit\"]:hover,[type=\"submit\"]:focus,[type=\"reset\"]:hover,[type=\"reset\"]:focus,a.button:hover,a.button:focus,label.button:hover,label.button:focus,.button:hover,.button:focus,a[role=\"button\"]:hover,a[role=\"button\"]:focus,label[role=\"button\"]:hover,label[role=\"button\"]:focus,[role=\"button\"]:hover,[role=\"button\"]:focus{background:var(--button-hover-back-color);border-color:var(--button-hover-border-color)}input:disabled,input[disabled],textarea:disabled,textarea[disabled],select:disabled,select[disabled],button:disabled,button[disabled],.button:disabled,.button[disabled],[role=\"button\"]:disabled,[role=\"button\"][disabled]{cursor:not-allowed;opacity:.75}.button-group{display:flex;border:.0625rem solid var(--button-group-border-color);border-radius:var(--universal-border-radius);margin:var(--universal-margin)}.button-group>button,.button-group [type=\"button\"],.button-group>[type=\"submit\"],.button-group>[type=\"reset\"],.button-group>.button,.button-group>[role=\"button\"]{margin:0;max-width:100%;flex:1 1 auto;text-align:center;border:0;border-radius:0;box-shadow:none}.button-group>:not(:first-child){border-left:.0625rem solid var(--button-group-border-color)}@media screen and (max-width: 767px){.button-group{flex-direction:column}.button-group>:not(:first-child){border:0;border-top:.0625rem solid var(--button-group-border-color)}}button.primary,[type=\"button\"].primary,[type=\"submit\"].primary,[type=\"reset\"].primary,.button.primary,[role=\"button\"].primary{--button-back-color:#1976d2;--button-fore-color:#f8f8f8}button.primary:hover,button.primary:focus,[type=\"button\"].primary:hover,[type=\"button\"].primary:focus,[type=\"submit\"].primary:hover,[type=\"submit\"].primary:focus,[type=\"reset\"].primary:hover,[type=\"reset\"].primary:focus,.button.primary:hover,.button.primary:focus,[role=\"button\"].primary:hover,[role=\"button\"].primary:focus{--button-hover-back-color:#1565c0}button.secondary,[type=\"button\"].secondary,[type=\"submit\"].secondary,[type=\"reset\"].secondary,.button.secondary,[role=\"button\"].secondary{--button-back-color:#d32f2f;--button-fore-color:#f8f8f8}button.secondary:hover,button.secondary:focus,[type=\"button\"].secondary:hover,[type=\"button\"].secondary:focus,[type=\"submit\"].secondary:hover,[type=\"submit\"].secondary:focus,[type=\"reset\"].secondary:hover,[type=\"reset\"].secondary:focus,.button.secondary:hover,.button.secondary:focus,[role=\"button\"].secondary:hover,[role=\"button\"].secondary:focus{--button-hover-back-color:#c62828}button.tertiary,[type=\"button\"].tertiary,[type=\"submit\"].tertiary,[type=\"reset\"].tertiary,.button.tertiary,[role=\"button\"].tertiary{--button-back-color:#308732;--button-fore-color:#f8f8f8}button.tertiary:hover,button.tertiary:focus,[type=\"button\"].tertiary:hover,[type=\"button\"].tertiary:focus,[type=\"submit\"].tertiary:hover,[type=\"submit\"].tertiary:focus,[type=\"reset\"].tertiary:hover,[type=\"reset\"].tertiary:focus,.button.tertiary:hover,.button.tertiary:focus,[role=\"button\"].tertiary:hover,[role=\"button\"].tertiary:focus{--button-hover-back-color:#277529}button.inverse,[type=\"button\"].inverse,[type=\"submit\"].inverse,[type=\"reset\"].inverse,.button.inverse,[role=\"button\"].inverse{--button-back-color:#212121;--button-fore-color:#f8f8f8}button.inverse:hover,button.inverse:focus,[type=\"button\"].inverse:hover,[type=\"button\"].inverse:focus,[type=\"submit\"].inverse:hover,[type=\"submit\"].inverse:focus,[type=\"reset\"].inverse:hover,[type=\"reset\"].inverse:focus,.button.inverse:hover,.button.inverse:focus,[role=\"button\"].inverse:hover,[role=\"button\"].inverse:focus{--button-hover-back-color:#111}button.small,[type=\"button\"].small,[type=\"submit\"].small,[type=\"reset\"].small,.button.small,[role=\"button\"].small{padding:calc(0.5 * var(--universal-padding)) calc(0.75 * var(--universal-padding));margin:var(--universal-margin)}button.large,[type=\"button\"].large,[type=\"submit\"].large,[type=\"reset\"].large,.button.large,[role=\"button\"].large{padding:calc(1.5 * var(--universal-padding)) calc(2 * var(--universal-padding));margin:var(--universal-margin)}:root{--header-back-color:#f8f8f8;--header-hover-back-color:#f0f0f0;--header-fore-color:#444;--header-border-color:#ddd;--nav-back-color:#f8f8f8;--nav-hover-back-color:#f0f0f0;--nav-fore-color:#444;--nav-border-color:#ddd;--nav-link-color:#0277bd;--footer-fore-color:#444;--footer-back-color:#f8f8f8;--footer-border-color:#ddd;--footer-link-color:#0277bd;--drawer-back-color:#f8f8f8;--drawer-hover-back-color:#f0f0f0;--drawer-border-color:#ddd;--drawer-close-color:#444}header{height:3.1875rem;background:var(--header-back-color);color:var(--header-fore-color);border-bottom:.0625rem solid var(--header-border-color);padding:calc(var(--universal-padding) / 4) 0;white-space:nowrap;overflow-x:auto;overflow-y:hidden}header.row{box-sizing:content-box}header .logo{color:var(--header-fore-color);font-size:1.75rem;padding:var(--universal-padding) calc(2 * var(--universal-padding));text-decoration:none}header button,header [type=\"button\"],header .button,header [role=\"button\"]{box-sizing:border-box;position:relative;top:calc(0rem - var(--universal-padding) / 4);height:calc(3.1875rem + var(--universal-padding) / 2);background:var(--header-back-color);line-height:calc(3.1875rem - var(--universal-padding) * 1.5);text-align:center;color:var(--header-fore-color);border:0;border-radius:0;margin:0;text-transform:uppercase}header button:hover,header button:focus,header [type=\"button\"]:hover,header [type=\"button\"]:focus,header .button:hover,header .button:focus,header [role=\"button\"]:hover,header [role=\"button\"]:focus{background:var(--header-hover-back-color)}nav{background:var(--nav-back-color);color:var(--nav-fore-color);border:.0625rem solid var(--nav-border-color);border-radius:var(--universal-border-radius);margin:var(--universal-margin)}nav *{padding:var(--universal-padding) calc(1.5 * var(--universal-padding))}nav a,nav a:visited{display:block;color:var(--nav-link-color);border-radius:var(--universal-border-radius);transition:background 0.3s}nav a:hover,nav a:focus,nav a:visited:hover,nav a:visited:focus{text-decoration:none;background:var(--nav-hover-back-color)}nav .sublink-1{position:relative;margin-left:calc(2 * var(--universal-padding))}nav .sublink-1:before{position:absolute;left:calc(var(--universal-padding) - 1 * var(--universal-padding));top:-.0625rem;content:'';height:100%;border:.0625rem solid var(--nav-border-color);border-left:0}nav .sublink-2{position:relative;margin-left:calc(4 * var(--universal-padding))}nav .sublink-2:before{position:absolute;left:calc(var(--universal-padding) - 3 * var(--universal-padding));top:-.0625rem;content:'';height:100%;border:.0625rem solid var(--nav-border-color);border-left:0}footer{background:var(--footer-back-color);color:var(--footer-fore-color);border-top:.0625rem solid var(--footer-border-color);padding:calc(2 * var(--universal-padding)) var(--universal-padding);font-size:.875rem}footer a,footer a:visited{color:var(--footer-link-color)}header.sticky{position:-webkit-sticky;position:sticky;z-index:1101;top:0}footer.sticky{position:-webkit-sticky;position:sticky;z-index:1101;bottom:0}.drawer-toggle:before{display:inline-block;position:relative;vertical-align:bottom;content:'\\00a0\\2261\\00a0';font-family:sans-serif;font-size:1.5em}@media screen and (min-width: 768px){.drawer-toggle:not(.persistent){display:none}}[type=\"checkbox\"].drawer{height:1px;width:1px;margin:-1px;overflow:hidden;position:absolute;clip:rect(0 0 0 0);-webkit-clip-path:inset(100%);clip-path:inset(100%)}[type=\"checkbox\"].drawer+*{display:block;box-sizing:border-box;position:fixed;top:0;width:320px;height:100vh;overflow-y:auto;background:var(--drawer-back-color);border:.0625rem solid var(--drawer-border-color);border-radius:0;margin:0;z-index:1110;right:-320px;transition:right 0.3s}[type=\"checkbox\"].drawer+* .drawer-close{position:absolute;top:var(--universal-margin);right:var(--universal-margin);z-index:1111;width:2rem;height:2rem;border-radius:var(--universal-border-radius);padding:var(--universal-padding);margin:0;cursor:pointer;transition:background 0.3s}[type=\"checkbox\"].drawer+* .drawer-close:before{display:block;content:'\\00D7';color:var(--drawer-close-color);position:relative;font-family:sans-serif;font-size:2rem;line-height:1;text-align:center}[type=\"checkbox\"].drawer+* .drawer-close:hover,[type=\"checkbox\"].drawer+* .drawer-close:focus{background:var(--drawer-hover-back-color)}@media screen and (max-width: 320px){[type=\"checkbox\"].drawer+*{width:100%}}[type=\"checkbox\"].drawer:checked+*{right:0}@media screen and (min-width: 768px){[type=\"checkbox\"].drawer:not(.persistent)+*{position:static;height:100%;z-index:1100}[type=\"checkbox\"].drawer:not(.persistent)+* .drawer-close{display:none}}:root{--table-border-color:#aaa;--table-border-separator-color:#666;--table-head-back-color:#e6e6e6;--table-head-fore-color:#111;--table-body-back-color:#f8f8f8;--table-body-fore-color:#111;--table-body-alt-back-color:#eee}table{border-collapse:separate;border-spacing:0;margin:0;display:flex;flex:0 1 auto;flex-flow:row wrap;padding:var(--universal-padding);padding-top:0}table caption{font-size:1.5rem;margin:calc(2 * var(--universal-margin)) 0;max-width:100%;flex:0 0 100%}table thead,table tbody{display:flex;flex-flow:row wrap;border:.0625rem solid var(--table-border-color)}table thead{z-index:999;border-radius:var(--universal-border-radius) var(--universal-border-radius) 0 0;border-bottom:.0625rem solid var(--table-border-separator-color)}table tbody{border-top:0;margin-top:calc(0 - var(--universal-margin));border-radius:0 0 var(--universal-border-radius) var(--universal-border-radius)}table tr{display:flex;padding:0}table th,table td{padding:calc(2 * var(--universal-padding))}table th{text-align:left;background:var(--table-head-back-color);color:var(--table-head-fore-color)}table td{background:var(--table-body-back-color);color:var(--table-body-fore-color);border-top:.0625rem solid var(--table-border-color)}table:not(.horizontal){overflow:auto;max-height:400px}table:not(.horizontal) thead,table:not(.horizontal) tbody{max-width:100%;flex:0 0 100%}table:not(.horizontal) tr{flex-flow:row wrap;flex:0 0 100%}table:not(.horizontal) th,table:not(.horizontal) td{flex:1 0 0%;overflow:hidden;text-overflow:ellipsis}table:not(.horizontal) thead{position:sticky;top:0}table:not(.horizontal) tbody tr:first-child td{border-top:0}table.horizontal{border:0}table.horizontal thead,table.horizontal tbody{border:0;flex:.2 0 0;flex-flow:row nowrap}table.horizontal tbody{overflow:auto;justify-content:space-between;flex:.8 0 0;margin-left:0;padding-bottom:calc(var(--universal-padding) / 4)}table.horizontal tr{flex-direction:column;flex:1 0 auto}table.horizontal th,table.horizontal td{width:auto;border:0;border-bottom:.0625rem solid var(--table-border-color)}table.horizontal th:not(:first-child),table.horizontal td:not(:first-child){border-top:0}table.horizontal th{text-align:right;border-left:.0625rem solid var(--table-border-color);border-right:.0625rem solid var(--table-border-separator-color)}table.horizontal thead tr:first-child{padding-left:0}table.horizontal th:first-child,table.horizontal td:first-child{border-top:.0625rem solid var(--table-border-color)}table.horizontal tbody tr:last-child td{border-right:.0625rem solid var(--table-border-color)}table.horizontal tbody tr:last-child td:first-child{border-top-right-radius:0.25rem}table.horizontal tbody tr:last-child td:last-child{border-bottom-right-radius:0.25rem}table.horizontal thead tr:first-child th:first-child{border-top-left-radius:0.25rem}table.horizontal thead tr:first-child th:last-child{border-bottom-left-radius:0.25rem}@media screen and (max-width: 767px){table,table.horizontal{border-collapse:collapse;border:0;width:100%;display:table}table thead,table th,table.horizontal thead,table.horizontal th{border:0;height:1px;width:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;clip:rect(0 0 0 0);-webkit-clip-path:inset(100%);clip-path:inset(100%)}table tbody,table.horizontal tbody{border:0;display:table-row-group}table tr,table.horizontal tr{display:block;border:.0625rem solid var(--table-border-color);border-radius:var(--universal-border-radius);background:#fafafa;padding:var(--universal-padding);margin:var(--universal-margin);margin-bottom:calc(2 * var(--universal-margin))}table th,table td,table.horizontal th,table.horizontal td{width:auto}table td,table.horizontal td{display:block;border:0;text-align:right}table td:before,table.horizontal td:before{content:attr(data-label);float:left;font-weight:600}table th:first-child,table td:first-child,table.horizontal th:first-child,table.horizontal td:first-child{border-top:0}table tbody tr:last-child td,table.horizontal tbody tr:last-child td{border-right:0}}:root{--table-body-alt-back-color:#eee}table.striped tr:nth-of-type(2n)>td{background:var(--table-body-alt-back-color)}@media screen and (max-width: 768px){table.striped tr:nth-of-type(2n){background:var(--table-body-alt-back-color)}}:root{--table-body-hover-back-color:#90caf9}table.hoverable tr:hover,table.hoverable tr:hover>td,table.hoverable tr:focus,table.hoverable tr:focus>td{background:var(--table-body-hover-back-color)}@media screen and (max-width: 768px){table.hoverable tr:hover,table.hoverable tr:hover>td,table.hoverable tr:focus,table.hoverable tr:focus>td{background:var(--table-body-hover-back-color)}}:root{--mark-back-color:#0277bd;--mark-fore-color:#fafafa}mark{background:var(--mark-back-color);color:var(--mark-fore-color);font-size:.95em;line-height:1em;border-radius:var(--universal-border-radius);padding:calc(var(--universal-padding) / 4) calc(var(--universal-padding) / 2)}mark.inline-block{display:inline-block;font-size:1em;line-height:1.5;padding:calc(var(--universal-padding) / 2) var(--universal-padding)}:root{--toast-back-color:#424242;--toast-fore-color:#fafafa}.toast{position:fixed;bottom:calc(var(--universal-margin) * 3);left:50%;transform:translate(-50%, -50%);z-index:1111;color:var(--toast-fore-color);background:var(--toast-back-color);border-radius:calc(var(--universal-border-radius) * 16);padding:var(--universal-padding) calc(var(--universal-padding) * 3)}:root{--tooltip-back-color:#212121;--tooltip-fore-color:#fafafa}.tooltip{position:relative;display:inline-block}.tooltip:before,.tooltip:after{position:absolute;opacity:0;clip:rect(0 0 0 0);-webkit-clip-path:inset(100%);clip-path:inset(100%);transition:all 0.3s;z-index:1010;left:50%}.tooltip:not(.bottom):before,.tooltip:not(.bottom):after{bottom:75%}.tooltip.bottom:before,.tooltip.bottom:after{top:75%}.tooltip:hover:before,.tooltip:hover:after,.tooltip:focus:before,.tooltip:focus:after{opacity:1;clip:auto;-webkit-clip-path:inset(0%);clip-path:inset(0%)}.tooltip:before{content:'';background:transparent;border:var(--universal-margin) solid transparent;left:calc(50% - var(--universal-margin))}.tooltip:not(.bottom):before{border-top-color:#212121}.tooltip.bottom:before{border-bottom-color:#212121}.tooltip:after{content:attr(aria-label);color:var(--tooltip-fore-color);background:var(--tooltip-back-color);border-radius:var(--universal-border-radius);padding:var(--universal-padding);white-space:nowrap;transform:translateX(-50%)}.tooltip:not(.bottom):after{margin-bottom:calc(2 * var(--universal-margin))}.tooltip.bottom:after{margin-top:calc(2 * var(--universal-margin))}:root{--modal-overlay-color:rgba(0,0,0,0.45);--modal-close-color:#444;--modal-close-hover-color:#f0f0f0}[type=\"checkbox\"].modal{height:1px;width:1px;margin:-1px;overflow:hidden;position:absolute;clip:rect(0 0 0 0);-webkit-clip-path:inset(100%);clip-path:inset(100%)}[type=\"checkbox\"].modal+div{position:fixed;top:0;left:0;display:none;width:100vw;height:100vh;background:var(--modal-overlay-color)}[type=\"checkbox\"].modal+div .card{margin:0 auto;max-height:50vh;overflow:auto}[type=\"checkbox\"].modal+div .card .modal-close{position:absolute;top:0;right:0;width:1.75rem;height:1.75rem;border-radius:var(--universal-border-radius);padding:var(--universal-padding);margin:0;cursor:pointer;transition:background 0.3s}[type=\"checkbox\"].modal+div .card .modal-close:before{display:block;content:'\\00D7';color:var(--modal-close-color);position:relative;font-family:sans-serif;font-size:1.75rem;line-height:1;text-align:center}[type=\"checkbox\"].modal+div .card .modal-close:hover,[type=\"checkbox\"].modal+div .card .modal-close:focus{background:var(--modal-close-hover-color)}[type=\"checkbox\"].modal:checked+div{display:flex;flex:0 1 auto;z-index:1200}[type=\"checkbox\"].modal:checked+div .card .modal-close{z-index:1211}:root{--collapse-label-back-color:#e8e8e8;--collapse-label-fore-color:#212121;--collapse-label-hover-back-color:#f0f0f0;--collapse-selected-label-back-color:#ececec;--collapse-border-color:#ddd;--collapse-content-back-color:#fafafa;--collapse-selected-label-border-color:#0277bd}.collapse{width:calc(100% - 2 * var(--universal-margin));opacity:1;display:flex;flex-direction:column;margin:var(--universal-margin);border-radius:var(--universal-border-radius)}.collapse>[type=\"radio\"],.collapse>[type=\"checkbox\"]{height:1px;width:1px;margin:-1px;overflow:hidden;position:absolute;clip:rect(0 0 0 0);-webkit-clip-path:inset(100%);clip-path:inset(100%)}.collapse>label{flex-grow:1;display:inline-block;height:1.5rem;cursor:pointer;transition:background 0.3s;color:var(--collapse-label-fore-color);background:var(--collapse-label-back-color);border:.0625rem solid var(--collapse-border-color);padding:calc(1.5 * var(--universal-padding))}.collapse>label:hover,.collapse>label:focus{background:var(--collapse-label-hover-back-color)}.collapse>label+div{flex-basis:auto;height:1px;width:1px;margin:-1px;overflow:hidden;position:absolute;clip:rect(0 0 0 0);-webkit-clip-path:inset(100%);clip-path:inset(100%);transition:max-height 0.3s;max-height:1px}.collapse>:checked+label{background:var(--collapse-selected-label-back-color);border-bottom-color:var(--collapse-selected-label-border-color)}.collapse>:checked+label+div{box-sizing:border-box;position:relative;width:100%;height:auto;overflow:auto;margin:0;background:var(--collapse-content-back-color);border:.0625rem solid var(--collapse-border-color);border-top:0;padding:var(--universal-padding);clip:auto;-webkit-clip-path:inset(0%);clip-path:inset(0%);max-height:400px}.collapse>label:not(:first-of-type){border-top:0}.collapse>label:first-of-type{border-radius:var(--universal-border-radius) var(--universal-border-radius) 0 0}.collapse>label:last-of-type:not(:first-of-type){border-radius:0 0 var(--universal-border-radius) var(--universal-border-radius)}.collapse>label:last-of-type:first-of-type{border-radius:var(--universal-border-radius)}.collapse>:checked:last-of-type:not(:first-of-type)+label{border-radius:0}.collapse>:checked:last-of-type+label+div{border-radius:0 0 var(--universal-border-radius) var(--universal-border-radius)}mark.secondary{--mark-back-color:#d32f2f}mark.tertiary{--mark-back-color:#308732}mark.tag{padding:calc(var(--universal-padding)/2) var(--universal-padding);border-radius:1em}:root{--progress-back-color:#ddd;--progress-fore-color:#555}progress{display:block;vertical-align:baseline;-webkit-appearance:none;-moz-appearance:none;appearance:none;height:.75rem;width:calc(100% - 2 * var(--universal-margin));margin:var(--universal-margin);border:0;border-radius:calc(2 * var(--universal-border-radius));background:var(--progress-back-color);color:var(--progress-fore-color)}progress::-webkit-progress-value{background:var(--progress-fore-color);border-top-left-radius:calc(2 * var(--universal-border-radius));border-bottom-left-radius:calc(2 * var(--universal-border-radius))}progress::-webkit-progress-bar{background:var(--progress-back-color)}progress::-moz-progress-bar{background:var(--progress-fore-color);border-top-left-radius:calc(2 * var(--universal-border-radius));border-bottom-left-radius:calc(2 * var(--universal-border-radius))}progress[value=\"1000\"]::-webkit-progress-value{border-radius:calc(2 * var(--universal-border-radius))}progress[value=\"1000\"]::-moz-progress-bar{border-radius:calc(2 * var(--universal-border-radius))}progress.inline{display:inline-block;vertical-align:middle;width:60%}:root{--spinner-back-color:#ddd;--spinner-fore-color:#555}@keyframes spinner-donut-anim{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}.spinner{display:inline-block;margin:var(--universal-margin);border:.25rem solid var(--spinner-back-color);border-left:.25rem solid var(--spinner-fore-color);border-radius:50%;width:1.25rem;height:1.25rem;animation:spinner-donut-anim 1.2s linear infinite}progress.primary{--progress-fore-color:#1976d2}progress.secondary{--progress-fore-color:#d32f2f}progress.tertiary{--progress-fore-color:#308732}.spinner.primary{--spinner-fore-color:#1976d2}.spinner.secondary{--spinner-fore-color:#d32f2f}.spinner.tertiary{--spinner-fore-color:#308732}span[class^='icon-']{display:inline-block;height:1em;width:1em;vertical-align:-0.125em;background-size:contain;margin:0 calc(var(--universal-margin) / 4)}span[class^='icon-'].secondary{-webkit-filter:invert(25%);filter:invert(25%)}span[class^='icon-'].inverse{-webkit-filter:invert(100%);filter:invert(100%)}span.icon-alert{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='10'%3E%3C/circle%3E%3Cline x1='12' y1='8' x2='12' y2='12'%3E%3C/line%3E%3Cline x1='12' y1='16' x2='12' y2='16'%3E%3C/line%3E%3C/svg%3E\")}span.icon-bookmark{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z'%3E%3C/path%3E%3C/svg%3E\")}span.icon-calendar{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='4' width='18' height='18' rx='2' ry='2'%3E%3C/rect%3E%3Cline x1='16' y1='2' x2='16' y2='6'%3E%3C/line%3E%3Cline x1='8' y1='2' x2='8' y2='6'%3E%3C/line%3E%3Cline x1='3' y1='10' x2='21' y2='10'%3E%3C/line%3E%3C/svg%3E\")}span.icon-credit{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='1' y='4' width='22' height='16' rx='2' ry='2'%3E%3C/rect%3E%3Cline x1='1' y1='10' x2='23' y2='10'%3E%3C/line%3E%3C/svg%3E\")}span.icon-edit{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34'%3E%3C/path%3E%3Cpolygon points='18 2 22 6 12 16 8 16 8 12 18 2'%3E%3C/polygon%3E%3C/svg%3E\")}span.icon-link{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6'%3E%3C/path%3E%3Cpolyline points='15 3 21 3 21 9'%3E%3C/polyline%3E%3Cline x1='10' y1='14' x2='21' y2='3'%3E%3C/line%3E%3C/svg%3E\")}span.icon-help{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3'%3E%3C/path%3E%3Ccircle cx='12' cy='12' r='10'%3E%3C/circle%3E%3Cline x1='12' y1='17' x2='12' y2='17'%3E%3C/line%3E%3C/svg%3E\")}span.icon-home{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'%3E%3C/path%3E%3Cpolyline points='9 22 9 12 15 12 15 22'%3E%3C/polyline%3E%3C/svg%3E\")}span.icon-info{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='10'%3E%3C/circle%3E%3Cline x1='12' y1='16' x2='12' y2='12'%3E%3C/line%3E%3Cline x1='12' y1='8' x2='12' y2='8'%3E%3C/line%3E%3C/svg%3E\")}span.icon-lock{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='11' width='18' height='11' rx='2' ry='2'%3E%3C/rect%3E%3Cpath d='M7 11V7a5 5 0 0 1 10 0v4'%3E%3C/path%3E%3C/svg%3E\")}span.icon-mail{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z'%3E%3C/path%3E%3Cpolyline points='22,6 12,13 2,6'%3E%3C/polyline%3E%3C/svg%3E\")}span.icon-location{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'%3E%3C/path%3E%3Ccircle cx='12' cy='10' r='3'%3E%3C/circle%3E%3C/svg%3E\")}span.icon-phone{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z'%3E%3C/path%3E%3C/svg%3E\")}span.icon-rss{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M4 11a9 9 0 0 1 9 9'%3E%3C/path%3E%3Cpath d='M4 4a16 16 0 0 1 16 16'%3E%3C/path%3E%3Ccircle cx='5' cy='19' r='1'%3E%3C/circle%3E%3C/svg%3E\")}span.icon-search{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='11' cy='11' r='8'%3E%3C/circle%3E%3Cline x1='21' y1='21' x2='16.65' y2='16.65'%3E%3C/line%3E%3C/svg%3E\")}span.icon-settings{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='3'%3E%3C/circle%3E%3Cpath d='M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z'%3E%3C/path%3E%3C/svg%3E\")}span.icon-share{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='18' cy='5' r='3'%3E%3C/circle%3E%3Ccircle cx='6' cy='12' r='3'%3E%3C/circle%3E%3Ccircle cx='18' cy='19' r='3'%3E%3C/circle%3E%3Cline x1='8.59' y1='13.51' x2='15.42' y2='17.49'%3E%3C/line%3E%3Cline x1='15.41' y1='6.51' x2='8.59' y2='10.49'%3E%3C/line%3E%3C/svg%3E\")}span.icon-cart{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='9' cy='21' r='1'%3E%3C/circle%3E%3Ccircle cx='20' cy='21' r='1'%3E%3C/circle%3E%3Cpath d='M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6'%3E%3C/path%3E%3C/svg%3E\")}span.icon-upload{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'%3E%3C/path%3E%3Cpolyline points='17 8 12 3 7 8'%3E%3C/polyline%3E%3Cline x1='12' y1='3' x2='12' y2='15'%3E%3C/line%3E%3C/svg%3E\")}span.icon-user{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'%3E%3C/path%3E%3Ccircle cx='12' cy='7' r='4'%3E%3C/circle%3E%3C/svg%3E\")}:root{--generic-border-color:rgba(0,0,0,0.3);--generic-box-shadow:0 .25rem .25rem 0 rgba(0,0,0,0.125),0 .125rem .125rem -.125rem rgba(0,0,0,0.25)}.hidden{display:none !important}.visually-hidden{position:absolute !important;width:1px !important;height:1px !important;margin:-1px !important;border:0 !important;padding:0 !important;clip:rect(0 0 0 0) !important;-webkit-clip-path:inset(100%) !important;clip-path:inset(100%) !important;overflow:hidden !important}.bordered{border:.0625rem solid var(--generic-border-color) !important}.rounded{border-radius:var(--universal-border-radius) !important}.circular{border-radius:50% !important}.shadowed{box-shadow:var(--generic-box-shadow) !important}.responsive-margin{margin:calc(var(--universal-margin) / 4) !important}@media screen and (min-width: 768px){.responsive-margin{margin:calc(var(--universal-margin) / 2) !important}}@media screen and (min-width: 1280px){.responsive-margin{margin:var(--universal-margin) !important}}.responsive-padding{padding:calc(var(--universal-padding) / 4) !important}@media screen and (min-width: 768px){.responsive-padding{padding:calc(var(--universal-padding) / 2) !important}}@media screen and (min-width: 1280px){.responsive-padding{padding:var(--universal-padding) !important}}@media screen and (max-width: 767px){.hidden-sm{display:none !important}}@media screen and (min-width: 768px) and (max-width: 1279px){.hidden-md{display:none !important}}@media screen and (min-width: 1280px){.hidden-lg{display:none !important}}@media screen and (max-width: 767px){.visually-hidden-sm{position:absolute !important;width:1px !important;height:1px !important;margin:-1px !important;border:0 !important;padding:0 !important;clip:rect(0 0 0 0) !important;-webkit-clip-path:inset(100%) !important;clip-path:inset(100%) !important;overflow:hidden !important}}@media screen and (min-width: 768px) and (max-width: 1279px){.visually-hidden-md{position:absolute !important;width:1px !important;height:1px !important;margin:-1px !important;border:0 !important;padding:0 !important;clip:rect(0 0 0 0) !important;-webkit-clip-path:inset(100%) !important;clip-path:inset(100%) !important;overflow:hidden !important}}@media screen and (min-width: 1280px){.visually-hidden-lg{position:absolute !important;width:1px !important;height:1px !important;margin:-1px !important;border:0 !important;padding:0 !important;clip:rect(0 0 0 0) !important;-webkit-clip-path:inset(100%) !important;clip-path:inset(100%) !important;overflow:hidden !important}}\n", "",{"version":3,"sources":["/workspaces/SgopleReef/node_modules/mini.css/src/mini/_core.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_layout.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_layout_mixins.scss","/workspaces/SgopleReef/node_modules/mini.css/src/flavors/mini-default.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_input_control.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_input_control_mixins.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_navigation.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_table.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_contextual.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_contextual_mixins.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_progress.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_progress_mixins.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_icon.scss","/workspaces/SgopleReef/node_modules/mini.css/src/mini/_utility.scss"],"names":[],"mappings":"AA0DA,MACE,iBA/C4B,CAgD5B,2BA/C4B,CAgD5B,oBA/C+B,CAgD/B,8BA/C+B,CAgD/B,0BA/C+B,CAgD/B,mBA/C+B,CAgD/B,mBA/C4B,CAgD5B,6BA/C4B,CAgD5B,oBA9C4B,CA+C5B,wBA5C8B,CA6C9B,yBA5C8B,CA6C9B,iCA5CgC,CA6ChC,sBAhCgC,CAiChC,yBAhCgC,CAoCjC,KAEC,cAzE4B,CA0E7B,iCAEC,aAAc,CACf,OAIG,kHAAa,CACb,eA9EyB,CAgFzB,6BAA8B,CAC/B,EAEC,cAlF0B,CAmF3B,KAYD,QA9FyB,CA+FzB,uBAA8B,CAC9B,4BAAmC,CACpC,QAIC,aAAc,CACf,QAIC,iBAAkB,CACnB,YAIC,kBAAmB,CACnB,gCAAiC,CAClC,MAIC,gBAAiB,CAClB,IAIC,cAAe,CACf,WAAY,CACb,kBAGC,eAtH2B,CAuH3B,kEAA+E,CAC/E,eA/G2B,CA4G7B,sDAKI,iCAAwC,CACxC,aAAc,CAEZ,kBA1H4B,CA+H/B,GAID,gHAAyI,CAC1I,GAEC,yFAA4G,CAC7G,GAEC,kEAA+E,CAChF,GAEC,2CAAkD,CACnD,GAEC,cAAe,CAChB,GAEC,2CAAkD,CACnD,EAGC,8BAAqC,CACtC,MAGC,8BAAqC,CACrC,8CAAqD,CACtD,SAGC,eAxJ2B,CAyJ5B,GAIC,sBAAuB,CACvB,QAAS,CAET,kBA/JmC,CAgKnC,8BAAqC,CACrC,eAzLwC,CA0LxC,gHAA6H,CAC9H,WAGC,aAAc,CACd,iBAAkB,CAClB,iBAAkB,CAClB,iCAAwC,CACxC,8BAAqC,CACrC,0CAAiD,CACjD,mDAAwD,CACxD,iDAAyD,CACzD,+EAA4F,CAT9F,kBAcI,iBAAkB,CAClB,yCAAgD,CAChD,MAAO,CACP,sBAAuB,CACvB,cAtL+B,CAuL/B,eAAgB,CAChB,eAAgB,CAChB,6BAAoC,CArBxC,uBAwBI,iBAAkB,CAClB,eA5LiC,CA6LjC,eAAgB,CAChB,0BAAkB,CAAU,eACf,CAAG,kBAIA,sCACN,CAAC,eAlMY,CAAM,KAsM7B,sCACU,CAAiC,4CAC9B,CAAoC,6EAED,CAAwC,IAMzF,4BACW,CAAuB,uBAC5B,CAAuB,4CACf,CAAoC,6EAED,CAAwC,IAMzF,aACS,CAAI,sCACF,CAAiC,4CACpC,CAA0C,8BAC3C,CAA6B,mDAChB,CAAmC,yCAC5B,CAAsB,+EACyC,CAAC,iBAO3E,aACJ,CAAC,iBACJ,CAAQ,uBACF,CAAQ,yBAGC,eA9OG,CAAM,IAkPjC,SAjPyB,CAAK,IAoP9B,aAnPyB,CAAM,OAuP5B,8BACI,CAA6B,WAE7B,iCACC,CAAiC,EAG3C,oBACkB,CAAI,OACf,yBACG,CAAyB,UAEzB,4BACA,CAA4B,gBAErB,yBACG,CAAS,WCvPpB,aACA,CAAM,8CACH,CAA0C,KAGnD,qBACU,CAAU,YACb,CAAI,aACP,CAAQ,kBACH,CAAQ,+EAQU,qBACb,CAAU,aAChB,CAAQ,4CACH,CAAwC,uBAIrC,cACH,CAAI,WACJ,CAAC,YACA,CAAC,2BAsBK,kBACN,CAAC,mBACA,CAAC,iBAUA,aAEC,CAAC,2BAdE,mBACN,CAAC,oBACA,CAAC,iBAUA,oBAKA,CAAC,2BAjBG,aACN,CAAC,cACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,eAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,aACN,CAAC,cACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,eAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,aACN,CAAC,cACA,CAAC,iBAUA,qBAKA,CAAC,6BAjBI,mBACP,CAAC,oBACA,CAAC,iBAUA,eAKA,CAAC,6BAjBI,mBACP,CAAC,oBACA,CAAC,kBAUC,qBAKD,CAAC,6BAjBI,cACP,CAAC,eACA,CAAC,kBAUC,qBAKD,CAAC,eAKL,aACL,CAAO,cAEH,UACJ,CAAI,aAED,SACH,CAAG,qCAMqB,+EAnEJ,qBACb,CAAU,aAChB,CAAQ,4CACH,CAAwC,uBAIrC,cACH,CAAI,WACJ,CAAC,YACA,CAAC,2BAsBK,kBACN,CAAC,mBACA,CAAC,iBAUA,aAEC,CAAC,2BAdE,mBACN,CAAC,oBACA,CAAC,iBAUA,oBAKA,CAAC,2BAjBG,aACN,CAAC,cACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,eAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,aACN,CAAC,cACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,eAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,aACN,CAAC,cACA,CAAC,iBAUA,qBAKA,CAAC,6BAjBI,mBACP,CAAC,oBACA,CAAC,iBAUA,eAKA,CAAC,6BAjBI,mBACP,CAAC,oBACA,CAAC,kBAUC,qBAKD,CAAC,6BAjBI,cACP,CAAC,eACA,CAAC,kBAUC,qBAKD,CAAC,eAKL,aACL,CAAO,cAEH,UACJ,CAAI,aAED,SACH,CAAG,CACX,sCASiC,+EAvEL,qBACb,CAAU,aAChB,CAAQ,4CACH,CAAwC,uBAIrC,cACH,CAAI,WACJ,CAAC,YACA,CAAC,2BAsBK,kBACN,CAAC,mBACA,CAAC,iBAUA,aAEC,CAAC,2BAdE,mBACN,CAAC,oBACA,CAAC,iBAUA,oBAKA,CAAC,2BAjBG,aACN,CAAC,cACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,eAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,aACN,CAAC,cACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,eAKA,CAAC,2BAjBG,mBACN,CAAC,oBACA,CAAC,iBAUA,qBAKA,CAAC,2BAjBG,aACN,CAAC,cACA,CAAC,iBAUA,qBAKA,CAAC,6BAjBI,mBACP,CAAC,oBACA,CAAC,iBAUA,eAKA,CAAC,6BAjBI,mBACP,CAAC,oBACA,CAAC,kBAUC,qBAKD,CAAC,6BAjBI,cACP,CAAC,eACA,CAAC,kBAUC,qBAKD,CAAC,eAKL,aACL,CAAO,cAEH,UACJ,CAAI,aAED,SACH,CAAG,CACX,MAaE,yBAzH0B,CAAO,sBADP,CAAI,wBAEJ,CAAI,MA8H9B,YAEM,CAAI,qBACG,CAAM,6BACL,CAAa,iBAClB,CAAM,iBACR,CAAQ,UACX,CAAI,iCAEC,CAA4B,4BACjC,CAA4B,8CACd,CAA8B,4CACpC,CAAoC,8BAC3C,CAA6B,eAI3B,CAAM,qCAEmB,MAnBhC,eAlI0B,CAAK,CAgLnC,eAvBa,iCAEE,CAA4B,4BACjC,CAA4B,qBACvB,CAAU,QACd,CAAC,QACD,CAAC,eACM,CAAC,qDACY,CAA8B,gCACjD,CAA8B,UAChC,CAAI,qBAEJ,YApKoB,CAAK,SAsKrB,CAAC,mBACK,CAAK,gBACL,CAAK,0BAID,eACN,CAAC,qCCvLmB,YACtB,eCEc,CAAK,CDA7B,qCAHgC,YACtB,eCMc,CAAK,CDJ7B,YATQ,cCiBgB,CAAI,UDftB,CAAI,cAkBF,yBCCgB,CAAO,2BAEP,CAAO,YDHzB,yBCOkB,CAAO,yBACP,CAAO,2BACP,CAAO,oBDSf,yBCLS,CAAO,6BDkBP,4CCbM,CAA0C,MCqB3E,yBArDyB,CAAO,sBACP,CAAI,wBACJ,CAAI,0BACJ,CAAO,uBACP,CAAI,yBACJ,CAAI,2BACJ,CAAO,6BACP,CAAO,2BACP,CAAO,iCACP,CAAO,2BACP,CAAO,mCACP,CAAW,yCACX,CAAW,kDACZ,CAAuB,KAyDhD,iCACU,CAA4B,4BACjC,CAA4B,8CACd,CAA8B,4CACpC,CAAoC,8BAC3C,CAA6B,mEACa,CAA8B,SAM1E,8CAEe,CAA8B,4CACpC,CAAoC,wCAC3C,CAAuC,gCACtC,CAA8B,OAGnC,qBAEQ,CAAU,aACb,CAAK,cACH,CAAI,kBACF,CAAM,eJ9EK,CAAG,0CIiFlB,CAAwC,MAG9C,mEAC+C,CAA8B,aAGtE,oBACD,CAAY,mBAGZ,YACI,CAAI,kBACA,CAAM,sBACF,CAAM,yBACd,cACI,CAAI,WACJ,CAAC,cACA,CAAG,qCAGkB,mBAV9B,mBAWU,CAAO,qBACJ,CAAM,CAEzB,sBAES,YACC,CAAI,mBACA,CAAO,qBACJ,CAAM,4BACb,cACI,CAAI,WACJ,CAAC,cACA,CAAG,sFAM+D,WAC5E,CAAI,gBAGE,4BACM,CAAS,mBACb,CAAI,yFAIoB,uBACpB,CAAI,4KAIwE,qBACpF,CAAU,kCAEV,CAA6B,6BAClC,CAA6B,+CACf,CAA+B,4CACrC,CAAoC,wCAC3C,CAAuC,qEACP,CAA0C,4MAIlE,qCACA,CAA8B,eAChC,CAAI,0OAEQ,uCACV,CAAgC,eAClC,CAAI,kHAEP,sCACG,CAAiC,OAI3C,cACO,CAAI,OAEX,eACM,CAAM,sBACD,CAAQ,iCAGS,uBACZ,CAAI,oBACP,CAAI,eACT,CAAI,iBACN,CAAQ,gDACV,CAA6D,+CAC9D,CAA6D,0BACpD,CAAW,SAClB,CAAC,+DACgE,CAAU,sBACzE,CAAY,+DACP,iBACJ,CAAQ,iCAIJ,eACL,CAAO,sBACH,CAAU,mDACZ,CAA6D,yCACnE,CAA2C,uCAC1C,CAAwC,eAGnC,kBACE,CAAI,8BACH,kBACC,CAAI,UACV,CAAE,iDACN,CAAoD,kDACnD,CAAoD,kCAC9C,CAA6B,YAClC,CAAM,aACL,CAAM,mBAIA,6BACT,CAA6B,kBAErB,6BACR,CAA6B,YAC3B,CAAI,8HAKiH,iBAChH,CAAI,SACT,CAAC,2DAGkD,yBACxC,CAAM,OAGtB,gBACM,CAAO,mBACD,CAAI,0IAKkC,oBAC7C,CAAY,mCACT,CAA8B,8BACnC,CAA8B,gDAChB,CAAgC,4CACtC,CAAoC,qEACX,CAA0C,8BAC1E,CAA6B,oBACpB,CAAI,cACb,CAAO,0BACH,CAAe,4YACX,yCACF,CAAoC,6CAClC,CAAsC,4NAM9B,kBACd,CAAW,WAhRO,CAAI,cAqRrB,YACF,CAAI,sDACQ,CAAsC,4CAC5C,CAAoC,8BAC3C,CAA6B,kKAKW,QACtC,CAAC,cACE,CAAI,aACT,CAAQ,iBACF,CAAM,QACV,CAAC,eACM,CAAC,eACJ,CAAI,iCAEK,2DACK,CAAsC,qCAG/B,cAtBxB,qBAuBO,CAAM,iCACC,QACb,CAAC,0DACgB,CAAsC,CAChE,8HC7SU,2BFyCkB,CAAO,2BAEP,CAAO,oUEjChB,iCFgCS,CAAO,0IE1CvB,2BF+CkB,CAAO,2BAEP,CAAO,4VEvClB,iCFsCW,CAAO,oIEhD1B,2BFqDkB,CAAO,2BAEP,CAAO,gVE7CjB,iCF4CU,CAAO,8HEtD1B,2BF2DkB,CAAO,2BAEP,CAAO,oUEnDhB,8BFkDS,CAAI,kHEjC1B,kFFsCuD,CAA2C,8BACtF,CAA6B,kHEvCzC,+EF2CuD,CAAwC,8BACnF,CAA6B,MGL/C,2BA1Ee,CAAO,iCACD,CAAO,wBACX,CAAI,0BACJ,CAAI,wBACJ,CAAO,8BACN,CAAO,qBACR,CAAI,uBACJ,CAAI,wBACJ,CAAO,wBACP,CAAI,2BACJ,CAAO,0BACP,CAAI,2BACJ,CAAO,2BACP,CAAO,iCAEH,CAAO,0BADX,CAAI,yBAEJ,CAAI,OA8EpB,gBA/Fc,CAAS,mCAiGf,CAA8B,8BACnC,CAA8B,uDAEP,CAAgC,4CAKZ,CAAC,kBAEtC,CAAM,eACP,CAAI,iBACJ,CAAM,WAEb,sBACS,CAAW,aAGpB,8BACI,CAA8B,iBA/FjB,CAAO,mEAiGa,CAAwC,oBAC/D,CAAI,2EAG0C,qBACnD,CAAU,iBACZ,CAAQ,6CACb,CAA+C,qDAC5C,CAA4D,mCACxD,CAA8B,4DAC7B,CAA8D,iBAC/D,CAAM,8BACX,CAA8B,QAC7B,CAAC,eACM,CAAC,QACR,CAAC,wBAES,CAAS,sMAEX,yCACF,CAAoC,IAKnD,gCACW,CAA2B,2BAChC,CAA2B,6CACb,CAA6B,4CACnC,CAAoC,8BAC3C,CAA6B,MAIpC,qEACyC,CAA0C,oBAExE,aACD,CAAK,2BACP,CAA2B,4CACnB,CAAoC,0BACvC,CAAe,gEACX,oBACG,CAAI,sCACT,CAAiC,eAKrC,iBACE,CAAQ,8CACL,CAAgD,sBACrD,iBACI,CAAQ,kEACZ,CAAyF,aAC1F,CAAW,UACP,CAAE,WACH,CAAI,6CACS,CAA6B,aACrC,CAAC,eAVR,iBACE,CAAQ,8CACL,CAAgD,sBACrD,iBACI,CAAQ,kEACZ,CAAyF,aAC1F,CAAW,UACP,CAAE,WACH,CAAI,6CACS,CAA6B,aACrC,CAAC,OAMhB,mCACQ,CAA8B,8BACnC,CAA8B,oDAEV,CAAgC,mEAMT,CAA8B,iBAxK5D,CAAQ,0BA0KhB,8BACH,CAA8B,cAI5B,uBACD,CAAc,eACd,CAAM,YACP,CAAI,KACR,CAAC,cAEK,uBACD,CAAc,eACd,CAAM,YACP,CAAI,QACL,CAAC,sBAID,oBACG,CAAY,iBACX,CAAQ,qBACF,CAAM,yBACb,CAAiB,sBACb,CAAU,eA9LD,CAAK,qCAiMM,gCACE,YACxB,CAAI,CACd,yBAGmB,UACd,CAAG,SACJ,CAAG,WACF,CAAI,eACF,CAAM,iBACN,CAAQ,kBACZ,CAAa,6BACA,CAAW,qBACnB,CAAW,2BACnB,aACQ,CAAK,qBACF,CAAU,cACZ,CAAK,KACV,CAAC,WAhNU,CAAK,YAkNb,CAAK,eACD,CAAI,mCACJ,CAA8B,gDACrB,CAAgC,eACtC,CAAC,QACR,CAAC,YAIA,CAAI,YA3NG,CAAK,qBA8NP,CAAU,yCAMT,iBACH,CAAQ,2BACb,CAA6B,6BAC3B,CAA6B,YAC3B,CAAI,UAtOC,CAAI,WAAJ,CAAI,4CAyOH,CAAoC,gCAC1C,CAA8B,QAC/B,CAAC,cACD,CAAO,0BACH,CAAe,gDACnB,aACG,CAAK,eACL,CAAO,+BACT,CAA+B,iBAC5B,CAAQ,sBACL,CAAU,cAnPX,CAAI,aAqPH,CAAC,iBACF,CAAM,8FAEJ,yCACF,CAAoC,qCAGjB,2BAlDlC,UAmDQ,CAAI,CAEd,mCACY,OAEF,CAAC,qCAMuB,4CACX,eACV,CAAM,WACR,CAAI,YACH,CAAI,0DACE,YACJ,CAAI,CACd,MCjQF,yBA5C0B,CAAI,mCACJ,CAAI,+BACJ,CAAO,4BACP,CAAI,+BACJ,CAAO,4BACP,CAAI,gCAKJ,CAAI,MA4C9B,wBACc,CAAQ,gBACT,CAAC,QACT,CAAC,YACA,CAAI,aACP,CAAQ,kBACH,CAAQ,gCACV,CAA8B,aAC1B,CAAC,cAKP,gBAtEqB,CAAM,0CAwEgB,CAAC,cACtC,CAAI,aACT,CAAQ,wBAEJ,YACD,CAAI,kBACF,CAAQ,+CACE,CAA+B,YAMjD,WACM,CAAG,+EAC+E,CAAC,gEAChE,CAAyC,YAMlE,YACS,CAAC,4CACD,CAAuC,+EACD,CAA8B,SAEhF,YACS,CAAI,SACJ,CAAC,kBAMN,0CACK,CAAwC,SAOjD,eACY,CAAI,uCACJ,CAAgC,kCACrC,CAAgC,SAEvC,uCACY,CAAgC,kCACrC,CAAgC,mDACd,CAA+B,uBAUpB,aAC1B,CAAI,gBAvIY,CAAK,0DAyInB,cACC,CAAI,aACT,CAAQ,0BAEd,kBACW,CAAQ,aACb,CAAQ,oDAEV,WACE,CAAM,eACF,CAAM,sBACD,CAAQ,6BAEpB,eACO,CAAM,KACX,CAAC,+CAEe,YACT,CAAC,iBAGD,QACN,CAAC,8CACG,QACF,CAAC,WACH,CAAM,oBACD,CAAU,uBAElB,aACO,CAAI,6BACG,CAAa,WACxB,CAAM,aACC,CAAC,iDACE,CAAwC,oBAExD,qBACgB,CAAM,aAChB,CAAQ,wCAEV,UACG,CAAI,QACH,CAAC,sDACmB,CAA+B,4EACxC,YACL,CAAC,oBAGf,gBACY,CAAK,oDACS,CAA+B,+DAC9B,CAAyC,sCAGtD,cACE,CAAC,gEAGW,mDACH,CAA+B,wCAEpC,qDACO,CAA+B,oDAC7C,+BACc,CAAO,mDAEtB,kCACkB,CAAO,qDAIxB,8BACa,CAAO,oDAErB,iCACiB,CAAO,qCAMP,uBAER,wBACJ,CAAQ,QACjB,CAAC,UACF,CAAI,aACF,CAAK,gEAEL,QACC,CAAC,UACD,CAAG,SACJ,CAAG,WACF,CAAI,eACF,CAAM,SACP,CAAC,iBACA,CAAQ,kBACZ,CAAa,6BACA,CAAW,qBACnB,CAAW,mCAEnB,QACK,CAAC,uBACA,CAAe,6BAExB,aACS,CAAK,+CACO,CAA+B,4CACrC,CAAoC,kBAIvC,CAAO,gCACV,CAA8B,8BAC/B,CAA6B,+CACtB,CAAuC,0DAElD,UACG,CAAI,6BAEX,aACS,CAAK,QACN,CAAC,gBACG,CAAK,2CAEV,wBACE,CAAiC,UACnC,CAAI,eApQc,CAAG,0GAuQA,YAChB,CAAC,qEAEO,cACN,CAAC,CAChB,MAqDA,gCAtTwB,CAAI,oCA0TR,2CACT,CAAoC,qCAIjB,iCAEZ,2CACL,CAAoC,CACjD,MAMA,qCAtUwB,CAAO,0GA4UrB,6CACK,CAAsC,qCAKvB,0GAIlB,6CACK,CAAsC,CACnD,MClSN,yBAzEoB,CAAO,yBACP,CAAO,KA6E5B,iCACU,CAA4B,4BACjC,CAA4B,eA9EZ,CAAM,eACN,CAAG,4CAgFX,CAAoC,6EACD,CAAwC,kBAI5E,oBACH,CAAY,aAEV,CAAG,eRrFQ,CAAG,mEQwFyB,CAA8B,MAK7E,0BA5FkB,CAAO,0BACP,CAAO,OA+FxB,cACM,CAAK,wCACP,CAAuC,QACzC,CAAG,+BACE,CAAqB,YACvB,CAAI,6BACN,CAA6B,kCACxB,CAA6B,uDAC1B,CAA+C,mEACtB,CAAwC,MAQ7E,4BA5GmB,CAAO,4BACP,CAAO,SA+GvB,iBACI,CAAQ,oBACT,CAAY,+BACJ,iBACL,CAAQ,SACT,CAAC,kBACJ,CAAa,6BACA,CAAW,qBACX,CAAW,mBAClB,CAAQ,YAEX,CAAI,QACP,CAAG,yDAEgC,UACjC,CAAG,6CAEkB,OACxB,CAAG,sFAGS,SACR,CAAC,SACJ,CAAI,2BACS,CAAS,mBACT,CAAS,gBAGtB,UACG,CAAE,sBACC,CAAW,gDACqB,CAAW,wCAEjD,CAAyC,6BAE5B,wBAnJC,CAAO,uBAsJd,2BAtJO,CAAO,eAyJtB,wBACI,CAAgB,+BAClB,CAA+B,oCAC1B,CAA+B,4CAC5B,CAAoC,gCAC1C,CAA8B,kBAI1B,CAAM,0BACR,CAAgB,4BAET,+CACH,CAAuC,sBAE1C,4CACA,CAAuC,MAMlD,sCA3Ke,CAAmB,wBAEf,CAAI,iCACC,CAAO,wBA6Kb,UACb,CAAG,SACJ,CAAG,WACF,CAAI,eACF,CAAM,iBACN,CAAQ,kBACZ,CAAa,6BACA,CAAW,qBACnB,CAAW,4BACf,cACK,CAAK,KACV,CAAC,MACA,CAAC,YACE,CAAI,WACN,CAAK,YACJ,CAAK,qCACD,CAAgC,kCACrC,aACG,CAAM,eACF,CAAI,aACN,CAAI,+CACA,iBACF,CAAQ,KACb,CAAC,OACC,CAAC,aApMQ,CAAO,cAAP,CAAO,4CAuMR,CAAoC,gCAC1C,CAA8B,QAC/B,CAAC,cACD,CAAO,0BACH,CAAe,sDACnB,aACG,CAAK,eACL,CAAO,8BACT,CAA8B,iBAC3B,CAAQ,sBACL,CAAU,iBAjNT,CAAO,aAmNR,CAAC,iBACF,CAAM,0GAEJ,yCACF,CAAyC,oCAK9C,YACJ,CAAI,aACP,CAAQ,YACL,CAAI,uDAEG,YACH,CAAI,MAQhB,mCArOyB,CAAO,mCACP,CAAO,yCACN,CAAO,4CACJ,CAAO,4BACjB,CAAI,qCAEA,CAAO,8CADI,CAAO,UAyOrC,8CACA,CAA8C,SAC5C,CAAC,YACD,CAAI,qBACG,CAAM,8BACd,CAA6B,4CACtB,CAAoC,qDAIT,UAChC,CAAG,SACJ,CAAG,WACF,CAAI,eACF,CAAM,iBACN,CAAQ,kBACZ,CAAa,6BACA,CAAW,qBACnB,CAAW,gBAEf,WACI,CAAC,oBACH,CAAY,aAtQD,CAAM,cAwQlB,CAAO,0BACH,CAAe,sCACpB,CAAsC,2CACjC,CAAsC,kDAC7B,CAAkC,4CAC9C,CAA0C,4CACnC,iDACF,CAA4C,oBAErD,eACS,CAAI,UACR,CAAG,SACJ,CAAG,WACF,CAAI,eACF,CAAM,iBACN,CAAQ,kBACZ,CAAa,6BACA,CAAW,qBACnB,CAAW,0BACV,CAAe,cACf,CAAG,yBAGD,oDACJ,CAA+C,+DAEtC,CAAiD,6BAC/D,qBACO,CAAU,iBACZ,CAAQ,UACX,CAAI,WACH,CAAI,aACF,CAAI,QACN,CAAC,6CACG,CAAwC,kDAC/B,CAAkC,YAC3C,CAAC,gCACJ,CAA8B,SACjC,CAAI,2BACS,CAAS,mBACjB,CAAS,gBA/SE,CAAK,oCAmTD,YAChB,CAAC,8BAEQ,+EACsE,CAAC,iDAEnD,+EACe,CAAoC,2CAE1D,4CACnB,CAAoC,0DAEA,eACpC,CAAC,0CAEqB,+EACmB,CAAoC,eCtVlF,yBNuFiB,CAAO,cMvFzB,yBN2FiB,CAAO,SM7E7B,iENiFqD,CAA8B,iBAC7D,CAAG,MOhE9B,0BArCqB,CAAI,0BACJ,CAAI,SAyCtB,aACG,CAAK,uBACE,CAAQ,uBACJ,CAAI,oBACP,CAAI,eACT,CAAI,aA7CQ,CAAO,8CA+CxB,CAA8C,8BAC7C,CAA6B,QAC7B,CAAC,sDACM,CAA8C,qCAIjD,CAAgC,gCACrC,CAAgC,iCAEd,qCACX,CAAgC,+DACpB,CAA8C,kEAC3C,CAA8C,+BAGpD,qCACT,CAAgC,4BAG1B,qCACN,CAAgC,+DACpB,CAA8C,kEAC3C,CAA8C,+CAGhD,sDACR,CAA8C,0CAE3C,sDACH,CAA8C,gBAGzD,oBACG,CAAY,qBACL,CAAM,SA/EA,CAAG,MAqFtB,yBAhFwB,CAAI,yBACJ,CAAI,8BAoFvB,GACN,sBAAc,CAAY,KACxB,wBAAc,CAAc,CAAA,SAE1B,oBACG,CAAY,8BACb,CAA6B,6CACS,CAAqC,kDAChC,CAAqC,iBACzE,CAAG,aAhGI,CAAO,cAAP,CAAO,iDAmGlB,CAAuC,iBCtGpC,6BRyGc,CAAO,mBQzGnB,6BR6GY,CAAO,kBQ7GpB,6BRiHc,CAAO,iBQlGtB,4BRsGmB,CAAO,mBQtGxB,4BR0GiB,CAAO,kBQ1GzB,4BR8GmB,CAAO,qBSjFb,oBACrB,CAAY,UACb,CAAG,SACJ,CAAG,uBACM,CAAQ,uBACP,CAAO,0CACd,CAAuC,+BACtC,0BACO,CAAW,kBACnB,CAAW,6BAEZ,2BACS,CAAY,mBACpB,CAAY,gBAKV,iYACO,CAAC,mBAEL,mTACI,CAAC,mBAEL,scACI,CAAC,iBAEP,kWACM,CAAC,eAET,oYACQ,CAAC,eAET,maACQ,CAAC,eAET,2YACQ,CAAC,eAET,4WACQ,CAAC,eAET,gYACQ,CAAC,eAET,iWACQ,CAAC,eAET,kYACQ,CAAC,mBAEL,+VACI,CAAC,gBAER,+hBACO,CAAC,cAEV,mXACS,CAAC,iBAEP,kVACM,CAAC,mBAEL,+gCACI,CAAC,gBAER,kfACO,CAAC,eAET,8ZACQ,CAAC,iBAEP,mZACM,CAAC,eAET,yVACQ,CAAC,MC3EjB,sCA/CoB,CAAgB,oGAIuD,CAAmB,QAgD5G,uBACI,CAAe,iBAGV,4BACJ,CAAmB,oBACtB,CAAc,qBACb,CAAc,sBACd,CAAe,mBACf,CAAY,oBACX,CAAY,6BACD,CAAU,wCACC,CAAU,gCAClB,CAAU,0BACvB,CAAiB,UAGpB,4DACgD,CAAU,SAG3D,uDAC8C,CAAU,UAGvD,4BACQ,CAAc,UAGtB,+CACqC,CAAU,mBAGtC,mDACgC,CAAU,qCACvB,mBAFnB,mDAGkC,CAAU,CAK7D,sCAHqC,mBALpB,yCAMwB,CAAU,CAEnD,oBAEkB,qDACiC,CAAU,qCACzB,oBAFlB,qDAGmC,CAAU,CAK/D,sCAHqC,oBALnB,2CAMyB,CAAU,CAErD,qCAEkC,WACvB,uBACC,CAAe,CACzB,6DAEwD,WAC/C,uBACC,CAAe,CACzB,sCAEiC,WACxB,uBACC,CAAe,CACzB,qCAGgC,oBACd,4BACP,CAAmB,oBACtB,CAAc,qBACb,CAAc,sBACd,CAAe,mBACf,CAAY,oBACX,CAAY,6BACD,CAAU,wCACC,CAAU,gCAClB,CAAU,0BACvB,CAAiB,CAC5B,6DAEwD,oBACtC,4BACP,CAAmB,oBACtB,CAAc,qBACb,CAAc,sBACd,CAAe,mBACf,CAAY,oBACX,CAAY,6BACD,CAAU,wCACC,CAAU,gCAClB,CAAU,0BACvB,CAAiB,CAC5B,sCAEiC,oBACf,4BACP,CAAmB,oBACtB,CAAc,qBACb,CAAc,sBACd,CAAe,mBACf,CAAY,oBACX,CAAY,6BACD,CAAU,wCACC,CAAU,gCAClB,CAAU,0BACvB,CAAiB","file":"mini-default.scss","sourcesContent":["/*\r\n  Browsers resets and base typography.\r\n*/\r\n@function rempx ($size) { @return 1px/$size;}   // Keep this, the generator breaks otherwise\r\n// TODO: Add fluid type and test thoroughly\r\n$base-root-font-size:     16px !default;        // Root font sizing for all elements (`px` only)\r\n$_apply-defaults-to-all:  true !default;        // [Hidden] Apply defaults to all elements? (boolean)\r\n$__1px: rempx($base-root-font-size) * 1rem !default;  // [Calculated] Calculated rem value of `1px`\r\n$base-font-family: '-apple-system, BlinkMacSystemFont, \\\"Segoe UI\\\", Roboto, Ubuntu, \\\"Helvetica Neue\\\", Helvetica, sans-serif' !default;                           // Font stack for all elements\r\n$base-line-height:        1.5 !default;         // Line height for most elements\r\n$base-font-size:          1rem !default;        // Font sizing for all elements\r\n$_body-margin:            0 !default;           // [Hidden] Margin for body\r\n$fore-color:              #111 !default;        // Text & foreground color\r\n$secondary-fore-color:    #444 !default;        // Secondary text & foreground color\r\n$back-color:              #f8f8f8 !default;     // Background color\r\n$secondary-back-color:    #f0f0f0 !default;     // Secondary background color\r\n$blockquote-color:        #f57c00 !default;     // <blockquote> sidebar and quotation color\r\n$pre-color:               #1565c0 !default;     // <pre> sidebar color\r\n$border-color:            #aaa !default;        // Border color\r\n$secondary-border-color:  #ddd !default;        // Secondary border color\r\n$heading-line-height:     1.2 !default;         // Line height for headings\r\n$heading-ratio:           1.19 !default;        // Ratio for headings (strictly unitless)\r\n$subheading-font-size:    0.75em !default;      // Font sizing for <small> elements in headings\r\n$subheading-top-margin:   -0.25rem !default;    // Top margin of <small> elements in headings\r\n$universal-margin:        0.5rem !default;      // Universal margin for the most elements\r\n$universal-padding:       0.5rem !default;      // Universal padding for the most elements\r\n$universal-border-radius: 0.125rem !default;    // Universal border-radius for most elements\r\n$universal-box-shadow:    none !default;        // Universal box-shadow for most elements\r\n$small-font-size:         0.75em !default;      // Font sizing for <small> elements\r\n$heading-font-weight:     500 !default;         // Font weight for headings\r\n$bold-font-weight:        700 !default;         // Font weight for <b> and <strong>\r\n$horizontal-rule-line-height:  1.25em !default; // <hr> line height\r\n$blockquote-quotation-size:    3rem !default;   // Font size for the quotation of <blockquote>\r\n$blockquote-cite-size:         0.75em !default; // Font size for the [cite] of <blockquote>\r\n$code-font-family: 'Menlo, Consolas, monospace' !default; // Font stack for code elements\r\n$code-font-size:           0.85em !default;     // Font size for <code>, <kbd>\r\n$small-element-font-size:     0.75em !default;  // Font size for <small>, <sub>, <sup>\r\n$sup-top:                  -0.5em !default;     // <sup> top\r\n$sub-bottom:               -0.25em !default;    // <sub> bottom\r\n$a-link-color:             #0277bd !default;    // Color for <a>:link\r\n$a-visited-color:          #01579b !default;    // Color for <a>:visited\r\n// CSS variable name definitions [exercise caution if modifying these]\r\n$fore-color-var:                '--fore-color' !default;\r\n$secondary-fore-color-var:      '--secondary-fore-color' !default;\r\n$back-color-var:                '--back-color' !default;\r\n$secondary-back-color-var:      '--secondary-back-color' !default;\r\n$blockquote-color-var:          '--blockquote-color' !default;\r\n$pre-color-var:                 '--pre-color' !default;\r\n$border-color-var:              '--border-color' !default;\r\n$secondary-border-color-var:    '--secondary-border-color' !default;\r\n$heading-ratio-var:             '--heading-ratio' !default;\r\n$universal-margin-var:          '--universal-margin' !default;\r\n$universal-padding-var:         '--universal-padding' !default;\r\n$universal-border-radius-var:   '--universal-border-radius' !default;\r\n$universal-box-shadow-var:      '--universal-box-shadow' !default;\r\n$a-link-color-var:              '--a-link-color' !default;\r\n$a-visited-color-var:           '--a-visited-color' !default;\r\n/* Core module CSS variable definitions */\r\n:root {\r\n  #{$fore-color-var}: $fore-color;\r\n  #{$secondary-fore-color-var}: $secondary-fore-color;\r\n  #{$back-color-var}: $back-color;\r\n  #{$secondary-back-color-var}: $secondary-back-color;\r\n  #{$blockquote-color-var}: $blockquote-color;\r\n  #{$pre-color-var}: $pre-color;\r\n  #{$border-color-var}: $border-color;\r\n  #{$secondary-border-color-var}: $secondary-border-color;\r\n  #{$heading-ratio-var}: $heading-ratio;\r\n  #{$universal-margin-var}: $universal-margin;\r\n  #{$universal-padding-var}: $universal-padding;\r\n  #{$universal-border-radius-var}: $universal-border-radius;\r\n  #{$a-link-color-var} : $a-link-color;\r\n  #{$a-visited-color-var} : $a-visited-color;\r\n  @if $universal-box-shadow != none {\r\n    #{$universal-box-shadow-var}: $universal-box-shadow;\r\n  }\r\n}\r\nhtml {\r\n  font-size: $base-root-font-size;  // Set root's font sizing.\r\n}\r\na, b, del, em, i, ins, q, span, strong, u {\r\n  font-size: 1em; // Fix for elements inside headings not displaying properly.\r\n}\r\n\r\n@if $_apply-defaults-to-all {\r\n  html, * {\r\n    font-family: #{$base-font-family};\r\n    line-height: $base-line-height;\r\n    // Prevent adjustments of font size after orientation changes in mobile.\r\n    -webkit-text-size-adjust: 100%;\r\n  }\r\n  * {\r\n    font-size: $base-font-size;\r\n  }\r\n}\r\n@else {\r\n  html {\r\n    font-family:  #{$base-font-family};\r\n    line-height: $base-line-height;\r\n    // Prevent adjustments of font size after orientation changes in mobile.\r\n    -webkit-text-size-adjust: 100%;\r\n  }\r\n}\r\n\r\nbody {\r\n  margin: $_body-margin;\r\n  color: var(#{$fore-color-var});\r\n  background: var(#{$back-color-var});\r\n}\r\n\r\n// Correct display for Edge & Firefox.\r\ndetails {\r\n  display: block;\r\n}\r\n\r\n// Correct display in all browsers.\r\nsummary {\r\n  display: list-item;\r\n}\r\n\r\n// Abbreviations\r\nabbr[title] {\r\n  border-bottom: none;           // Remove bottom border in Firefox 39-.\r\n  text-decoration: underline dotted;  // Opinionated style-fix for all browsers.\r\n}\r\n\r\n// Show overflow in Edge.\r\ninput {\r\n  overflow: visible;\r\n}\r\n\r\n// Make images responsive by default.\r\nimg {\r\n  max-width: 100%;\r\n  height: auto;\r\n}\r\n\r\nh1, h2, h3, h4, h5, h6 {\r\n  line-height: $heading-line-height;\r\n  margin: calc(1.5 * var(#{$universal-margin-var})) var(#{$universal-margin-var});\r\n  font-weight: $heading-font-weight;\r\n  small {\r\n    color: var(#{$secondary-fore-color-var});\r\n    display: block;\r\n    @if $subheading-top-margin != 0 {\r\n      margin-top: $subheading-top-margin;\r\n    }\r\n    @if $subheading-font-size != $small-font-size {\r\n      font-size: $subheading-font-size;\r\n    }\r\n  }\r\n}\r\n\r\nh1 {\r\n  font-size: calc(1rem * var(#{$heading-ratio-var}) * var(#{$heading-ratio-var}) * var(#{$heading-ratio-var}) * var(#{$heading-ratio-var}));\r\n}\r\nh2 {\r\n  font-size: calc(1rem * var(#{$heading-ratio-var}) * var(#{$heading-ratio-var}) * var(#{$heading-ratio-var}));\r\n}\r\nh3 {\r\n  font-size: calc(1rem * var(#{$heading-ratio-var}) * var(#{$heading-ratio-var}));\r\n}\r\nh4 {\r\n  font-size: calc(1rem * var(#{$heading-ratio-var}));\r\n}\r\nh5 {\r\n  font-size: 1rem;\r\n}\r\nh6 {\r\n  font-size: calc(1rem / var(#{$heading-ratio-var}));\r\n}\r\n\r\np {\r\n  margin: var(#{$universal-margin-var});\r\n}\r\n\r\nol, ul {\r\n  margin: var(#{$universal-margin-var});\r\n  padding-left: calc(2 * var(#{$universal-margin-var}));\r\n}\r\n\r\nb, strong {\r\n  font-weight: $bold-font-weight;\r\n}\r\n\r\nhr {\r\n  // Fixes and defaults for styling\r\n  box-sizing: content-box;\r\n  border: 0;\r\n  // Actual styling using variables\r\n  line-height: $horizontal-rule-line-height;\r\n  margin: var(#{$universal-margin-var});\r\n  height: $__1px;\r\n  background: linear-gradient(to right, transparent, var(#{$border-color-var}) 20%, var(#{$border-color-var}) 80%, transparent);\r\n}\r\n\r\nblockquote {  // Doesn't have a back color by default, can be added manually.\r\n  display: block;\r\n  position: relative;\r\n  font-style: italic;\r\n  color: var(#{$secondary-fore-color-var});\r\n  margin: var(#{$universal-margin-var});\r\n  padding: calc(3 * var(#{$universal-padding-var}));\r\n  border: $__1px solid var(#{$secondary-border-color-var});\r\n  border-left: 6*$__1px solid var(#{$blockquote-color-var});\r\n  border-radius: 0 var(#{$universal-border-radius-var}) var(#{$universal-border-radius-var}) 0;\r\n  @if $universal-box-shadow != none {\r\n    box-shadow: var(#{$universal-box-shadow-var});\r\n  }\r\n  &:before {\r\n    position: absolute;\r\n    top: calc(0rem - var(#{$universal-padding-var}));\r\n    left: 0;\r\n    font-family: sans-serif;\r\n    font-size: $blockquote-quotation-size;\r\n    font-weight: 700;\r\n    content: \"\\201c\";\r\n    color: var(#{$blockquote-color-var});\r\n  }\r\n  &[cite]:after{\r\n    font-style: normal;\r\n    font-size: $blockquote-cite-size;\r\n    font-weight: 700;\r\n    content: \"\\a—  \" attr(cite);\r\n    white-space: pre;\r\n  }\r\n}\r\n\r\ncode, kbd, pre, samp {\r\n  font-family: #{$code-font-family};     // Display fix should be applied manually!\r\n  font-size: $code-font-size;\r\n}\r\n\r\ncode { // No border color by default and fore color is the default for text, can be altered manually.\r\n  background: var(#{$secondary-back-color-var});\r\n  border-radius: var(#{$universal-border-radius-var});\r\n  // This could be a bit counterintuitive and burden the codebase a bit, look into it again?\r\n  padding: calc(var(#{$universal-padding-var}) / 4) calc(var(#{$universal-padding-var}) / 2);\r\n  @if $universal-box-shadow != none {\r\n    box-shadow: var(#{$universal-box-shadow-var});\r\n  }\r\n}\r\n\r\nkbd { // No border color by default, can be altered manually.\r\n  background: var(#{$fore-color-var});\r\n  color: var(#{$back-color-var});\r\n  border-radius: var(#{$universal-border-radius-var});\r\n  // This could be a bit counterintuitive and burden the codebase a bit, look into it again?\r\n  padding: calc(var(#{$universal-padding-var}) / 4) calc(var(#{$universal-padding-var}) / 2);\r\n  @if $universal-box-shadow != none {\r\n    box-shadow: var(#{$universal-box-shadow-var});\r\n  }\r\n}\r\n\r\npre { // Fore color is the default, can be altered manually.\r\n  overflow: auto; // Responsiveness\r\n  background: var(#{$secondary-back-color-var});\r\n  padding: calc(1.5 * var(#{$universal-padding-var}));\r\n  margin: var(#{$universal-margin-var});\r\n  border: $__1px solid var(#{$secondary-border-color-var});\r\n  border-left: 4*$__1px solid var(#{$pre-color-var});\r\n  border-radius: 0 var(#{$universal-border-radius-var}) var(#{$universal-border-radius-var}) 0;\r\n  @if $universal-box-shadow != none {\r\n    box-shadow: var(#{$universal-box-shadow-var});\r\n  }\r\n}\r\n\r\n// Prevent elements from affecting the line height in all browsers.\r\nsup, sub, code, kbd {\r\n  line-height: 0;\r\n  position: relative;\r\n  vertical-align: baseline;\r\n}\r\n\r\nsmall, sup, sub, figcaption {\r\n  font-size: $small-element-font-size;\r\n}\r\n\r\nsup {\r\n  top: $sup-top;\r\n}\r\nsub {\r\n  bottom: $sub-bottom;\r\n}\r\n\r\nfigure {\r\n  margin: var(#{$universal-margin-var});\r\n}\r\nfigcaption {\r\n    color: var(#{$secondary-fore-color-var});\r\n}\r\n\r\na {\r\n  text-decoration: none;\r\n  &:link{\r\n    color: var(#{$a-link-color-var});\r\n  }\r\n  &:visited {\r\n    color: var(#{$a-visited-color-var});\r\n  }\r\n  &:hover, &:focus {\r\n    text-decoration: underline;\r\n  }\r\n}\r\n","/*\r\n  Definitions for the grid system, cards and containers.\r\n*/\r\n// The grid system uses the flexbox module, meaning it might be incompatible with certain browsers.\r\n$_include-parent-layout:        true !default;        // [Hidden] Flag for rows defining column layouts (`true`/`false`).\r\n$grid-column-count:            12 !default;           // Number of columns in the grid (integer value only).\r\n$grid-container-name:          'container' !default;  // Class name for the grid system container.\r\n$grid-row-name:                'row' !default;        // Class name for the grid system rows.\r\n$grid-row-parent-layout-prefix:'cols' !default;       // Class name prefix for the grid's row parents.\r\n$grid-column-prefix:           'col' !default;        // Class name prefix for the grid's columns.\r\n$grid-column-offset-suffix:    'offset' !default;     // Class name suffix for the grid's offsets.\r\n$grid-order-normal-suffix:     'normal' !default;     // Class name suffix for grid columns with normal priority.\r\n$grid-order-first-suffix:      'first' !default;      // Class name suffix for grid columns with highest priority.\r\n$grid-order-last-suffix:       'last' !default;       // Class name suffix for grid columns with lowest priorty.\r\n$grid-small-prefix:            'sm' !default;         // Small screen class prefix for grid.\r\n$grid-medium-prefix:           'md' !default;         // Medium screen class prefix for grid.\r\n$grid-large-prefix:            'lg' !default;         // Large screen class prefix for grid.\r\n$grid-medium-breakpoint:       768px !default;        // Medium screen breakpoint for grid.\r\n$grid-large-breakpoint:        1280px !default;       // Large screen breakpoint for grid.\r\n$card-name:                    'card' !default;       // Class name for the cards.\r\n$card-section-name:            'section' !default;    // Class name for the cards' sections.\r\n$card-section-media-name:      'media' !default;      // Class name for the cards' sections (media cotent).\r\n$card-normal-width:            320px !default;        // Width for normal cards.\r\n$card-section-media-height:    200px !default;        // Height for cards' media sections.\r\n$card-fore-color:              #111 !default;         // Text color for the cards.\r\n$card-back-color:              #f8f8f8 !default;      // Background color for the cards.\r\n$card-border-color:            #ddd !default;         // Border color for the cards.\r\n// CSS variable name definitions [exercise caution if modifying these]\r\n$card-fore-color-var:          '--card-fore-color' !default;\r\n$card-back-color-var:          '--card-back-color' !default;\r\n$card-border-color-var:        '--card-border-color' !default;\r\n// == Uncomment below code if this module is used on its own ==\r\n//\r\n// $universal-margin:        0.5rem !default;      // Universal margin for the most elements\r\n// $universal-padding:       0.5rem !default;      // Universal padding for the most elements\r\n// $universal-border-radius: 0.125rem !default;    // Universal border-radius for most elements\r\n// $universal-box-shadow:    none !default;        // Universal box-shadow for most elements\r\n// $universal-margin-var:          '--universal-margin' !default;\r\n// $universal-padding-var:         '--universal-padding' !default;\r\n// $universal-border-radius-var:   '--universal-border-radius' !default;\r\n// $universal-box-shadow-var:      '--universal-box-shadow' !default;\r\n// :root {\r\n//  #{$universal-margin-var}: $universal-margin;\r\n//  #{$universal-padding-var}: $universal-padding;\r\n//  #{$universal-border-radius-var}: $universal-border-radius;\r\n//  @if $universal-box-shadow != none {\r\n//   #{$universal-box-shadow-var}: $universal-box-shadow;\r\n//  }\r\n// }\r\n//\r\n// ============================================================\r\n// Check the `_layout_mixins.scss` file to find this module's mixins.\r\n@import 'layout_mixins';\r\n// Fluid grid system container definition.\r\n.#{$grid-container-name} {\r\n  margin: 0 auto;\r\n  padding: 0 calc(1.5 * var(#{$universal-padding-var}));\r\n}\r\n// Grid row definition.\r\n.#{$grid-row-name} {\r\n  box-sizing: border-box;\r\n  display: flex;\r\n  flex: 0 1 auto;\r\n  flex-flow: row wrap;\r\n}\r\n// Inline mixin, used to generate class definitions for each grid step.\r\n@mixin generate-grid-size ($size-prefix){\r\n  @if $_include-parent-layout {\r\n    .#{$grid-column-prefix}-#{$size-prefix},\r\n    [class^='#{$grid-column-prefix}-#{$size-prefix}-'],\r\n    [class^='#{$grid-column-prefix}-#{$size-prefix}-#{$grid-column-offset-suffix}-'],\r\n    .#{$grid-row-name}[class*='#{$grid-row-parent-layout-prefix}-#{$size-prefix}-'] > * {\r\n      box-sizing: border-box;\r\n      flex: 0 0 auto;\r\n      padding: 0 calc(var(#{$universal-padding-var}) / 2);\r\n    }\r\n    // Grid column specific definition for flexible column.\r\n    .#{$grid-column-prefix}-#{$size-prefix},\r\n    .#{$grid-row-name}.#{$grid-row-parent-layout-prefix}-#{$size-prefix} > *  {\r\n      max-width: 100%;\r\n      flex-grow: 1;\r\n      flex-basis: 0;\r\n    }\r\n  }\r\n  @else {\r\n    // Grid column generic definitions.\r\n    .#{$grid-column-prefix}-#{$size-prefix},\r\n    [class^='#{$grid-column-prefix}-#{$size-prefix}-'],\r\n    [class^='#{$grid-column-prefix}-#{$size-prefix}-#{$grid-column-offset-suffix}-'] {\r\n      flex: 0 0 auto;\r\n      padding: 0 calc(var(#{$universal-padding-var}) / 2);\r\n    }\r\n    // Grid column specific definition for flexible column.\r\n    .#{$grid-column-prefix}-#{$size-prefix} {\r\n      max-width: 100%;\r\n      flex-grow: 1;\r\n      flex-basis: 0;\r\n    }\r\n  }\r\n  // Grid column specific definitions for predefined columns.\r\n  @for $i from 1 through $grid-column-count {\r\n    @if $_include-parent-layout {\r\n      .#{$grid-column-prefix}-#{$size-prefix}-#{$i},\r\n      .#{$grid-row-name}.#{$grid-row-parent-layout-prefix}-#{$size-prefix}-#{$i} > * {\r\n        max-width: #{($i * 100% / $grid-column-count)};\r\n        flex-basis: #{($i * 100% / $grid-column-count)};\r\n      }\r\n    }\r\n    @else {\r\n      .#{$grid-column-prefix}-#{$size-prefix}-#{$i} {\r\n        max-width: #{($i * 100% / $grid-column-count)};\r\n        flex-basis: #{($i * 100% / $grid-column-count)};\r\n      }\r\n    }\r\n    // Offest definitions.\r\n    .#{$grid-column-prefix}-#{$size-prefix}-#{$grid-column-offset-suffix}-#{($i - 1)} {\r\n      @if ($i - 1) == 0 {\r\n        margin-left: 0;\r\n      }\r\n      @else {\r\n        margin-left: #{(($i - 1) * 100% / $grid-column-count)};\r\n      }\r\n    }\r\n  }\r\n  // Reordering definitions.\r\n  .#{$grid-column-prefix}-#{$size-prefix}-#{$grid-order-normal-suffix} {\r\n    order: initial;\r\n  }\r\n  .#{$grid-column-prefix}-#{$size-prefix}-#{$grid-order-first-suffix}  {\r\n    order: -999;\r\n  }\r\n  .#{$grid-column-prefix}-#{$size-prefix}-#{$grid-order-last-suffix} {\r\n    order: 999;\r\n  }\r\n}\r\n// Definitions for smaller screens.\r\n@include generate-grid-size($grid-small-prefix);\r\n// Definitions for medium screens.\r\n@media screen and (min-width: #{$grid-medium-breakpoint}){\r\n  @include generate-grid-size($grid-medium-prefix);\r\n}\r\n// Definitions for large screens.\r\n@media screen and (min-width: #{$grid-large-breakpoint}){\r\n  @include generate-grid-size($grid-large-prefix);\r\n}\r\n/* Card component CSS variable definitions */\r\n:root {\r\n  #{$card-back-color-var}: $card-back-color;\r\n  #{$card-fore-color-var}: $card-fore-color;\r\n  #{$card-border-color-var}: $card-border-color;\r\n}\r\n// Card styling\r\n.#{$card-name} {\r\n  // New syntax\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: space-between;\r\n  align-self: center;\r\n  position: relative;\r\n  width: 100%;\r\n  // Actual styling for the cards\r\n  background: var(#{$card-back-color-var});\r\n  color: var(#{$card-fore-color-var});\r\n  border: $__1px solid var(#{$card-border-color-var});\r\n  border-radius: var(#{$universal-border-radius-var});\r\n  margin: var(#{$universal-margin-var});\r\n  @if $universal-box-shadow != none {\r\n    box-shadow: var(#{$universal-box-shadow-var});\r\n  }\r\n  overflow: hidden;   // Hide overflow from section borders\r\n  // Responsiveness (if the screen is larger than card, set max-width)\r\n  @media screen and (min-width: #{$card-normal-width}) {\r\n    max-width: $card-normal-width;\r\n  }\r\n  // Card sections\r\n  & > .#{$card-section-name} {\r\n    // Reapply background and foreground colors, so that mixins can be applied properly.\r\n    background: var(#{$card-back-color-var});\r\n    color: var(#{$card-fore-color-var});\r\n    box-sizing: border-box;\r\n    margin: 0;\r\n    border: 0;        // Clean borders and radiuses for any element-based sections\r\n    border-radius: 0; // Clean borders and radiuses for any element-based sections\r\n    border-bottom: $__1px solid var(#{$card-border-color-var});\r\n    padding: var(#{$universal-padding-var});\r\n    width: 100%;\r\n    // Card media sections\r\n    &.#{$card-section-media-name} {\r\n      height: $card-section-media-height;\r\n      padding: 0;\r\n      -o-object-fit: cover;\r\n         object-fit: cover;\r\n    }\r\n  }\r\n  // Card sections - last\r\n  & > .#{$card-section-name}:last-child {\r\n    border-bottom: 0;  // Clean the extra border for last section\r\n  }\r\n}\r\n","// Layout (card) module's mixin definitions are here. For the module itself\r\n// check `_layout.scss`.\r\n// Mixin for alternate card sizes:\r\n//  $card-alt-size-name: The name of the class used for the alternate size card.\r\n//  $card-alt-size-width: The width of the alternate size card.\r\n@mixin make-card-alt-size ($card-alt-size-name, $card-alt-size-width) {\r\n  @if type-of($card-alt-size-width) == 'number' and unit($card-alt-size-width) == '%' {\r\n    .#{$card-name}.#{$card-alt-size-name} {\r\n      max-width: $card-alt-size-width;\r\n      width: auto;\r\n    }\r\n  }\r\n  @else {\r\n    @media screen and (min-width: #{$card-alt-size-width}) {\r\n      .#{$card-name}.#{$card-alt-size-name} {\r\n        max-width: $card-alt-size-width;\r\n      }\r\n    }\r\n  }\r\n}\r\n// Mixin for alternate cards (card color variants):\r\n//  $card-alt-name: The name of the class used for the alternate card.\r\n//  $card-alt-back-color: The background color of the alternate card.\r\n//  $card-alt-fore-color: The text color of the alternate card.\r\n//  $card-alt-border-color: The border style of the alternate card.\r\n@mixin make-card-alt-color ($card-alt-name, $card-alt-back-color : $card-back-color,\r\n  $card-alt-fore-color : $card-fore-color, $card-alt-border-color : $card-border-color) {\r\n  .#{$card-name}.#{$card-alt-name} {\r\n    @if $card-alt-back-color != $card-back-color {\r\n      #{$card-back-color-var}: $card-alt-back-color;\r\n    }\r\n    @if $card-alt-fore-color != $card-fore-color {\r\n      #{$card-fore-color-var}: $card-alt-fore-color;\r\n    }\r\n    @if $card-alt-border-color != $card-border-color {\r\n      #{$card-border-color-var}: $card-alt-border-color;\r\n    }\r\n  }\r\n}\r\n// Mixin for alternate card sections (card section color variants):\r\n//  $card-section-alt-name: The name of the class used for the alternate card section.\r\n//  $card-section-alt-back-color: The background color of the alternate card section.\r\n//  $card-section-alt-fore-color: The text color of the alternate card section.\r\n@mixin make-card-section-alt-color ($card-section-alt-name, $card-section-alt-back-color : $card-back-color,\r\n  $card-section-alt-fore-color : $card-fore-color) {\r\n  .#{$card-name} > .#{$card-section-name}.#{$card-section-alt-name} {\r\n    @if $card-section-alt-back-color != $card-back-color {\r\n      #{$card-back-color-var}: $card-section-alt-back-color;\r\n    }\r\n    @if $card-section-alt-fore-color != $card-fore-color {\r\n      #{$card-fore-color-var}: $card-section-alt-fore-color;\r\n    }\r\n  }\r\n}\r\n// Mixin for alternate card sections (card section padding variants):\r\n//  $card-section-alt-name: The name of the class used for the alternate card section.\r\n//  $card-section-alt-padding: The padding of the alternate card section.\r\n@mixin make-card-section-alt-style ($card-section-alt-name, $card-section-alt-padding) {\r\n  .#{$card-name} > .#{$card-section-name}.#{$card-section-alt-name} {\r\n    padding: $card-section-alt-padding;\r\n  }\r\n}\r\n","//  This is a flavor file. Duplicate it and edit it to create your own flavor. Read instructions carefully.\r\n//  Single-line comments, starting with '//' will not be included in your final CSS file. Multiline comments,\r\n//  structured like the flavor description below, will be included in your final CSS file.\r\n/*\r\n  Flavor name: Default (mini-default)\r\n  Author: Angelos Chalaris (chalarangelo@gmail.com)\r\n  Maintainers: Angelos Chalaris\r\n  mini.css version: v3.0.1\r\n*/\r\n@import '../mini/core';\r\n@import '../mini/layout';\r\n\r\n/*\r\n  Custom elements for card elements.\r\n*/\r\n$card-small-name:              'small';            // Class name for small cards.\r\n$card-small-width:             240px;              // Width for small cards.\r\n@include make-card-alt-size ($card-small-name, $card-small-width);\r\n\r\n$card-large-name:              'large';            // Class name for large cards.\r\n$card-large-width:             480px;              // Width for large cards.\r\n@include make-card-alt-size ($card-large-name, $card-large-width);\r\n\r\n$card-fluid-name:              'fluid';            // Class name for fluid cards.\r\n$card-fluid-width:             100%;               // Width for fluid cards.\r\n@include make-card-alt-size ($card-fluid-name, $card-fluid-width);\r\n\r\n$card-warning-name:            'warning';          // Class name for card warnging color variant.\r\n$card-warning-back-color:      #ffca28;            // Background color for card warnging color variant.\r\n$card-warning-fore-color:      #111;               // Text color for card warnging color variant.\r\n$card-warning-border-color:    #e8b825;            // Border style for card warnging color variant.\r\n@include make-card-alt-color ($card-warning-name, $card-warning-back-color, $card-warning-fore-color, $card-warning-border-color);\r\n\r\n$card-error-name:              'error';            // Class name for card error color variant.\r\n$card-error-back-color:        #b71c1c;            // Background color for card error color variant.\r\n$card-error-fore-color:        #f8f8f8;            // Text color for card error color variant.\r\n$card-error-border-color:      #a71a1a;            // Border style for card error color variant.\r\n@include make-card-alt-color ($card-error-name, $card-error-back-color, $card-error-fore-color, $card-error-border-color);\r\n\r\n$card-section-dark-name:        'dark';            // Class name for card dark section variant.\r\n$card-section-dark-back-color:  #e0e0e0;           // Background color for card dark section variant.\r\n$card-section-dark-fore-color:  #111;              // Text color for card dark section variant.\r\n@include make-card-section-alt-color ($card-section-dark-name, $card-section-dark-back-color, $card-section-dark-fore-color);\r\n\r\n$card-section-double-padded-name:    'double-padded';   // Class name for card double-padded section variant.\r\n$card-section-double-padded-padding:  calc(1.5 * var(#{$universal-padding-var}));  // Padding for card sectiondouble-padded section variant.\r\n@include make-card-section-alt-style ($card-section-double-padded-name, $card-section-double-padded-padding);\r\n\r\n@import '../mini/input_control';\r\n\r\n/*\r\n  Custom elements for forms and input elements.\r\n*/\r\n$button-primary-name:            'primary';   // Class name for primary button color variant.\r\n$button-primary-back-color:      #1976d2;     // Background color for primary button color variant.\r\n$button-primary-hover-back-color:#1565c0;     // Background color for primary button color variant (hover).\r\n$button-primary-fore-color:      #f8f8f8;     // Text color for primary button color variant.\r\n@include make-button-alt-color ($button-primary-name, $button-primary-back-color, $button-primary-hover-back-color, $button-primary-fore-color);\r\n\r\n$button-secondary-name:            'secondary'; // Class name for secondary button color variant.\r\n$button-secondary-back-color:      #d32f2f;     // Background color for secondary button color variant.\r\n$button-secondary-hover-back-color:#c62828;     // Background color for secondary button color variant (hover).\r\n$button-secondary-fore-color:      #f8f8f8;     // Text color for secondary button color variant.\r\n@include make-button-alt-color ($button-secondary-name, $button-secondary-back-color, $button-secondary-hover-back-color, $button-secondary-fore-color);\r\n\r\n$button-tertiary-name:            'tertiary';  // Class name for tertiary button color variant.\r\n$button-tertiary-back-color:      #308732;     // Background color for tertiary button color variant.\r\n$button-tertiary-hover-back-color:#277529;     // Background color for tertiary button color variant (hover).\r\n$button-tertiary-fore-color:      #f8f8f8;     // Text color for tertiary button color variant.\r\n@include make-button-alt-color ($button-tertiary-name, $button-tertiary-back-color, $button-tertiary-hover-back-color, $button-tertiary-fore-color);\r\n\r\n$button-inverse-name:            'inverse';   // Class name for inverse button color variant.\r\n$button-inverse-back-color:      #212121;     // Background color for inverse button color variant.\r\n$button-inverse-hover-back-color:#111;        // Background color for inverse button color variant (hover).\r\n$button-inverse-fore-color:      #f8f8f8;     // Text color for inverse button color variant.\r\n@include make-button-alt-color ($button-inverse-name, $button-inverse-back-color, $button-inverse-hover-back-color, $button-inverse-fore-color);\r\n\r\n$button-small-name:    'small';              // Class name, padding and margin for small button size variant.\r\n$button-small-padding: calc(0.5 * var(#{$universal-padding-var})) calc(0.75 * var(#{$universal-padding-var}));\r\n$button-small-margin:  var(#{$universal-margin-var});\r\n@include make-button-alt-size ($button-small-name, $button-small-padding, $button-small-margin);\r\n\r\n$button-large-name:    'large';              // Class name, padding and margin for large button size variant.\r\n$button-large-padding: calc(1.5 * var(#{$universal-padding-var})) calc(2 * var(#{$universal-padding-var}));\r\n$button-large-margin:  var(#{$universal-margin-var});\r\n@include make-button-alt-size ($button-large-name, $button-large-padding, $button-large-margin);\r\n\r\n@import '../mini/navigation';\r\n@import '../mini/table';\r\n@import '../mini/contextual';\r\n\r\n/*\r\n  Custom elements for contextual background elements, toasts and tooltips.\r\n*/\r\n$mark-secondary-name:            'secondary'; // Class name for secondary <mark> color variant.\r\n$mark-secondary-back-color:      #d32f2f;     // Background color for secondary <mark> color variant.\r\n@include make-mark-alt-color ($mark-secondary-name, $mark-secondary-back-color);\r\n\r\n$mark-tertiary-name:            'tertiary';  // Class name for tertiary <mark> color variant.\r\n$mark-tertiary-back-color:      #308732;     // Background color for tertiary <mark> color variant.\r\n@include make-mark-alt-color ($mark-tertiary-name, $mark-tertiary-back-color);\r\n\r\n$mark-tag-name:                 'tag';       // Class name, padding and border radius for tag <mark> size variant.\r\n$mark-tag-padding:      calc(var(#{$universal-padding-var})/2) var(#{$universal-padding-var});\r\n$mark-tag-border-radius:        1em;\r\n@include make-mark-alt-size ($mark-tag-name, $mark-tag-padding, $mark-tag-border-radius);\r\n\r\n@import '../mini/progress';\r\n\r\n/*\r\n  Custom elements for progress bars and spinners.\r\n*/\r\n$progress-primary-name:         'primary';   // Class name for primary <progress> color variant.\r\n$progress-primary-fore-color:   #1976d2;     // Foreground color for primary <progress> color variant.\r\n@include make-progress-alt-color ($progress-primary-name, $progress-primary-fore-color);\r\n\r\n$progress-secondary-name:     'secondary';   // Class name for secondary <progress> color variant.\r\n$progress-secondary-fore-color: #d32f2f;     // Foreground color for secondary <progress> color variant.\r\n@include make-progress-alt-color ($progress-secondary-name, $progress-secondary-fore-color);\r\n\r\n$progress-tertiary-name:       'tertiary';   // Class name for tertiary <progress> color variant.\r\n$progress-tertiary-fore-color:   #308732;    // Foreground color for tertiary <progress> color variant.\r\n@include make-progress-alt-color ($progress-tertiary-name, $progress-tertiary-fore-color);\r\n\r\n$spinner-donut-primary-name:         'primary';   // Class name for primary spinner donutcolor variant.\r\n$spinner-donut-primary-fore-color:   #1976d2;     // Foreground color for primary spinner donut color variant.\r\n@include make-spinner-donut-alt-color ($spinner-donut-primary-name, $spinner-donut-primary-fore-color);\r\n\r\n$spinner-donut-secondary-name:     'secondary';   // Class name for secondary spinner donut color variant.\r\n$spinner-donut-secondary-fore-color: #d32f2f;     // Foreground color for secondary spinner donut color variant.\r\n@include make-spinner-donut-alt-color ($spinner-donut-secondary-name, $spinner-donut-secondary-fore-color);\r\n\r\n$spinner-donut-tertiary-name:       'tertiary';   // Class name for tertiary spinner donut color variant.\r\n$spinner-donut-tertiary-fore-color:   #308732;    // Foreground color for tertiary spinner donut color variant.\r\n@include make-spinner-donut-alt-color ($spinner-donut-tertiary-name, $spinner-donut-tertiary-fore-color);\r\n\r\n@import '../mini/icon';\r\n@import '../mini/utility';\r\n","/*\r\n  Definitions for forms and input elements.\r\n*/\r\n// Different elements are styled based on the same set of rules.\r\n$input-group-name:           'input-group' !default;  // Class name for input groups.\r\n$_include-fluid-input-group: true !default;           // [Hidden] Should fluid input groups be included? (boolean)\r\n$input-group-fluid-name:     'fluid' !default;        // Class name for fluid input groups.\r\n$input-group-vertical-name:  'vertical' !default;     // Class name for vertical input groups.\r\n$input-group-mobile-breakpoint:   767px !default;     // Breakpoint for fluid input group mobile view.\r\n$button-class-name:           'button' !default;      // Class name for elements styled as buttons.\r\n$input-disabled-opacity:      0.75 !default;          // Opacity for input elements when disabled.\r\n$button-group-name:         'button-group' !default;  // Class name for button groups.\r\n$button-group-mobile-breakpoint: 767px !default;      // Mobile breakpoint for button groups.\r\n$form-back-color:             #f0f0f0 !default;       // Background color for forms.\r\n$form-fore-color:             #111 !default;          // Text color for forms.\r\n$form-border-color:           #ddd !default;          // Border color for forms.\r\n$input-back-color:            #f8f8f8 !default;       // Background color for input elements.\r\n$input-fore-color:            #111 !default;          // Text color for input elements.\r\n$input-border-color:          #ddd !default;          // Border color for input elements.\r\n$input-focus-color:           #0288d1 !default;       // Border color for focused input elements.\r\n$input-invalid-color:         #d32f2f !default;       // Border color for invalid input elements.\r\n$button-back-color:           #e2e2e2 !default;       // Background color for buttons.\r\n$button-hover-back-color:     #dcdcdc !default;       // Background color for buttons (hover).\r\n$button-fore-color:           #212121 !default;       // Text color for buttons.\r\n$button-border-color:         transparent !default;   // Border color for buttons.\r\n$button-hover-border-color:   transparent !default;   // Border color for buttons (hover).\r\n$button-group-border-color:  rgba(124,124,124, 0.54) !default;  // Border color for button groups.\r\n// CSS variable name definitions [exercise caution if modifying these]\r\n$form-back-color-var:         '--form-back-color' !default;\r\n$form-fore-color-var:         '--form-fore-color' !default;\r\n$form-border-color-var:       '--form-border-color' !default;\r\n$input-back-color-var:        '--input-back-color' !default;\r\n$input-fore-color-var:        '--input-fore-color' !default;\r\n$input-border-color-var:      '--input-border-color' !default;\r\n$input-focus-color-var:       '--input-focus-color' !default;\r\n$input-invalid-color-var:     '--input-invalid-color' !default;\r\n$button-back-color-var:       '--button-back-color' !default;\r\n$button-hover-back-color-var: '--button-hover-back-color' !default;\r\n$button-fore-color-var:       '--button-fore-color' !default;\r\n$button-border-color-var:       '--button-border-color' !default;\r\n$button-hover-border-color-var: '--button-hover-border-color' !default;\r\n$button-group-border-color-var: '--button-group-border-color' !default;\r\n// == Uncomment below code if this module is used on its own ==\r\n//\r\n// $base-font-size:          1rem !default;        // Font sizing for all elements\r\n// $universal-margin:        0.5rem !default;      // Universal margin for the most elements\r\n// $universal-padding:       0.5rem !default;      // Universal padding for the most elements\r\n// $universal-border-radius: 0.125rem !default;    // Universal border-radius for most elements\r\n// $universal-box-shadow:    none !default;        // Universal box-shadow for most elements\r\n// $universal-margin-var:          '--universal-margin' !default;\r\n// $universal-padding-var:         '--universal-padding' !default;\r\n// $universal-border-radius-var:   '--universal-border-radius' !default;\r\n// $universal-box-shadow-var:      '--universal-box-shadow' !default;\r\n// :root {\r\n//  #{$universal-margin-var}: $universal-margin;\r\n//  #{$universal-padding-var}: $universal-padding;\r\n//  #{$universal-border-radius-var}: $universal-border-radius;\r\n//  @if $universal-box-shadow != none {\r\n//   #{$universal-box-shadow-var}: $universal-box-shadow;\r\n//  }\r\n// }\r\n//\r\n// ============================================================\r\n// Check the `_input_control_mixins.scss` file to find this module's mixins.\r\n@import 'input_control_mixins';\r\n/* Input_control module CSS variable definitions */\r\n:root {\r\n  #{$form-back-color-var}: $form-back-color;\r\n  #{$form-fore-color-var}: $form-fore-color;\r\n  #{$form-border-color-var}: $form-border-color;\r\n  #{$input-back-color-var}: $input-back-color;\r\n  #{$input-fore-color-var}: $input-fore-color;\r\n  #{$input-border-color-var}: $input-border-color;\r\n  #{$input-focus-color-var}: $input-focus-color;\r\n  #{$input-invalid-color-var}: $input-invalid-color;\r\n  #{$button-back-color-var}: $button-back-color;\r\n  #{$button-hover-back-color-var}: $button-hover-back-color;\r\n  #{$button-fore-color-var}: $button-fore-color;\r\n  #{$button-border-color-var}: $button-border-color;\r\n  #{$button-hover-border-color-var}: $button-hover-border-color;\r\n  #{$button-group-border-color-var}: $button-group-border-color;\r\n}\r\n// Base form styling\r\nform {  // Text color is the default, this can be changed manually.\r\n  background: var(#{$form-back-color-var});\r\n  color: var(#{$form-fore-color-var});\r\n  border: $__1px solid var(#{$form-border-color-var});\r\n  border-radius: var(#{$universal-border-radius-var});\r\n  margin: var(#{$universal-margin-var});\r\n  padding: calc(2 * var(#{$universal-padding-var})) var(#{$universal-padding-var});\r\n  @if $universal-box-shadow != none {\r\n    box-shadow: var(#{$universal-box-shadow-var});\r\n  }\r\n}\r\n// Fieldset styling\r\nfieldset {\r\n  // Apply always to overwrite defaults for all of the below.\r\n  border: $__1px solid var(#{$form-border-color-var});\r\n  border-radius: var(#{$universal-border-radius-var});\r\n  margin: calc(var(#{$universal-margin-var}) / 4);\r\n  padding: var(#{$universal-padding-var});\r\n}\r\n// Legend styling.\r\nlegend {\r\n  // Edge fixes.\r\n  box-sizing: border-box;\r\n  display: table;\r\n  max-width: 100%;\r\n  white-space: normal;\r\n  // Actual styling.\r\n  font-weight: $bold-font-weight;\r\n  padding: calc(var(#{$universal-padding-var}) / 2);\r\n}\r\n// Label syling. - Basically just padding, but there might be more in the future.\r\nlabel {\r\n  padding: calc(var(#{$universal-padding-var}) / 2) var(#{$universal-padding-var});\r\n}\r\n// Input group styling.\r\n.#{$input-group-name} {\r\n  display: inline-block;\r\n  // Fluid input groups\r\n  @if $_include-fluid-input-group {\r\n    &.#{$input-group-fluid-name} {\r\n      display: flex;\r\n      align-items: center;\r\n      justify-content: center;\r\n      & > input {\r\n        max-width: 100%;\r\n        flex-grow: 1;\r\n        flex-basis: 0px;\r\n      }\r\n      // On mobile\r\n      @media screen and (max-width: #{$input-group-mobile-breakpoint}) {\r\n        align-items: stretch;\r\n        flex-direction: column;\r\n      }\r\n    }\r\n    // Vertical input groups\r\n    &.#{$input-group-vertical-name} {\r\n      display: flex;\r\n      align-items: stretch;\r\n      flex-direction: column;\r\n      & > input {\r\n        max-width: 100%;\r\n        flex-grow: 1;\r\n        flex-basis: 0px;\r\n      }\r\n    }\r\n  }\r\n}\r\n// Correct the cursor style of increment and decrement buttons in Chrome.\r\n[type=\"number\"]::-webkit-inner-spin-button, [type=\"number\"]::-webkit-outer-spin-button {\r\n  height: auto;\r\n}\r\n// Correct style in Chrome and Safari.\r\n[type=\"search\"] {\r\n  -webkit-appearance: textfield;\r\n  outline-offset: -2px;\r\n}\r\n// Correct style in Chrome and Safari.\r\n[type=\"search\"]::-webkit-search-cancel-button,\r\n[type=\"search\"]::-webkit-search-decoration {\r\n  -webkit-appearance: none;\r\n}\r\n// Common textual input styling. - Avoid using box-shadow with these.\r\ninput:not([type]), [type=\"text\"], [type=\"email\"], [type=\"number\"], [type=\"search\"],\r\n[type=\"password\"], [type=\"url\"], [type=\"tel\"], [type=\"checkbox\"], [type=\"radio\"], textarea, select {\r\n  box-sizing: border-box;\r\n  // Background, color and border should not be unassigned, as the browser defaults will apply.\r\n  background: var(#{$input-back-color-var});\r\n  color: var(#{$input-fore-color-var});\r\n  border: $__1px solid var(#{$input-border-color-var});\r\n  border-radius: var(#{$universal-border-radius-var});\r\n  margin: calc(var(#{$universal-margin-var}) / 2);\r\n  padding: var(#{$universal-padding-var}) calc(1.5 * var(#{$universal-padding-var}));\r\n}\r\n// Hover, focus, disabled, readonly, invalid styling for common textual inputs.\r\ninput:not([type=\"button\"]):not([type=\"submit\"]):not([type=\"reset\"]), textarea, select {\r\n  &:hover, &:focus {\r\n    border-color: var(#{$input-focus-color-var});\r\n    box-shadow: none;\r\n  }\r\n  &:invalid, &:focus:invalid{\r\n    border-color: var(#{$input-invalid-color-var});\r\n    box-shadow: none;\r\n  }\r\n  &[readonly]{\r\n    background: var(#{$secondary-back-color-var});\r\n  }\r\n}\r\n// Fix for select and option elements overflowing their parent container.\r\nselect {\r\n  max-width: 100%;\r\n}\r\noption {\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n}\r\n// Styling for checkboxes and radio buttons.\r\n[type=\"checkbox\"], [type=\"radio\"] {\r\n  -webkit-appearance: none;\r\n  -moz-appearance: none;\r\n  appearance: none;\r\n  position: relative;\r\n  height: calc(#{$base-font-size} + var(#{$universal-padding-var}) / 2);\r\n  width: calc(#{$base-font-size} + var(#{$universal-padding-var}) / 2);\r\n  vertical-align: text-bottom;\r\n  padding: 0; // Remove padding added from previous styles.\r\n  flex-basis: calc(#{$base-font-size} + var(#{$universal-padding-var}) / 2) !important; // Override fluid input-group styling.\r\n  flex-grow: 0 !important;  // Using with fluid input-groups is not recommended.\r\n  &:checked:before {\r\n    position: absolute;\r\n  }\r\n}\r\n[type=\"checkbox\"] {\r\n  &:checked:before {\r\n    content: '\\2713';\r\n    font-family: sans-serif;\r\n    font-size: calc(#{$base-font-size} + var(#{$universal-padding-var}) / 2);\r\n    top: calc(0rem - var(#{$universal-padding-var}));\r\n    left: calc(var(#{$universal-padding-var}) / 4);\r\n  }\r\n}\r\n[type=\"radio\"] {\r\n  border-radius: 100%;\r\n  &:checked:before {\r\n    border-radius: 100%;\r\n    content: '';\r\n    top: calc(#{$__1px} + var(#{$universal-padding-var}) / 2);\r\n    left: calc(#{$__1px} + var(#{$universal-padding-var}) / 2);\r\n    background: var(#{$input-fore-color-var});\r\n    width: 0.5rem;\r\n    height: 0.5rem;\r\n  }\r\n}\r\n// Placeholder styling (keep browser-specific definitions separated, they do not play well together).\r\n:placeholder-shown {\r\n  color: var(#{$input-fore-color-var});\r\n}\r\n::-ms-placeholder {\r\n  color: var(#{$input-fore-color-var});\r\n  opacity: 0.54;\r\n}\r\n// Definitions for the button and button-like elements.\r\n// Different elements are styled based on the same set of rules.\r\n// Reset for Firefox focusing on button elements.\r\nbutton::-moz-focus-inner, [type=\"button\"]::-moz-focus-inner, [type=\"reset\"]::-moz-focus-inner, [type=\"submit\"]::-moz-focus-inner {\r\n  border-style: none;\r\n  padding: 0;\r\n}\r\n// Fixes for Android 4, iOS and Safari.\r\nbutton, html [type=\"button\"], [type=\"reset\"], [type=\"submit\"] {\r\n  -webkit-appearance: button;\r\n}\r\n// Other fixes.\r\nbutton {\r\n  overflow: visible;      // Show the overflow in IE.\r\n  text-transform: none;    // Remove inheritance of text-transform in Edge, Firefox, and IE.\r\n}\r\n// Default styling\r\nbutton, [type=\"button\"], [type=\"submit\"], [type=\"reset\"],\r\na.#{$button-class-name}, label.#{$button-class-name}, .#{$button-class-name},\r\na[role=\"button\"], label[role=\"button\"], [role=\"button\"] {\r\n  display: inline-block;\r\n  background: var(#{$button-back-color-var});\r\n  color: var(#{$button-fore-color-var});\r\n  border: $__1px solid var(#{$button-border-color-var});\r\n  border-radius: var(#{$universal-border-radius-var});\r\n  padding: var(#{$universal-padding-var}) calc(1.5 * var(#{$universal-padding-var}));\r\n  margin: var(#{$universal-margin-var});\r\n  text-decoration: none;\r\n  cursor: pointer;\r\n  transition: background 0.3s;\r\n  &:hover, &:focus {\r\n    background: var(#{$button-hover-back-color-var});\r\n    border-color: var(#{$button-hover-border-color-var});\r\n  }\r\n}\r\n// Disabled styling for input and button elements.\r\ninput, textarea, select, button, .#{$button-class-name}, [role=\"button\"] {\r\n  // .button[disabled] is actually higher specificity than a.button, so no need for more than that\r\n  &:disabled, &[disabled] {\r\n    cursor: not-allowed;\r\n    opacity: $input-disabled-opacity;\r\n  }\r\n}\r\n// Button group styling.\r\n.#{$button-group-name} {\r\n  display: flex;\r\n  border: $__1px solid var(#{$button-group-border-color-var});\r\n  border-radius: var(#{$universal-border-radius-var});\r\n  margin: var(#{$universal-margin-var});\r\n  @if $universal-box-shadow != none {\r\n    box-shadow: var(#{$universal-box-shadow-var});\r\n  }\r\n  & > button, [type=\"button\"], & > [type=\"submit\"], & > [type=\"reset\"],\r\n  & > .#{$button-class-name}, & > [role=\"button\"] {\r\n    margin: 0;\r\n    max-width: 100%;\r\n    flex: 1 1 auto;\r\n    text-align: center;\r\n    border: 0;\r\n    border-radius: 0;\r\n    box-shadow: none;\r\n  }\r\n  & > :not(:first-child) {\r\n    border-left: $__1px solid var(#{$button-group-border-color-var});\r\n  }\r\n  // Responsiveness for button groups\r\n  @media screen and (max-width: #{$button-group-mobile-breakpoint}) {\r\n    flex-direction: column;\r\n    & > :not(:first-child) {\r\n      border: 0;    // Reapply to remove the left border from elements.\r\n      border-top: $__1px solid var(#{$button-group-border-color-var});\r\n    }\r\n  }\r\n}\r\n","// Input_control module's mixin definitions are here. For the module itself\r\n// check `_input_control.scss`.\r\n// Button color variant mixin:\r\n//  $button-alt-name: The name of the class used for the button variant.\r\n//  $button-alt-back-color: Background color for button variant.\r\n//  $button-alt-hover-back-color: Background color for button variant (hover).\r\n//  $button-alt-fore-color: Text color for button variant.\r\n//  $button-alt-border-color: Border color for button variant.\r\n//  $button-alt-hover-border-color: Border color for button variant (hover).\r\n@mixin make-button-alt-color ($button-alt-name, $button-alt-back-color : $button-back-color,\r\n  $button-alt-hover-back-color : $button-hover-back-color, $button-alt-fore-color : $button-fore-color,\r\n  $button-alt-border-color : $button-border-color, $button-alt-hover-border-color : $button-hover-border-color) {\r\n    button, [type=\"button\"], [type=\"submit\"], [type=\"reset\"], .#{$button-class-name}, [role=\"button\"] {\r\n      &.#{$button-alt-name} {\r\n        @if $button-alt-back-color != $button-back-color {\r\n          #{$button-back-color-var}: $button-alt-back-color;\r\n        }\r\n        @if $button-alt-fore-color != $button-fore-color{\r\n          #{$button-fore-color-var}: $button-alt-fore-color;\r\n        }\r\n        @if $button-alt-border-color != $button-border-color{\r\n          #{$button-border-color-var}: $button-alt-border-color;\r\n        }\r\n        &:hover, &:focus {\r\n          @if $button-alt-hover-back-color != $button-hover-back-color{\r\n            #{$button-hover-back-color-var}: $button-alt-hover-back-color;\r\n          }\r\n          @if $button-alt-hover-border-color != $button-hover-border-color{\r\n            #{$button-hover-border-color-var}: $button-alt-hover-border-color;\r\n          }\r\n        }\r\n      }\r\n    }\r\n}\r\n// Button size variant mixin:\r\n//  $button-alt-name: The name of the class used for the button variant.\r\n//  $button-alt-padding: The padding of the button variant.\r\n//  $button-alt-margin The margin of the button variant.\r\n@mixin make-button-alt-size ($button-alt-name, $button-alt-padding, $button-alt-margin) {\r\n  button, [type=\"button\"], [type=\"submit\"], [type=\"reset\"], .#{$button-class-name}, [role=\"button\"] {\r\n    &.#{$button-alt-name} {\r\n      padding: $button-alt-padding;\r\n      margin: $button-alt-margin;\r\n    }\r\n  }\r\n}\r\n","/*\r\n  Definitions for navigation elements.\r\n*/\r\n// Different elements are styled based on the same set of rules.\r\n$header-height:     3.1875rem !default;      // Height of the header element.\r\n$header-back-color: #f8f8f8 !default;        // Background color for the header element.\r\n$header-hover-back-color: #f0f0f0 !default;  // Background color for the header element (hover).\r\n$header-fore-color:   #444 !default;         // Text color for the header element.\r\n$header-border-color: #ddd !default;         // Border color for the header element.\r\n$nav-back-color:      #f8f8f8 !default;      // Background color for the nav element.\r\n$nav-hover-back-color: #f0f0f0 !default;     // Background color for the nav element (hover).\r\n$nav-fore-color:      #444 !default;         // Text color for the nav element.\r\n$nav-border-color:    #ddd !default;         // Border color for the nav element.\r\n$nav-link-color:      #0277bd !default;      // Color for link in the nav element.\r\n$footer-fore-color:   #444 !default;         // Text color for the footer element.\r\n$footer-back-color:   #f8f8f8 !default;      // Background color for footer nav element.\r\n$footer-border-color: #ddd !default;         // Border color for the footer element.\r\n$footer-link-color:   #0277bd !default;      // Color for link in the footer element.\r\n$drawer-back-color:   #f8f8f8 !default;      // Background color for the drawer component.\r\n$drawer-border-color: #ddd !default;         // Border color for the drawer component.\r\n$drawer-hover-back-color: #f0f0f0 !default;  // Background color for the drawer component's close (hover).\r\n$drawer-close-color:  #444 !default;         // Color of the close element for the drawer component.\r\n$_header-only-bottom-border:  true !default; // [Hidden] Apply styling only to the bottom border of header? (boolean)\r\n$_header-links-uppercase:     true !default; // [Hidden] Should header links and buttons be uppercase? (boolean)\r\n$header-logo-name:    'logo' !default;       // Class name for the header logo element.\r\n$header-logo-font-size: 1.75rem !default;    // Font ize for the header logo element.\r\n$nav-sublink-prefix:   'sublink' !default;   // Prefix for the subcategory tabs in nav.\r\n$nav-sublink-depth:    2 !default;           // Amount of subcategory classes to add.\r\n$_footer-only-top-border:  true !default;    // [Hidden] Apply styling only to the top border of footer? (boolean)\r\n$footer-font-size:    0.875rem !default;     // Font size for text in footer element.\r\n$sticky-name:         'sticky' !default;     // Class name for sticky headers and footers.\r\n$drawer-name:         'drawer' !default;     // Class name for the drawer component.\r\n$drawer-toggle-name: 'drawer-toggle' !default; // Class name for the drawer component's toggle.\r\n$drawer-toggle-font-size: 1.5em !default;    // Font size for the drawer component's toggle. (prefer em units)\r\n$drawer-mobile-breakpoint: 768px !default;   // Mobile breakpoint for the drawer component.\r\n$_drawer-right:     true !default;           // [Hidden] Should the drawer appear on the right side of the screen?\r\n$drawer-persistent-name: 'persistent' !default; // Class name for the persisten variant of the drawer component.\r\n$drawer-width:      320px !default;          // Width of the drawer component.\r\n$drawer-close-name: 'drawer-close' !default; // Class name of the close element for the drawer component.\r\n$drawer-close-size: 2rem !default;           // Size of the close element for the drawer component.\r\n// CSS variable name definitions [exercise caution if modifying these]\r\n$header-fore-color-var:          '--header-fore-color' !default;\r\n$header-back-color-var:          '--header-back-color' !default;\r\n$header-hover-back-color-var:    '--header-hover-back-color' !default;\r\n$header-border-color-var:        '--header-border-color' !default;\r\n$nav-fore-color-var:             '--nav-fore-color' !default;\r\n$nav-back-color-var:             '--nav-back-color' !default;\r\n$nav-hover-back-color-var:       '--nav-hover-back-color' !default;\r\n$nav-border-color-var:           '--nav-border-color' !default;\r\n$nav-link-color-var:             '--nav-link-color' !default;\r\n$footer-fore-color-var:          '--footer-fore-color' !default;\r\n$footer-back-color-var:          '--footer-back-color' !default;\r\n$footer-border-color-var:        '--footer-border-color' !default;\r\n$footer-link-color-var:          '--footer-link-color' !default;\r\n$drawer-back-color-var:          '--drawer-back-color' !default;\r\n$drawer-border-color-var:        '--drawer-border-color' !default;\r\n$drawer-hover-back-color-var:    '--drawer-hover-back-color' !default;\r\n$drawer-close-color-var:         '--drawer-close-color' !default;\r\n// == Uncomment below code if this module is used on its own ==\r\n//\r\n// $universal-margin:        0.5rem !default;      // Universal margin for the most elements\r\n// $universal-padding:       0.5rem !default;      // Universal padding for the most elements\r\n// $universal-border-radius: 0.125rem !default;    // Universal border-radius for most elements\r\n// $universal-box-shadow:    none !default;        // Universal box-shadow for most elements\r\n// $universal-margin-var:          '--universal-margin' !default;\r\n// $universal-padding-var:         '--universal-padding' !default;\r\n// $universal-border-radius-var:   '--universal-border-radius' !default;\r\n// $universal-box-shadow-var:      '--universal-box-shadow' !default;\r\n// :root {\r\n//  #{$universal-margin-var}: $universal-margin;\r\n//  #{$universal-padding-var}: $universal-padding;\r\n//  #{$universal-border-radius-var}: $universal-border-radius;\r\n//  @if $universal-box-shadow != none {\r\n//   #{$universal-box-shadow-var}: $universal-box-shadow;\r\n//  }\r\n// }\r\n//\r\n// ============================================================\r\n/* Navigation module CSS variable definitions */\r\n:root {\r\n  #{$header-back-color-var}: $header-back-color;\r\n  #{$header-hover-back-color-var}: $header-hover-back-color;\r\n  #{$header-fore-color-var}: $header-fore-color;\r\n  #{$header-border-color-var}: $header-border-color;\r\n  #{$nav-back-color-var}: $nav-back-color;\r\n  #{$nav-hover-back-color-var}: $nav-hover-back-color;\r\n  #{$nav-fore-color-var}: $nav-fore-color;\r\n  #{$nav-border-color-var}: $nav-border-color;\r\n  #{$nav-link-color-var}: $nav-link-color;\r\n  #{$footer-fore-color-var}: $footer-fore-color;\r\n  #{$footer-back-color-var}: $footer-back-color;\r\n  #{$footer-border-color-var}: $footer-border-color;\r\n  #{$footer-link-color-var}: $footer-link-color;\r\n  #{$drawer-back-color-var}: $drawer-back-color;\r\n  #{$drawer-hover-back-color-var}: $drawer-hover-back-color;\r\n  #{$drawer-border-color-var}: $drawer-border-color;\r\n  #{$drawer-close-color-var}: $drawer-close-color;\r\n}\r\n// Header styling. - No box-shadow as it causes lots of weird bugs in Chrome. No margin as it shouldn't have any.\r\nheader {\r\n  height: $header-height;\r\n  background: var(#{$header-back-color-var}); // Always apply background color to avoid shine through\r\n  color: var(#{$header-fore-color-var});\r\n  @if $_header-only-bottom-border {\r\n    border-bottom: $__1px solid var(#{$header-border-color-var});\r\n  }\r\n  @else {\r\n    border: $__1px solid var(#{$header-border-color-var});\r\n  }\r\n  padding: calc(var(#{$universal-padding-var}) / 4) 0;\r\n  // Responsiveness for smaller displays, scrolls horizontally.\r\n  white-space: nowrap;\r\n  overflow-x: auto;\r\n  overflow-y: hidden;\r\n  // Fix for responsive header, using the grid system's row and column alignment.\r\n  &.#{$grid-row-name} {\r\n    box-sizing: content-box;\r\n  }\r\n  // Header logo styling.\r\n  .#{$header-logo-name} {\r\n    color: var(#{$header-fore-color-var});\r\n    font-size: $header-logo-font-size;\r\n    padding: var(#{$universal-padding-var}) calc(2 * var(#{$universal-padding-var}));\r\n    text-decoration: none;\r\n  }\r\n  // Link styling.\r\n  button, [type=\"button\"], .#{$button-class-name}, [role=\"button\"] {\r\n    box-sizing: border-box;\r\n    position: relative;\r\n    top: calc(0rem - var(#{$universal-padding-var}) / 4);  // Use universal-padding to offset the padding of the header.\r\n    height: calc(#{$header-height} + var(#{$universal-padding-var}) / 2);  // Fill header.\r\n    background: var(#{$header-back-color-var});        // Apply color regardless to override styling from other things.\r\n    line-height: calc(#{$header-height} - var(#{$universal-padding-var}) * 1.5);\r\n    text-align: center;\r\n    color: var(#{$header-fore-color-var});\r\n    border: 0;\r\n    border-radius: 0;\r\n    margin: 0;\r\n    @if $_header-links-uppercase {\r\n      text-transform: uppercase;\r\n    }\r\n    &:hover, &:focus {\r\n      background: var(#{$header-hover-back-color-var});\r\n    }\r\n  }\r\n}\r\n// Navigation sidebar styling.\r\nnav {\r\n  background: var(#{$nav-back-color-var});\r\n  color: var(#{$nav-fore-color-var});\r\n  border: $__1px solid var(#{$nav-border-color-var});\r\n  border-radius: var(#{$universal-border-radius-var});\r\n  margin: var(#{$universal-margin-var});\r\n  @if $universal-box-shadow != none {\r\n    box-shadow: var(#{$universal-box-shadow-var});\r\n  }\r\n  * {\r\n    padding: var(#{$universal-padding-var}) calc(1.5 * var(#{$universal-padding-var}));\r\n  }\r\n  a, a:visited {\r\n    display: block;\r\n    color: var(#{$nav-link-color-var});    // Apply regardless to de-stylize visited links.\r\n    border-radius: var(#{$universal-border-radius-var});\r\n    transition: background 0.3s;\r\n    &:hover, &:focus {\r\n      text-decoration: none;\r\n      background: var(#{$nav-hover-back-color-var});\r\n    }\r\n  }\r\n  // Subcategories in navigation.\r\n  @for $i from 1 through $nav-sublink-depth {\r\n    .#{$nav-sublink-prefix}-#{$i} {\r\n      position: relative;\r\n      margin-left: calc(#{$i * 2} * var(#{$universal-padding-var}));\r\n      &:before {\r\n        position: absolute;\r\n        left: calc(var(#{$universal-padding-var}) - #{1 + ($i - 1)*2} * var(#{$universal-padding-var}));\r\n        top: -#{$__1px};\r\n        content: '';\r\n        height: 100%;\r\n        border: $__1px solid var(#{$nav-border-color-var});\r\n        border-left: 0;\r\n      }\r\n    }\r\n  }\r\n}\r\n// Footer styling.\r\nfooter {\r\n  background: var(#{$footer-back-color-var}); // Always apply background color to avoid shine through\r\n  color: var(#{$footer-fore-color-var});\r\n  @if $_footer-only-top-border {\r\n    border-top: $__1px solid var(#{$footer-border-color-var});\r\n  }\r\n  @else {\r\n    border: $__1px solid var(#{$footer-border-color-var});\r\n  }\r\n  // margin: $footer-margin;\r\n  padding: calc(2 * var(#{$universal-padding-var})) var(#{$universal-padding-var});\r\n  font-size: $footer-font-size;\r\n  a, a:visited {\r\n    color: var(#{$footer-link-color-var});\r\n  }\r\n}\r\n// Definitions for sticky headers and footers.\r\nheader.#{$sticky-name} {\r\n  position: -webkit-sticky; // One of the rare instances where prefixes are necessary.\r\n  position: sticky;\r\n  z-index: 1101;  // Deals with certain problems when combined with cards and tables.\r\n  top: 0;\r\n}\r\nfooter.#{$sticky-name} {\r\n  position: -webkit-sticky; // One of the rare instances where prefixes are necessary.\r\n  position: sticky;\r\n  z-index: 1101;  // Deals with certain problems when combined with cards and tables.\r\n  bottom: 0;\r\n}\r\n// Responsive drawer component.\r\n.#{$drawer-toggle-name} {\r\n  &:before {  // No color specified, should use the color of its surroundings!\r\n    display: inline-block;\r\n    position: relative;\r\n    vertical-align: bottom;\r\n    content: '\\00a0\\2261\\00a0'; // Spaces ensure compatibility with buttons that have text and that textless buttons will have some extra padding.\r\n    font-family: sans-serif;\r\n    font-size: $drawer-toggle-font-size;   // Almost hardcoded, should be fully compatible with its surroundings.\r\n  }\r\n  @media screen and (min-width: #{$drawer-mobile-breakpoint}){\r\n    &:not(.#{$drawer-persistent-name}) {\r\n      display: none;\r\n    }\r\n  }\r\n}\r\n[type=\"checkbox\"].#{$drawer-name} {\r\n  height: 1px;\r\n  width: 1px;\r\n  margin: -1px;\r\n  overflow: hidden;\r\n  position: absolute;\r\n  clip: rect(0 0 0 0);\r\n  -webkit-clip-path: inset(100%);\r\n  clip-path: inset(100%);\r\n  + * {\r\n    display: block;\r\n    box-sizing: border-box;\r\n    position: fixed;\r\n    top: 0;\r\n    width: $drawer-width;\r\n    height: 100vh;\r\n    overflow-y: auto;\r\n    background: var(#{$drawer-back-color-var});\r\n    border: $__1px solid var(#{$drawer-border-color-var});\r\n    border-radius: 0; // Set to 0 to override the value from `nav`.\r\n    margin: 0;        // Set to 0 to override the value from `nav`.\r\n    @if $universal-box-shadow != none {\r\n      box-shadow: var(#{$universal-box-shadow-var});\r\n    }\r\n    z-index: 1110;\r\n    @if $_drawer-right {\r\n      right: -$drawer-width;\r\n      transition: right 0.3s;\r\n    }\r\n    @else {\r\n      left: -$drawer-width;\r\n      transition: left 0.3s;\r\n    }\r\n    & .#{$drawer-close-name} {\r\n      position: absolute;\r\n      top: var(#{$universal-margin-var});\r\n      right: var(#{$universal-margin-var});\r\n      z-index: 1111;\r\n      width: $drawer-close-size;\r\n      height: $drawer-close-size;\r\n      border-radius: var(#{$universal-border-radius-var});\r\n      padding: var(#{$universal-padding-var});\r\n      margin: 0; // Fixes the offset from label\r\n      cursor: pointer;\r\n      transition: background 0.3s;\r\n      &:before {    // Transparent background unless hovered over. Does not block text behind it.\r\n        display: block;\r\n        content: '\\00D7';\r\n        color: var(#{$drawer-close-color-var});\r\n        position: relative;\r\n        font-family: sans-serif;\r\n        font-size: $drawer-close-size;\r\n        line-height: 1;   // Setting to 1 seems to center the 'X' properly.\r\n        text-align: center;\r\n      }\r\n      &:hover, &:focus {\r\n        background: var(#{$drawer-hover-back-color-var});\r\n      }\r\n    }\r\n    @media screen and (max-width: #{$drawer-width}) {\r\n      width: 100%;\r\n    }\r\n  }\r\n  &:checked + * {\r\n    @if $_drawer-right {\r\n      right: 0;\r\n    }\r\n    @else {\r\n      left: 0;\r\n    }\r\n  }\r\n  @media screen and (min-width: #{$drawer-mobile-breakpoint}){\r\n    &:not(.#{$drawer-persistent-name}) + * {\r\n      position: static;\r\n      height: 100%;\r\n      z-index: 1100;\r\n      & .#{$drawer-close-name} {\r\n        display: none;\r\n      }\r\n    }\r\n  }\r\n}\r\n","/*\r\n  Definitions for the responsive table component.\r\n*/\r\n// The tables use the common table elements and syntax - <tfoot> is not supported.\r\n$table-mobile-breakpoint:     768px !default;       // Breakpoint for <table> mobile view.\r\n$table-max-height:            400px !default;       // Maximum height of <table> elements (non-horizontal).\r\n$table-caption-font-size:     1.5rem !default;      // Font size for <caption> elements.\r\n$table-mobile-card-label:  'data-label' !default;   // Attribute used to replace column headers in mobile view.\r\n$table-mobile-label-font-weight: 600 !default;      // Font weight for column header labels in mobile view.\r\n$table-border-color:           #aaa !default;       // Border color for <table> elements.\r\n$table-border-separator-color: #666 !default;       // Border color for the border between <thead> and <tbody>.\r\n$table-th-back-color:          #e6e6e6 !default;    // Background color for <th> elements.\r\n$table-th-fore-color:          #111 !default;       // Text color for <th> elements.\r\n$table-td-back-color:          #f8f8f8 !default;    // Background color for <td> elements.\r\n$table-td-fore-color:          #111 !default;       // Text color for <td> elements.\r\n$_include-horizontal-table:    true !default;       // [Hidden] Flag for horizontal tables (`true`/`false`).\r\n$table-horizontal-name: 'horizontal' !default;      // Class name for horizontal <table> elements.\r\n$_include-striped-table:       true !default;       // [Hidden] Flag for striped tables.\r\n$table-striped-name: 'striped' !default;            // Class name for striped <table> elements.\r\n$table-td-alt-back-color:      #eee !default;       // Alternative background color for <td> elements in striped tables.\r\n$_include-hoverable-table:     true !default;       // [Hidden] Flag for striped tables.\r\n$table-hoverable-name: 'hoverable' !default;        // Class name for hoverable <table> elements.\r\n$table-td-hover-back-color:    #90caf9 !default;    // Hover background color for <td> elements in hoverable tables.\r\n// CSS variable name definitions [exercise caution if modifying these]\r\n$table-border-color-var:           '--table-border-color' !default;\r\n$table-border-separator-color-var: '--table-border-separator-color' !default;\r\n$table-th-back-color-var:          '--table-head-back-color' !default;\r\n$table-th-fore-color-var:          '--table-head-fore-color' !default;\r\n$table-td-back-color-var:          '--table-body-back-color' !default;\r\n$table-td-fore-color-var:          '--table-body-fore-color' !default;\r\n$table-td-alt-back-color-var:      '--table-body-alt-back-color' !default;\r\n$table-td-hover-back-color-var:      '--table-body-hover-back-color' !default;\r\n// == Uncomment below code if this module is used on its own ==\r\n//\r\n// $universal-margin:        0.5rem !default;      // Universal margin for the most elements\r\n// $universal-padding:       0.5rem !default;      // Universal padding for the most elements\r\n// $universal-border-radius: 0.125rem !default;    // Universal border-radius for most elements\r\n// $universal-box-shadow:    none !default;        // Universal box-shadow for most elements\r\n// $universal-margin-var:          '--universal-margin' !default;\r\n// $universal-padding-var:         '--universal-padding' !default;\r\n// $universal-border-radius-var:   '--universal-border-radius' !default;\r\n// $universal-box-shadow-var:      '--universal-box-shadow' !default;\r\n// :root {\r\n//  #{$universal-margin-var}: $universal-margin;\r\n//  #{$universal-padding-var}: $universal-padding;\r\n//  #{$universal-border-radius-var}: $universal-border-radius;\r\n//  @if $universal-box-shadow != none {\r\n//   #{$universal-box-shadow-var}: $universal-box-shadow;\r\n//  }\r\n// }\r\n//\r\n// ============================================================\r\n/* Table module CSS variable definitions. */\r\n:root {\r\n  #{$table-border-color-var}: $table-border-color;\r\n  #{$table-border-separator-color-var}: $table-border-separator-color;\r\n  #{$table-th-back-color-var}: $table-th-back-color;\r\n  #{$table-th-fore-color-var}: $table-th-fore-color;\r\n  #{$table-td-back-color-var}: $table-td-back-color;\r\n  #{$table-td-fore-color-var}: $table-td-fore-color;\r\n  #{$table-td-alt-back-color-var}: $table-td-alt-back-color;\r\n}\r\n// Desktop view (scrollable vertical tables).\r\ntable {\r\n  border-collapse: separate;\r\n  border-spacing: 0;\r\n  margin: 0;\r\n  display: flex;\r\n  flex: 0 1 auto;\r\n  flex-flow: row wrap;\r\n  padding: var(#{$universal-padding-var});\r\n  padding-top: 0;\r\n  @if not($_include-horizontal-table) {\r\n    overflow: auto;\r\n    max-height: $table-max-height;\r\n  }\r\n  caption {\r\n    font-size: $table-caption-font-size;\r\n    margin: calc(2 * var(#{$universal-margin-var})) 0;\r\n    max-width: 100%;\r\n    flex: 0 0 100%;\r\n  }\r\n  thead, tbody {\r\n    display: flex;\r\n    flex-flow: row wrap;\r\n    border: $__1px solid var(#{$table-border-color-var});\r\n    @if not($_include-horizontal-table) {\r\n      max-width: 100%;\r\n      flex: 0 0 100%;\r\n    }\r\n  }\r\n  thead {\r\n    z-index: 999;  // Fixes the visibility of the element.\r\n    border-radius: var(#{$universal-border-radius-var}) var(#{$universal-border-radius-var}) 0 0;\r\n    border-bottom: $__1px solid var(#{$table-border-separator-color-var});\r\n    @if not($_include-horizontal-table) {\r\n      position: sticky;\r\n      top: 0;\r\n    }\r\n  }\r\n  tbody {\r\n    border-top: 0;\r\n    margin-top: calc(0 - var(#{$universal-margin-var}));\r\n    border-radius: 0 0 var(--universal-border-radius) var(--universal-border-radius);\r\n  }\r\n  tr {\r\n    display: flex;\r\n    padding: 0; // Apply always to overwrite default.\r\n    @if not($_include-horizontal-table) {\r\n      flex-flow: row wrap;\r\n      flex: 0 0 100%;\r\n    }\r\n  }\r\n  th, td {\r\n    padding: calc(2 * var(#{$universal-padding-var}));    // Apply always to overwrite default.\r\n    @if not($_include-horizontal-table) {\r\n      flex: 1 0 0%;\r\n      overflow: hidden;\r\n      text-overflow: ellipsis;\r\n    }\r\n  }\r\n  th {\r\n    text-align: left;\r\n    background: var(#{$table-th-back-color-var});\r\n    color: var(#{$table-th-fore-color-var});\r\n  }\r\n  td {\r\n    background: var(#{$table-td-back-color-var});\r\n    color: var(#{$table-td-fore-color-var});\r\n    border-top: $__1px solid var(#{$table-border-color-var});\r\n  }\r\n  @if not($_include-horizontal-table) {\r\n    tbody tr:first-child td {\r\n      border-top: 0;\r\n    }\r\n  }\r\n}\r\n// Styling for horizontal tables\r\n@if $_include-horizontal-table {\r\n  table:not(.#{$table-horizontal-name}) {\r\n    overflow: auto;\r\n    max-height: $table-max-height;\r\n    thead, tbody {\r\n      max-width: 100%;\r\n      flex: 0 0 100%;\r\n    }\r\n    tr {\r\n      flex-flow: row wrap;\r\n      flex: 0 0 100%;\r\n    }\r\n    th, td {\r\n      flex: 1 0 0%;\r\n      overflow: hidden;\r\n      text-overflow: ellipsis;\r\n    }\r\n    thead {\r\n      position: sticky;\r\n      top: 0;\r\n    }\r\n    tbody tr:first-child td {\r\n      border-top: 0;\r\n    }\r\n  }\r\n  table.#{$table-horizontal-name} {\r\n    border: 0;\r\n    thead, tbody {\r\n      border: 0;\r\n      flex: .2 0 0;\r\n      flex-flow: row nowrap;\r\n    }\r\n    tbody {\r\n      overflow: auto;\r\n      justify-content: space-between;\r\n      flex: .8 0 0;\r\n      margin-left: 0;\r\n      padding-bottom: calc(var(#{$universal-padding-var}) / 4);\r\n    }\r\n    tr {\r\n      flex-direction: column;\r\n      flex: 1 0 auto;\r\n    }\r\n    th, td {\r\n      width: auto;\r\n      border: 0;\r\n      border-bottom: $__1px solid var(#{$table-border-color-var});\r\n      &:not(:first-child){\r\n        border-top: 0;\r\n      }\r\n    }\r\n    th {\r\n      text-align: right;\r\n      border-left: $__1px solid var(#{$table-border-color-var});\r\n      border-right: $__1px solid var(#{$table-border-separator-color-var});\r\n    }\r\n    thead {\r\n      tr:first-child {\r\n        padding-left: 0;\r\n      }\r\n    }\r\n    th:first-child, td:first-child {\r\n      border-top: $__1px solid var(#{$table-border-color-var});\r\n    }\r\n    tbody tr:last-child td {\r\n      border-right: $__1px solid var(#{$table-border-color-var});\r\n      &:first-child{\r\n        border-top-right-radius: 0.25rem;\r\n      }\r\n      &:last-child{\r\n        border-bottom-right-radius: 0.25rem;\r\n      }\r\n    }\r\n    thead tr:first-child th {\r\n      &:first-child{\r\n        border-top-left-radius: 0.25rem;\r\n      }\r\n      &:last-child{\r\n        border-bottom-left-radius: 0.25rem;\r\n      }\r\n    }\r\n  }\r\n}\r\n// Mobile\r\n@media screen and (max-width: #{$table-mobile-breakpoint - 1px}){\r\n  @if $_include-horizontal-table {\r\n    table, table.#{$table-horizontal-name} {\r\n      border-collapse: collapse;\r\n      border: 0;\r\n      width: 100%;\r\n      display: table;\r\n      // Accessibility (element is not visible, but screen readers read it normally)\r\n      thead, th {\r\n        border: 0;\r\n        height: 1px;\r\n        width: 1px;\r\n        margin: -1px;\r\n        overflow: hidden;\r\n        padding: 0;\r\n        position: absolute;\r\n        clip: rect(0 0 0 0);\r\n        -webkit-clip-path: inset(100%);\r\n        clip-path: inset(100%);\r\n      }\r\n      tbody {\r\n        border: 0;\r\n        display: table-row-group;\r\n      }\r\n      tr {\r\n        display: block;\r\n        border: $__1px solid var(#{$table-border-color-var});\r\n        border-radius: var(#{$universal-border-radius-var});\r\n        @if $universal-box-shadow != none {\r\n          box-shadow: var(#{$universal-box-shadow-var});\r\n        }\r\n        background: #fafafa;     // use variables, this is a test (body)\r\n        padding: var(#{$universal-padding-var});\r\n        margin: var(#{$universal-margin-var});\r\n        margin-bottom: calc(2 * var(#{$universal-margin-var}));\r\n      }\r\n      th, td {\r\n        width: auto;\r\n      }\r\n      td {\r\n        display: block;\r\n        border: 0;\r\n        text-align: right;\r\n      }\r\n      td:before {\r\n        content: attr(#{$table-mobile-card-label});\r\n        float: left;\r\n        font-weight: $table-mobile-label-font-weight;\r\n      }\r\n      th:first-child, td:first-child {\r\n        border-top: 0;\r\n      }\r\n      tbody tr:last-child td {\r\n        border-right: 0;\r\n      }\r\n    }\r\n  }\r\n  @else {\r\n    table {\r\n      border-collapse: collapse;\r\n      border: 0;\r\n      width: 100%;\r\n      display: table;\r\n      // Accessibility (element is not visible, but screen readers read it normally)\r\n      thead, th {\r\n        border: 0;\r\n        height: 1px;\r\n        width: 1px;\r\n        margin: -1px;\r\n        overflow: hidden;\r\n        padding: 0;\r\n        position: absolute;\r\n        clip: rect(0 0 0 0);\r\n        -webkit-clip-path: inset(100%);\r\n        clip-path: inset(100%);\r\n      }\r\n      tbody {\r\n        border: 0;\r\n        display: table-row-group;\r\n      }\r\n      tr {\r\n        display: block;\r\n        border: $__1px solid var(#{$table-border-color-var});\r\n        border-radius: var(#{$universal-border-radius-var});\r\n        @if $universal-box-shadow != none {\r\n          box-shadow: var(#{$universal-box-shadow-var});\r\n        }\r\n        background: #fafafa;     // use variables, this is a test (body)\r\n        padding: var(#{$universal-padding-var});\r\n        margin: var(#{$universal-margin-var});\r\n        margin-bottom: calc(2 * var(#{$universal-margin-var}));\r\n      }\r\n      td {\r\n        display: block;\r\n        border: 0;\r\n        text-align: right;\r\n      }\r\n      td:before {\r\n        content: attr(#{$table-mobile-card-label});\r\n        float: left;\r\n        font-weight: $table-mobile-label-font-weight;\r\n      }\r\n    }\r\n  }\r\n}\r\n// Striped tables.\r\n@if $_include-striped-table {\r\n  :root {\r\n    #{$table-td-alt-back-color-var} : $table-td-alt-back-color;\r\n  }\r\n  table.#{$table-striped-name} {\r\n    tr:nth-of-type(2n) > td {\r\n      background: var(#{$table-td-alt-back-color-var});\r\n    }\r\n  }\r\n  // Responsiveness for striped tables.\r\n  @media screen and (max-width: #{$table-mobile-breakpoint}) {\r\n    table.#{$table-striped-name} {\r\n      tr:nth-of-type(2n) {\r\n        background: var(#{$table-td-alt-back-color-var});\r\n      }\r\n    }\r\n  }\r\n}\r\n// Hoverable tables.\r\n@if $_include-striped-table {\r\n  :root {\r\n    #{$table-td-hover-back-color-var} : $table-td-hover-back-color;\r\n  }\r\n  table.#{$table-hoverable-name} {\r\n    tr {\r\n      &:hover, &:focus {\r\n        &, & > td {\r\n          background: var(#{$table-td-hover-back-color-var});\r\n        }\r\n      }\r\n    }\r\n  }\r\n  @media screen and (max-width: #{$table-mobile-breakpoint}) {\r\n    table.#{$table-hoverable-name} {\r\n      tr {\r\n        &:hover, &:focus {\r\n          &, & > td {\r\n            background: var(#{$table-td-hover-back-color-var});\r\n          }\r\n        }\r\n      }\r\n    }\r\n  }\r\n}\r\n","/*\r\n  Definitions for contextual background elements, toasts and tooltips.\r\n*/\r\n$mark-back-color:        #0277bd !default;       // Background color for <mark>\r\n$mark-fore-color:        #fafafa !default;       // Text color for <mark>\r\n$mark-font-size:         0.95em !default;        // Font size for <mark>\r\n$mark-line-height:       1em !default;           // Line height for <mark>\r\n$mark-inline-block-name: 'inline-block' !default;// Class name for inline-block <mark>\r\n$_include-toast:         true !default;          // [Hidden] Should toasts be included? (boolean)\r\n$toast-name:             'toast' !default;       // Class name for toast component\r\n$toast-back-color:       #424242 !default;       // Background color for toast component\r\n$toast-fore-color:       #fafafa !default;       // Text color for toast component\r\n$_include-tooltip:       true !default;          // [Hidden] Should tooltips be included? (boolean)\r\n$tooltip-name:           'tooltip' !default;     // Class name for tooltip component\r\n$tooltip-bottom-name:    'bottom' !default;      // Bottom tooltip class name\r\n$tooltip-back-color:      #212121 !default;      // Background color for tooltip component\r\n$tooltip-fore-color:      #fafafa !default;      // Text color for tooltip component\r\n$_include-modal:          true !default;         // [Hidden] Should modal dialogs be included? (boolean)\r\n$modal-name:              'modal' !default;      // Class name for modal dialog component\r\n$modal-overlay-color: rgba(0, 0, 0, 0.45) !default; // Overlay color for modal dialog component\r\n$modal-close-name:        'modal-close' !default;// Class name for modal dialog close button\r\n$modal-close-color:       #444 !default;         // Text color for the close button of the modal dialog component\r\n$modal-close-hover-back-color: #f0f0f0 !default; // Background color for the close button of the modal dialog component (on hover/focus)\r\n$modal-close-size:        1.75rem !default;      // Font size for the close button of the modal dialog component\r\n$_include-collapse:       true !default;         // [Hidden] Should collapse components be included? (boolean)\r\n$collapse-name:           'collapse' !default;   // Class name for collapse component\r\n$collapse-label-height:   1.5rem !default;       // Height for the labels in the collapse component\r\n$collapse-content-max-height: 400px !default;    // Max height for the content panes in the collapse component\r\n$collapse-label-back-color:     #e8e8e8 !default;// Background color for labels in the collapse component\r\n$collapse-label-fore-color:     #212121 !default;// Text color for labels in the collapse component\r\n$collapse-label-hover-back-color:#f0f0f0 !default;// Background color for labels in the collapse component (hover)\r\n$collapse-selected-label-back-color:#ececec !default;// Background color for selected labels in the collapse component\r\n$collapse-border-color:   #ddd !default;          // Border color for collapse component\r\n$collapse-selected-label-border-color:   #0277bd !default;  // Border color for collapse component's selected labels\r\n$collapse-content-back-color: #fafafa !default;   // Background color for collapse component's content panes\r\n// CSS variable name definitions [exercise caution if modifying these]\r\n$mark-back-color-var:         '--mark-back-color' !default;\r\n$mark-fore-color-var:         '--mark-fore-color' !default;\r\n$toast-back-color-var:        '--toast-back-color' !default;\r\n$toast-fore-color-var:        '--toast-fore-color' !default;\r\n$tooltip-back-color-var:      '--tooltip-back-color' !default;\r\n$tooltip-fore-color-var:      '--tooltip-fore-color' !default;\r\n$modal-overlay-color-var:     '--modal-overlay-color' !default;\r\n$modal-close-color-var:       '--modal-close-color' !default;\r\n$modal-close-hover-back-color-var: '--modal-close-hover-color' !default;\r\n$collapse-label-back-color-var:    '--collapse-label-back-color' !default;\r\n$collapse-label-fore-color-var:    '--collapse-label-fore-color' !default;\r\n$collapse-label-hover-back-color-var:    '--collapse-label-hover-back-color' !default;\r\n$collapse-selected-label-back-color-var: '--collapse-selected-label-back-color' !default;\r\n$collapse-border-color-var:        '--collapse-border-color' !default;\r\n$collapse-content-back-color-var:  '--collapse-content-back-color' !default;\r\n$collapse-selected-label-border-color-var: '--collapse-selected-label-border-color' !default;\r\n// == Uncomment below code if this module is used on its own ==\r\n//\r\n// $base-line-height:        1.5 !default;         // Line height for most elements\r\n// $universal-margin:        0.5rem !default;      // Universal margin for the most elements\r\n// $universal-padding:       0.5rem !default;      // Universal padding for the most elements\r\n// $universal-border-radius: 0.125rem !default;    // Universal border-radius for most elements\r\n// $universal-box-shadow:    none !default;        // Universal box-shadow for most elements\r\n// $universal-margin-var:          '--universal-margin' !default;\r\n// $universal-padding-var:         '--universal-padding' !default;\r\n// $universal-border-radius-var:   '--universal-border-radius' !default;\r\n// $universal-box-shadow-var:      '--universal-box-shadow' !default;\r\n// :root {\r\n//  #{$universal-margin-var}: $universal-margin;\r\n//  #{$universal-padding-var}: $universal-padding;\r\n//  #{$universal-border-radius-var}: $universal-border-radius;\r\n//  @if $universal-box-shadow != none {\r\n//   #{$universal-box-shadow-var}: $universal-box-shadow;\r\n//  }\r\n// }\r\n//\r\n// ============================================================\r\n// Check the `_contextual_mixins.scss` file to find this module's mixins.\r\n@import '_contextual_mixins';\r\n/* Contextual module CSS variable definitions */\r\n:root {\r\n  #{$mark-back-color-var}: $mark-back-color;\r\n  #{$mark-fore-color-var}: $mark-fore-color;\r\n}\r\n// Default styling for mark. Use mixins for alternate styles.\r\nmark {\r\n  background: var(#{$mark-back-color-var});\r\n  color: var(#{$mark-fore-color-var});\r\n  font-size: $mark-font-size;\r\n  line-height: $mark-line-height;\r\n  border-radius: var(#{$universal-border-radius-var});\r\n  padding: calc(var(#{$universal-padding-var}) / 4) calc(var(#{$universal-padding-var}) / 2);\r\n  @if $universal-box-shadow != none {\r\n    box-shadow: var(#{$universal-box-shadow-var});\r\n  }\r\n  &.#{$mark-inline-block-name} {\r\n    display: inline-block;\r\n    // This is hardcoded, as we want inline-block <mark> elements to be styled as normal pieces of text, instead of look small and weird.\r\n    font-size: 1em;\r\n    // Line height is reset to the normal line-height from `core`. Also hardcoded for same reasons.\r\n    line-height: $base-line-height;\r\n    padding: calc(var(#{$universal-padding-var}) / 2) var(#{$universal-padding-var});\r\n  }\r\n}\r\n// Styling for toasts.  - No border styling, I think it's unnecessary anyways.\r\n@if $_include-toast {\r\n  :root {\r\n    #{$toast-back-color-var}: $toast-back-color;\r\n    #{$toast-fore-color-var}: $toast-fore-color;\r\n  }\r\n  .#{$toast-name} {\r\n    position: fixed;\r\n    bottom: calc(var(#{$universal-margin-var}) * 3);\r\n    left: 50%;\r\n    transform: translate(-50%, -50%);\r\n    z-index: 1111;\r\n    color: var(#{$toast-fore-color-var});\r\n    background: var(#{$toast-back-color-var});\r\n    border-radius: calc(var(#{$universal-border-radius-var}) * 16);\r\n    padding: var(#{$universal-padding-var}) calc(var(#{$universal-padding-var}) * 3);\r\n    @if $universal-box-shadow != none {\r\n      box-shadow: var(#{$universal-box-shadow-var});\r\n    }\r\n  }\r\n}\r\n// Styling for tooltips.\r\n@if $_include-tooltip {\r\n  :root {\r\n    #{$tooltip-back-color-var}: $tooltip-back-color;\r\n    #{$tooltip-fore-color-var}: $tooltip-fore-color;\r\n  }\r\n  .#{$tooltip-name} {\r\n    position: relative;\r\n    display: inline-block;\r\n    &:before, &:after {\r\n      position: absolute;\r\n      opacity: 0;\r\n      clip: rect(0 0 0 0);\r\n      -webkit-clip-path: inset(100%);\r\n              clip-path: inset(100%);\r\n      transition: all 0.3s;\r\n      // Remember to keep this index a lower value than the one used for stickies.\r\n      z-index: 1010;  // Deals with certain problems when combined with cards and tables.\r\n      left: 50%;\r\n    }\r\n    &:not(.#{$tooltip-bottom-name}):before, &:not(.#{$tooltip-bottom-name}):after { // Top (default) tooltip styling\r\n      bottom: 75%;\r\n    }\r\n    &.#{$tooltip-bottom-name}:before, &.#{$tooltip-bottom-name}:after { // Bottom tooltip styling\r\n      top: 75%;\r\n    }\r\n    &:hover, &:focus {\r\n      &:before, &:after {\r\n      opacity: 1;\r\n      clip: auto;\r\n      -webkit-clip-path: inset(0%);\r\n              clip-path: inset(0%);\r\n      }\r\n    }\r\n    &:before {  // This is the little tooltip triangle\r\n      content: '';\r\n      background: transparent;\r\n      border: var(#{$universal-margin-var}) solid transparent;\r\n      // Newer browsers will center the tail properly\r\n      left: calc(50% - var(#{$universal-margin-var}));\r\n    }\r\n    &:not(.#{$tooltip-bottom-name}):before { // Top (default) tooltip styling\r\n      border-top-color: $tooltip-back-color;\r\n    }\r\n    &.#{$tooltip-bottom-name}:before { // Bottom tooltip styling\r\n      border-bottom-color: $tooltip-back-color;\r\n    }\r\n    &:after {  // This is the actual tooltip's text block\r\n      content: attr(aria-label);\r\n      color: var(#{$tooltip-fore-color-var});\r\n      background: var(#{$tooltip-back-color-var});\r\n      border-radius: var(#{$universal-border-radius-var});\r\n      padding: var(#{$universal-padding-var});\r\n      @if $universal-box-shadow != none {\r\n        box-shadow: var(#{$universal-box-shadow-var});\r\n      }\r\n      white-space: nowrap;\r\n      transform: translateX(-50%);\r\n    }\r\n    &:not(.#{$tooltip-bottom-name}):after { // Top (default) tooltip styling\r\n      margin-bottom: calc(2 * var(#{$universal-margin-var}));\r\n    }\r\n    &.#{$tooltip-bottom-name}:after { // Bottom tooltip styling\r\n      margin-top: calc(2 * var(#{$universal-margin-var}));\r\n    }\r\n  }\r\n}\r\n// Styling for modal dialogs.\r\n@if $_include-modal {\r\n  :root {\r\n    #{$modal-overlay-color-var}: $modal-overlay-color;\r\n    #{$modal-close-color-var}: $modal-close-color;\r\n    #{$modal-close-hover-back-color-var}: $modal-close-hover-back-color;\r\n  }\r\n  [type=\"checkbox\"].#{$modal-name} {\r\n    height: 1px;\r\n    width: 1px;\r\n    margin: -1px;\r\n    overflow: hidden;\r\n    position: absolute;\r\n    clip: rect(0 0 0 0);\r\n    -webkit-clip-path: inset(100%);\r\n    clip-path: inset(100%);\r\n    & + div {\r\n      position: fixed;\r\n      top: 0;\r\n      left: 0;\r\n      display: none;\r\n      width: 100vw;\r\n      height: 100vh;\r\n      background: var(#{$modal-overlay-color-var});\r\n      & .card {\r\n        margin: 0 auto;\r\n        max-height: 50vh;\r\n        overflow: auto;\r\n        & .#{$modal-close-name} {\r\n          position: absolute;\r\n          top: 0;\r\n          right: 0;\r\n          width: $modal-close-size;\r\n          height: $modal-close-size;\r\n          border-radius: var(#{$universal-border-radius-var});\r\n          padding: var(#{$universal-padding-var});\r\n          margin: 0;\r\n          cursor: pointer;\r\n          transition: background 0.3s;\r\n          &:before {\r\n            display: block;\r\n            content: '\\00D7';\r\n            color: var(#{$modal-close-color-var});\r\n            position: relative;\r\n            font-family: sans-serif;\r\n            font-size: $modal-close-size;\r\n            line-height: 1;\r\n            text-align: center;\r\n          }\r\n          &:hover, &:focus {\r\n            background: var(#{$modal-close-hover-back-color-var});\r\n          }\r\n        }\r\n      }\r\n    }\r\n    &:checked + div {\r\n      display: flex;\r\n      flex: 0 1 auto;\r\n      z-index: 1200;\r\n      & .card {\r\n        & .#{$modal-close-name} {\r\n          z-index: 1211;\r\n        }\r\n      }\r\n    }\r\n  }\r\n}\r\n// Styling for collapse.\r\n@if $_include-collapse {\r\n  :root {\r\n    #{$collapse-label-back-color-var}:  $collapse-label-back-color;\r\n    #{$collapse-label-fore-color-var}:  $collapse-label-fore-color;\r\n    #{$collapse-label-hover-back-color-var}:  $collapse-label-hover-back-color;\r\n    #{$collapse-selected-label-back-color-var}: $collapse-selected-label-back-color;\r\n    #{$collapse-border-color-var}: $collapse-border-color;\r\n    #{$collapse-content-back-color-var} : $collapse-content-back-color;\r\n    #{$collapse-selected-label-border-color-var}: $collapse-selected-label-border-color;\r\n  }\r\n  .#{$collapse-name} {\r\n    width: calc(100% - 2 * var(#{$universal-margin-var}));\r\n    opacity: 1;\r\n    display: flex;\r\n    flex-direction: column;\r\n    margin: var(#{$universal-margin-var});\r\n    border-radius: var(#{$universal-border-radius-var});\r\n    @if $universal-box-shadow != none {\r\n      box-shadow: var(#{$universal-box-shadow-var});\r\n    }\r\n    & > [type=\"radio\"], & > [type=\"checkbox\"] {\r\n      height: 1px;\r\n      width: 1px;\r\n      margin: -1px;\r\n      overflow: hidden;\r\n      position: absolute;\r\n      clip: rect(0 0 0 0);\r\n      -webkit-clip-path: inset(100%);\r\n      clip-path: inset(100%);\r\n    }\r\n    & > label {\r\n      flex-grow: 1;\r\n      display: inline-block;\r\n      height: $collapse-label-height;\r\n      cursor: pointer;\r\n      transition: background 0.3s;\r\n      color: var(#{$collapse-label-fore-color-var});\r\n      background: var(#{$collapse-label-back-color-var});\r\n      border: $__1px solid var(#{$collapse-border-color-var});\r\n      padding: calc(1.5 * var(#{$universal-padding-var}));\r\n      &:hover, &:focus {\r\n        background: var(#{$collapse-label-hover-back-color-var});\r\n      }\r\n      + div {\r\n        flex-basis: auto;\r\n        height: 1px;\r\n        width: 1px;\r\n        margin: -1px;\r\n        overflow: hidden;\r\n        position: absolute;\r\n        clip: rect(0 0 0 0);\r\n        -webkit-clip-path: inset(100%);\r\n        clip-path: inset(100%);\r\n        transition: max-height 0.3s;\r\n        max-height: 1px;  // for transition\r\n      }\r\n    }\r\n    > :checked + label {\r\n      background: var(#{$collapse-selected-label-back-color-var});\r\n      // border: 0.0625rem solid #bdbdbd; // var it\r\n      border-bottom-color: var(#{$collapse-selected-label-border-color-var});\r\n      & + div {\r\n        box-sizing: border-box;\r\n        position: relative;\r\n        width: 100%;\r\n        height: auto;\r\n        overflow: auto;\r\n        margin: 0;\r\n        background: var(#{$collapse-content-back-color-var});\r\n        border: $__1px solid var(#{$collapse-border-color-var});\r\n        border-top: 0;\r\n        padding: var(#{$universal-padding-var});\r\n        clip: auto;\r\n        -webkit-clip-path: inset(0%);\r\n        clip-path: inset(0%);\r\n        max-height: $collapse-content-max-height;\r\n      }\r\n    }\r\n    & > label:not(:first-of-type) { // Keep these down here, as it overrides some other styles.\r\n      border-top: 0;\r\n    }\r\n    & > label:first-of-type {\r\n      border-radius: var(#{$universal-border-radius-var}) var(#{$universal-border-radius-var}) 0 0;\r\n    }\r\n    & > label:last-of-type:not(:first-of-type) {\r\n      border-radius: 0 0 var(#{$universal-border-radius-var}) var(#{$universal-border-radius-var});\r\n    }\r\n    & > label:last-of-type:first-of-type {\r\n      border-radius: var(#{$universal-border-radius-var});\r\n    }\r\n    & > :checked:last-of-type:not(:first-of-type) + label {\r\n      border-radius: 0;\r\n    }\r\n    & > :checked:last-of-type + label + div {\r\n      border-radius: 0 0 var(#{$universal-border-radius-var}) var(#{$universal-border-radius-var});\r\n    }\r\n  }\r\n}\r\n","// Contextual module's mixin definitions are here. For the module itself\r\n// check `_contextual.scss`.\r\n// Mark color variant mixin:\r\n//  $mark-alt-name: The name of the class used for the <mark> variant.\r\n//  $mark-alt-back-color: Background color for <mark> variant.\r\n//  $mark-alt-fore-color: Text color for <mark> variant.\r\n@mixin make-mark-alt-color ($mark-alt-name, $mark-alt-back-color : $mark-back-color,\r\n  $mark-alt-fore-color : $mark-fore-color) {\r\n  mark.#{$mark-alt-name} {\r\n    @if $mark-alt-back-color != $mark-back-color {\r\n      #{$mark-back-color-var}: $mark-alt-back-color;\r\n    }\r\n    @if $mark-alt-fore-color != $mark-fore-color{\r\n      #{$mark-fore-color-var}: $mark-alt-fore-color;\r\n    }\r\n  }\r\n}\r\n// Mark size variant mixin:\r\n//  $mark-alt-name: The name of the class used for the <mark> variant.\r\n//  $mark-alt-padding: The padding of the <mark> variant.\r\n//  $mark-alt-border-radius: The border radius of the <mark> variant.\r\n@mixin make-mark-alt-size ($mark-alt-name, $mark-alt-padding, $mark-alt-border-radius) {\r\n  mark.#{$mark-alt-name} {\r\n    padding: $mark-alt-padding;\r\n    border-radius: $mark-alt-border-radius;\r\n  }\r\n}\r\n","/*\r\n  Definitions for progress elements and spinners.\r\n*/\r\n$progress-back-color:     #ddd !default;           // Background color of <progress>.\r\n$progress-fore-color:     #555 !default;           // Foreground color of <progress>.\r\n$progress-height:         0.75rem !default;        // Height of <progress>.\r\n$progress-max-value:      1000 !default;           // Arithmetic max value of <progress> - use integer values.\r\n$progress-inline-name:    'inline' !default;       // Class name for inline <progress> elements.\r\n$progress-inline-width:   60% !default;            // Width of inline <progress> elements.\r\n$_include-spinner-donut:  true !default;           // [Hidden] Should spinner donuts be included? (boolean)\r\n$spinner-donut-name:      'spinner' !default;      // Class name for spinner donuts\r\n$spinner-donut-size:      1.25rem !default;        // Size of the spinner donuts\r\n$spinner-donut-border-thickness: 0.25rem !default; // Border thickness for spinner donuts\r\n$spinner-donut-back-color:     #ddd !default;      // Background color for spinner donuts\r\n$spinner-donut-fore-color:     #555 !default;      // Foreground color for spinner donuts\r\n// CSS variable name definitions [exercise caution if modifying these]\r\n$progress-back-color-var: '--progress-back-color' !default;\r\n$progress-fore-color-var: '--progress-fore-color' !default;\r\n$spinner-donut-back-color-var: '--spinner-back-color' !default;\r\n$spinner-donut-fore-color-var: '--spinner-fore-color' !default;\r\n// == Uncomment below code if this module is used on its own ==\r\n//\r\n// $universal-margin:        0.5rem !default;      // Universal margin for the most elements\r\n// $universal-border-radius: 0.125rem !default;    // Universal border-radius for most elements\r\n// $universal-box-shadow:    none !default;        // Universal box-shadow for most elements\r\n// $universal-margin-var:          '--universal-margin' !default;\r\n// $universal-border-radius-var:   '--universal-border-radius' !default;\r\n// $universal-box-shadow-var:      '--universal-box-shadow' !default;\r\n// :root {\r\n//  #{$universal-margin-var}: $universal-margin;\r\n//  #{$universal-border-radius-var}: $universal-border-radius;\r\n//  @if $universal-box-shadow != none {\r\n//   #{$universal-box-shadow-var}: $universal-box-shadow;\r\n//  }\r\n// }\r\n//\r\n// ============================================================\r\n// Check the `_progress_mixins.scss` file to find this module's mixins.\r\n@import '_progress_mixins';\r\n/* Progess module CSS variable definitions */\r\n:root {\r\n  #{$progress-back-color-var}: $progress-back-color;\r\n  #{$progress-fore-color-var}: $progress-fore-color;\r\n}\r\n// Default styling for progress. Use mixins for alternate styles\r\nprogress {\r\n  display: block;\r\n  vertical-align: baseline; // Correct vertical alignment in some browsers.\r\n  -webkit-appearance: none;\r\n  -moz-appearance: none;\r\n  appearance: none;\r\n  height: $progress-height;\r\n  width: calc(100% - 2 * var(#{$universal-margin-var}));\r\n  margin: var(#{$universal-margin-var});\r\n  border: 0; // Removes default border\r\n  border-radius: calc(2 * var(#{$universal-border-radius-var}));\r\n  @if $universal-box-shadow != none {\r\n    box-shadow: var(#{$universal-box-shadow-var});\r\n  }\r\n  background: var(#{$progress-back-color-var});\r\n  color: var(#{$progress-fore-color-var});\r\n  // Foreground color on webkit browsers\r\n  &::-webkit-progress-value {\r\n    background: var(#{$progress-fore-color-var});\r\n    border-top-left-radius: calc(2 * var(#{$universal-border-radius-var}));\r\n    border-bottom-left-radius: calc(2 * var(#{$universal-border-radius-var}));\r\n  }\r\n  // Background color on webkit browser\r\n  &::-webkit-progress-bar {\r\n    background: var(#{$progress-back-color-var});\r\n  }\r\n  // Foreground color on Firefox\r\n  &::-moz-progress-bar {\r\n    background: var(#{$progress-fore-color-var});\r\n    border-top-left-radius: calc(2 * var(#{$universal-border-radius-var}));\r\n    border-bottom-left-radius: calc(2 * var(#{$universal-border-radius-var}));\r\n  }\r\n  &[value=\"#{$progress-max-value}\"] {\r\n    &::-webkit-progress-value {\r\n      border-radius: calc(2 * var(#{$universal-border-radius-var}));\r\n    }\r\n    &::-moz-progress-bar {\r\n      border-radius: calc(2 * var(#{$universal-border-radius-var}));\r\n    }\r\n  }\r\n  &.#{$progress-inline-name} {\r\n    display: inline-block;\r\n    vertical-align: middle;   // Align progress bar vertically to look better with text next to it.\r\n    width: $progress-inline-width;\r\n  }\r\n}\r\n// Style for donut spinner\r\n@if $_include-spinner-donut {\r\n  :root {\r\n    #{$spinner-donut-back-color-var}: $spinner-donut-back-color;\r\n    #{$spinner-donut-fore-color-var}: $spinner-donut-fore-color;\r\n  }\r\n  // Donut spinner animation\r\n  @keyframes spinner-donut-anim {\r\n    0% { transform: rotate(0deg); }\r\n    100% { transform: rotate(360deg);}\r\n  }\r\n  .#{$spinner-donut-name} {\r\n    display: inline-block;\r\n    margin: var(#{$universal-margin-var});\r\n    border: $spinner-donut-border-thickness solid var(#{$spinner-donut-back-color-var});\r\n    border-left: $spinner-donut-border-thickness solid var(#{$spinner-donut-fore-color-var});\r\n    border-radius: 50%;\r\n    width: $spinner-donut-size;\r\n    height: $spinner-donut-size;\r\n    animation: spinner-donut-anim 1.2s linear infinite;\r\n  }\r\n}\r\n","// Progress module's mixin definitions are here. For the module itself\r\n// check `progress.scss`.\r\n// Progress color variant mixin:\r\n//  $progress-alt-name: The name of the class used for the <progress> variant.\r\n//  $progress-alt-fore-color: Foregound color for <progress> variant.\r\n//  $progress-alt-back-color: Background color for <progress> variant.\r\n@mixin make-progress-alt-color ($progress-alt-name, $progress-alt-fore-color : $progress-fore-color,\r\n  $progress-alt-back-color : $progress-back-color) {\r\n  progress.#{$progress-alt-name} {\r\n    @if $progress-alt-fore-color != $progress-fore-color{\r\n      #{$progress-fore-color-var}: $progress-alt-fore-color;\r\n    }\r\n    @if $progress-alt-back-color != $progress-back-color {\r\n      #{$progress-back-color-var}: $progress-alt-back-color;\r\n    }\r\n  }\r\n}\r\n// Spinner donut color variant mixin:\r\n//  $spinner-donut-alt-name: The name of the class used for the spinner donut variant.\r\n//  $spinner-donut-alt-fore-color: Text color for spinner donut variant.\r\n//  $spinner-donut-alt-back-color: Background color for spinner donut variant.\r\n@mixin make-spinner-donut-alt-color ($spinner-donut-alt-name, $spinner-donut-alt-fore-color : $spinner-donut-fore-color,\r\n  $spinner-donut-alt-back-color : $spinner-donut-back-color) {\r\n  .#{$spinner-donut-name}.#{$spinner-donut-alt-name} {\r\n    @if $spinner-donut-alt-fore-color != $spinner-donut-fore-color{\r\n      #{$spinner-donut-fore-color-var}: $spinner-donut-alt-fore-color;\r\n    }\r\n    @if $spinner-donut-alt-back-color != $spinner-donut-back-color {\r\n      #{$spinner-donut-back-color-var}: $spinner-donut-alt-back-color;\r\n    }\r\n  }\r\n}\r\n","/*\r\n  Definitions for icons - powered by Feather (https://feathericons.com/).\r\n*/\r\n$icon-prefix:            'icon' !default;        // Class name prefix for icons.\r\n$icon-alert-name:        'alert' !default;       // Class name suffix for alert icon.\r\n$icon-bookmark-name:     'bookmark' !default;    // Class name suffix for bookmark icon.\r\n$icon-calendar-name:     'calendar' !default;    // Class name suffix for calendar icon.\r\n$icon-credit-name:       'credit' !default;      // Class name suffix for credit icon.\r\n$icon-edit-name:         'edit' !default;        // Class name suffix for edit icon.\r\n$icon-link-name:         'link' !default;        // Class name suffix for link icon.\r\n$icon-help-name:         'help' !default;        // Class name suffix for help icon.\r\n$icon-home-name:         'home' !default;        // Class name suffix for home icon.\r\n$icon-info-name:         'info' !default;        // Class name suffix for info icon.\r\n$icon-lock-name:         'lock' !default;        // Class name suffix for lock icon.\r\n$icon-mail-name:         'mail' !default;        // Class name suffix for mail icon.\r\n$icon-location-name:     'location' !default;    // Class name suffix for location icon.\r\n$icon-phone-name:        'phone' !default;       // Class name suffix for phone icon.\r\n$icon-rss-name:          'rss' !default;         // Class name suffix for rss icon.\r\n$icon-search-name:       'search' !default;      // Class name suffix for search icon.\r\n$icon-settings-name:     'settings' !default;    // Class name suffix for settings icon.\r\n$icon-share-name:        'share' !default;       // Class name suffix for share icon.\r\n$icon-cart-name:         'cart' !default;        // Class name suffix for cart icon.\r\n$icon-upload-name:       'upload' !default;      // Class name suffix for upload icon.\r\n$icon-user-name:         'user' !default;        // Class name suffix for user icon.\r\n$icon-secondary-color-name: 'secondary' !default;// Class name for secondary color icons.\r\n$icon-inverse-color-name: 'inverse' !default;    // Class name for inverse color icons.\r\n/// Replace `$search` with `$replace` in `$string`\r\n/// @author Hugo Giraudel\r\n/// @param {String} $string - Initial string\r\n/// @param {String} $search - Substring to replace\r\n/// @param {String} $replace ('') - New value\r\n/// @return {String} - Updated string\r\n@function str-replace($string, $search, $replace: '') {\r\n  $index: str-index($string, $search);\r\n  @if $index {\r\n    @return str-slice($string, 1, $index - 1) + $replace + str-replace(str-slice($string, $index + str-length($search)), $search, $replace);\r\n  }\r\n  @return $string;\r\n}\r\n// == Uncomment below code if this module is used on its own ==\r\n//\r\n// $universal-margin:        0.5rem !default;      // Universal margin for the most elements\r\n// $fore-color:              #111 !default;        // Text & foreground color\r\n// $universal-margin-var:          '--universal-margin' !default;\r\n// $fore-color-var:                '--fore-color' !default;\r\n// :root {\r\n//  #{$universal-margin-var}: $universal-margin;\r\n//  #{$fore-color-var}: $fore-color;\r\n// }\r\n//\r\n// ============================================================\r\n// Base styling for icons.\r\nspan[class^='#{$icon-prefix}-'] {\r\n  display: inline-block;\r\n  height: 1em;\r\n  width: 1em;\r\n  vertical-align: -0.125em; // fixes alignment issues\r\n  background-size: contain;\r\n  margin: 0 calc(var(#{$universal-margin-var}) / 4);\r\n  &.#{$icon-secondary-color-name}{\r\n    -webkit-filter: invert(25%);\r\n    filter: invert(25%);\r\n  }\r\n  &.#{$icon-inverse-color-name}{\r\n    -webkit-filter: invert(100%);\r\n    filter: invert(100%);\r\n  }\r\n}\r\nspan{\r\n  $stroke-color: str-replace(#{$fore-color}, '#', '%23');\r\n  &.#{$icon-prefix}-#{$icon-alert-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='10'%3E%3C/circle%3E%3Cline x1='12' y1='8' x2='12' y2='12'%3E%3C/line%3E%3Cline x1='12' y1='16' x2='12' y2='16'%3E%3C/line%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-bookmark-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z'%3E%3C/path%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-calendar-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='4' width='18' height='18' rx='2' ry='2'%3E%3C/rect%3E%3Cline x1='16' y1='2' x2='16' y2='6'%3E%3C/line%3E%3Cline x1='8' y1='2' x2='8' y2='6'%3E%3C/line%3E%3Cline x1='3' y1='10' x2='21' y2='10'%3E%3C/line%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-credit-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='1' y='4' width='22' height='16' rx='2' ry='2'%3E%3C/rect%3E%3Cline x1='1' y1='10' x2='23' y2='10'%3E%3C/line%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-edit-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34'%3E%3C/path%3E%3Cpolygon points='18 2 22 6 12 16 8 16 8 12 18 2'%3E%3C/polygon%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-link-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6'%3E%3C/path%3E%3Cpolyline points='15 3 21 3 21 9'%3E%3C/polyline%3E%3Cline x1='10' y1='14' x2='21' y2='3'%3E%3C/line%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-help-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3'%3E%3C/path%3E%3Ccircle cx='12' cy='12' r='10'%3E%3C/circle%3E%3Cline x1='12' y1='17' x2='12' y2='17'%3E%3C/line%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-home-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'%3E%3C/path%3E%3Cpolyline points='9 22 9 12 15 12 15 22'%3E%3C/polyline%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-info-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='10'%3E%3C/circle%3E%3Cline x1='12' y1='16' x2='12' y2='12'%3E%3C/line%3E%3Cline x1='12' y1='8' x2='12' y2='8'%3E%3C/line%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-lock-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='11' width='18' height='11' rx='2' ry='2'%3E%3C/rect%3E%3Cpath d='M7 11V7a5 5 0 0 1 10 0v4'%3E%3C/path%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-mail-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z'%3E%3C/path%3E%3Cpolyline points='22,6 12,13 2,6'%3E%3C/polyline%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-location-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'%3E%3C/path%3E%3Ccircle cx='12' cy='10' r='3'%3E%3C/circle%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-phone-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z'%3E%3C/path%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-rss-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M4 11a9 9 0 0 1 9 9'%3E%3C/path%3E%3Cpath d='M4 4a16 16 0 0 1 16 16'%3E%3C/path%3E%3Ccircle cx='5' cy='19' r='1'%3E%3C/circle%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-search-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='11' cy='11' r='8'%3E%3C/circle%3E%3Cline x1='21' y1='21' x2='16.65' y2='16.65'%3E%3C/line%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-settings-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='3'%3E%3C/circle%3E%3Cpath d='M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z'%3E%3C/path%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-share-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='18' cy='5' r='3'%3E%3C/circle%3E%3Ccircle cx='6' cy='12' r='3'%3E%3C/circle%3E%3Ccircle cx='18' cy='19' r='3'%3E%3C/circle%3E%3Cline x1='8.59' y1='13.51' x2='15.42' y2='17.49'%3E%3C/line%3E%3Cline x1='15.41' y1='6.51' x2='8.59' y2='10.49'%3E%3C/line%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-cart-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='9' cy='21' r='1'%3E%3C/circle%3E%3Ccircle cx='20' cy='21' r='1'%3E%3C/circle%3E%3Cpath d='M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6'%3E%3C/path%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-upload-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'%3E%3C/path%3E%3Cpolyline points='17 8 12 3 7 8'%3E%3C/polyline%3E%3Cline x1='12' y1='3' x2='12' y2='15'%3E%3C/line%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n  &.#{$icon-prefix}-#{$icon-user-name}{\r\n    background-image: #{str-replace(\"url(\\\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'%3E%3C/path%3E%3Ccircle cx='12' cy='7' r='4'%3E%3C/circle%3E%3C/svg%3E\\\")\",'currentColor',$stroke-color)};\r\n  }\r\n}\r\n","/*\r\n  Definitions for utilities and helper classes.\r\n*/\r\n$hidden-name:           'hidden' !default;          // Class name for hidden elements.\r\n$visually-hidden-name:  'visually-hidden' !default; // Class name for visually hidden elements.\r\n$border-generic-name:   'bordered' !default;        // Class name for bordered elements.\r\n$border-generic-color:   rgba(0,0,0, 0.3) !default; // Border color for bordered elements.\r\n$border-rounded-name:   'rounded' !default;         // Class name for rounded-border elements.\r\n$border-circular-name:   'circular' !default;       // Class name for circular-border elements.\r\n$box-shadow-generic-name:'shadowed' !default;       // Class name for box-shadow elements.\r\n$box-shadow-generic: 0 4*$__1px 4*$__1px 0 rgba(0, 0, 0, 0.125),  0 2*$__1px 2*$__1px -2*$__1px rgba(0, 0, 0, 0.25) !default;\r\n$responsive-margin-name: 'responsive-margin' !default; //Class name for responsive margin elements.\r\n$responsive-margin-medium-breakpoint: 768px !default; // Medium screen breakpoint for responsive margin elements.\r\n$responsive-margin-large-breakpoint: 1280px !default; // Medium screen breakpoint for responsive margin elements.\r\n$responsive-padding-name: 'responsive-padding' !default; //Class name for responsive padding elements.\r\n$responsive-padding-medium-breakpoint: 768px !default; // Medium screen breakpoint for responsive padding elements.\r\n$responsive-padding-large-breakpoint: 1280px !default; // Medium screen breakpoint for responsive padding elements.\r\n$hidden-prefix:           'hidden' !default;           // Class prefix for responsive hidden elements.\r\n$hidden-small-suffix:     'sm' !default;               // Class suffix for responsive hidden elements.\r\n$hidden-medium-breakpoint: 768px !default;             // Medium screen breakpoint for responsive hidden elements.\r\n$hidden-medium-suffix:     'md' !default;              // Class suffix for responsive hidden elements.\r\n$hidden-large-breakpoint: 1280px !default;             // Medium screen breakpoint for responsive hidden elements.\r\n$hidden-large-suffix:     'lg' !default;               // Class suffix for responsive hidden elements.\r\n$visually-hidden-prefix:  'visually-hidden' !default;  // Class prefix for responsive visually hidden elements.\r\n$visually-hidden-small-suffix:   'sm' !default;        // Class suffix for responsive hidden elements.\r\n$visually-hidden-medium-breakpoint: 768px !default;    // Medium screen breakpoint for responsive visually hidden elements.\r\n$visually-hidden-medium-suffix:   'md' !default;       // Class suffix for responsive hidden elements.\r\n$visually-hidden-large-breakpoint: 1280px !default;    // Medium screen breakpoint for responsive visually hidden elements.\r\n$visually-hidden-large-suffix:  'lg' !default;         // Class suffix for responsive hidden elements.\r\n// CSS variable name definitions [exercise caution if modifying these]\r\n$border-generic-color-var:        '--generic-border-color' !default;\r\n$box-shadow-generic-var:          '--generic-box-shadow' !default;\r\n// == Uncomment below code if this module is used on its own ==\r\n//\r\n// $universal-margin:        0.5rem !default;      // Universal margin for the most elements\r\n// $universal-padding:       0.5rem !default;      // Universal padding for the most elements\r\n// $universal-border-radius: 0.125rem !default;    // Universal border-radius for most elements\r\n// $universal-box-shadow:    none !default;        // Universal box-shadow for most elements\r\n// $universal-margin-var:          '--universal-margin' !default;\r\n// $universal-padding-var:         '--universal-padding' !default;\r\n// $universal-border-radius-var:   '--universal-border-radius' !default;\r\n// $universal-box-shadow-var:      '--universal-box-shadow' !default;\r\n// :root {\r\n//  #{$universal-margin-var}: $universal-margin;\r\n//  #{$universal-padding-var}: $universal-padding;\r\n//  #{$universal-border-radius-var}: $universal-border-radius;\r\n//  @if $universal-box-shadow != none {\r\n//   #{$universal-box-shadow-var}: $universal-box-shadow;\r\n//  }\r\n// }\r\n//\r\n// ============================================================\r\n/* Utility module CSS variable definitions */\r\n:root {\r\n  #{$border-generic-color-var}: $border-generic-color;\r\n  #{$box-shadow-generic-var}: $box-shadow-generic;\r\n}\r\n// Hidden elements class. NOTE: Uses !important.\r\n.#{$hidden-name}{\r\n  display: none !important;\r\n}\r\n// Visually hidden elements class. NOTE: Uses !important.\r\n.#{$visually-hidden-name} {\r\n  position: absolute !important;\r\n  width: 1px !important;\r\n  height: 1px !important;\r\n  margin: -1px !important;\r\n  border: 0 !important;\r\n  padding: 0 !important;\r\n  clip: rect(0 0 0 0) !important;\r\n  -webkit-clip-path: inset(100%) !important;\r\n  clip-path: inset(100%) !important;\r\n  overflow: hidden !important;\r\n}\r\n// Generic bordered element class. NOTE: Uses !important.\r\n.#{$border-generic-name} {\r\n  border: $__1px solid var(#{$border-generic-color-var}) !important;\r\n}\r\n// Generic rounded-border element class. NOTE: Uses !important.\r\n.#{$border-rounded-name} {\r\n  border-radius: var(#{$universal-border-radius-var}) !important;\r\n}\r\n// Generic circular-border element class. NOTE: Uses !important.\r\n.#{$border-circular-name} {\r\n  border-radius: 50% !important;\r\n}\r\n// Generic box-shadow element class. NOTE: Uses !important.\r\n.#{$box-shadow-generic-name} {\r\n  box-shadow: var(#{$box-shadow-generic-var}) !important;\r\n}\r\n// Responsive margin class. NOTE: Uses !important.\r\n.#{$responsive-margin-name} {\r\n  margin: calc(var(#{$universal-margin-var}) / 4) !important;\r\n  @media screen and (min-width: #{$responsive-margin-medium-breakpoint}) {\r\n    margin: calc(var(#{$universal-margin-var}) / 2) !important;\r\n  }\r\n  @media screen and (min-width: #{$responsive-margin-large-breakpoint}) {\r\n    margin: var(#{$universal-margin-var}) !important;\r\n  }\r\n}\r\n// Responsive padding class. NOTE: Uses !important.\r\n.#{$responsive-padding-name} {\r\n  padding: calc(var(#{$universal-padding-var}) / 4) !important;\r\n  @media screen and (min-width: #{$responsive-padding-medium-breakpoint}) {\r\n    padding: calc(var(#{$universal-padding-var}) / 2) !important;\r\n  }\r\n  @media screen and (min-width: #{$responsive-padding-large-breakpoint}) {\r\n    padding: var(#{$universal-padding-var}) !important;\r\n  }\r\n}\r\n// Responsive hidden element class. NOTE: Uses !important.\r\n@media screen and (max-width: $hidden-medium-breakpoint - 1px) {\r\n  .#{$hidden-prefix}-#{$hidden-small-suffix} {\r\n    display: none !important;\r\n  }\r\n}\r\n@media screen and (min-width: #{$hidden-medium-breakpoint}) and (max-width: $hidden-large-breakpoint - 1px) {\r\n  .#{$hidden-prefix}-#{$hidden-medium-suffix} {\r\n    display: none !important;\r\n  }\r\n}\r\n@media screen and (min-width: #{$hidden-large-breakpoint}) {\r\n  .#{$hidden-prefix}-#{$hidden-large-suffix} {\r\n    display: none !important;\r\n  }\r\n}\r\n// Responsive visually hidden element class. NOTE: Uses !important.\r\n@media screen and (max-width: $visually-hidden-medium-breakpoint - 1px) {\r\n  .#{$visually-hidden-prefix}-#{$visually-hidden-small-suffix} {\r\n    position: absolute !important;\r\n    width: 1px !important;\r\n    height: 1px !important;\r\n    margin: -1px !important;\r\n    border: 0 !important;\r\n    padding: 0 !important;\r\n    clip: rect(0 0 0 0) !important;\r\n    -webkit-clip-path: inset(100%) !important;\r\n    clip-path: inset(100%) !important;\r\n    overflow: hidden !important;\r\n  }\r\n}\r\n@media screen and (min-width: #{$visually-hidden-medium-breakpoint}) and (max-width: $visually-hidden-large-breakpoint - 1px) {\r\n  .#{$visually-hidden-prefix}-#{$visually-hidden-medium-suffix} {\r\n    position: absolute !important;\r\n    width: 1px !important;\r\n    height: 1px !important;\r\n    margin: -1px !important;\r\n    border: 0 !important;\r\n    padding: 0 !important;\r\n    clip: rect(0 0 0 0) !important;\r\n    -webkit-clip-path: inset(100%) !important;\r\n    clip-path: inset(100%) !important;\r\n    overflow: hidden !important;\r\n  }\r\n}\r\n@media screen and (min-width: #{$visually-hidden-large-breakpoint}) {\r\n  .#{$visually-hidden-prefix}-#{$visually-hidden-large-suffix} {\r\n    position: absolute !important;\r\n    width: 1px !important;\r\n    height: 1px !important;\r\n    margin: -1px !important;\r\n    border: 0 !important;\r\n    padding: 0 !important;\r\n    clip: rect(0 0 0 0) !important;\r\n    -webkit-clip-path: inset(100%) !important;\r\n    clip-path: inset(100%) !important;\r\n    overflow: hidden !important;\r\n  }\r\n}\r\n"]}]);
// Exports
module.exports = exports;


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(1);
            var content = __webpack_require__(8);

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(2);
exports = ___CSS_LOADER_API_IMPORT___(true);
// Module
exports.push([module.i, ".debug {\n    height: 90%;\n    width: 99%;\n}\n\n.debug textarea {\n    background-color: black;\n    overflow: auto;\n    color: white;\n    height: 100%;\n    width: 100%;\n    white-space: pre;\n}", "",{"version":3,"sources":["debug.css"],"names":[],"mappings":"AAAA;IACI,WAAW;IACX,UAAU;AACd;;AAEA;IACI,uBAAuB;IACvB,cAAc;IACd,YAAY;IACZ,YAAY;IACZ,WAAW;IACX,gBAAgB;AACpB","file":"debug.css","sourcesContent":[".debug {\n    height: 90%;\n    width: 99%;\n}\n\n.debug textarea {\n    background-color: black;\n    overflow: auto;\n    color: white;\n    height: 100%;\n    width: 100%;\n    white-space: pre;\n}"]}]);
// Exports
module.exports = exports;


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(1);
            var content = __webpack_require__(10);

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(2);
exports = ___CSS_LOADER_API_IMPORT___(true);
// Module
exports.push([module.i, ".eco, .normal, .confort {\n    margin-top: 15px;\n    border: 1px solid;\n    min-height: 5px;\n    background-color: black;\n    border-color: gray;\n    min-width: 5px;\n    display: inline-block;\n}\n\n.eco:hover, .normal:hover, .confort:hover {\n    background-color: darkcyan;\n    cursor: pointer;    \n}\n\n.normal {\n    margin-top: 10px;\n    min-height: 10px;\n}\n\n.confort {\n    margin-top: 5px;\n    min-height: 15px;\n}\n\n.unsaved {\n    background-color: goldenrod;\n}\n\n.plist .row {\n    min-height: 34px;\n}\n\n.plist .row:nth-of-type(odd) {\n    background-color: gainsboro;\n\n}\n\n.plist sup {\n    margin-left: 1px;\n    margin-right: 1px;\n}\n\n.noselect {\n    -webkit-touch-callout: none; /* iOS Safari */\n      -webkit-user-select: none; /* Safari */\n       -khtml-user-select: none; /* Konqueror HTML */\n         -moz-user-select: none; /* Old versions of Firefox */\n          -ms-user-select: none; /* Internet Explorer/Edge */\n              user-select: none; /* Non-prefixed version, currently\n                                    supported by Chrome, Opera and Firefox */\n}\n\n.mirror {\n    height: 100%;\n    width: 100%;\n    max-width: 390px;\n    max-height: 195px;\n}\n\n.terminal {\n    height: 100%;\n\n}\n", "",{"version":3,"sources":["holds.css"],"names":[],"mappings":"AAAA;IACI,gBAAgB;IAChB,iBAAiB;IACjB,eAAe;IACf,uBAAuB;IACvB,kBAAkB;IAClB,cAAc;IACd,qBAAqB;AACzB;;AAEA;IACI,0BAA0B;IAC1B,eAAe;AACnB;;AAEA;IACI,gBAAgB;IAChB,gBAAgB;AACpB;;AAEA;IACI,eAAe;IACf,gBAAgB;AACpB;;AAEA;IACI,2BAA2B;AAC/B;;AAEA;IACI,gBAAgB;AACpB;;AAEA;IACI,2BAA2B;;AAE/B;;AAEA;IACI,gBAAgB;IAChB,iBAAiB;AACrB;;AAEA;IACI,2BAA2B,EAAE,eAAe;MAC1C,yBAAyB,EAAE,WAAW;OACrC,wBAAwB,EAAE,mBAAmB;SAC3C,sBAAsB,EAAE,4BAA4B;UACnD,qBAAqB,EAAE,2BAA2B;cAC9C,iBAAiB,EAAE;4EAC2C;AAC5E;;AAEA;IACI,YAAY;IACZ,WAAW;IACX,gBAAgB;IAChB,iBAAiB;AACrB;;AAEA;IACI,YAAY;;AAEhB","file":"holds.css","sourcesContent":[".eco, .normal, .confort {\n    margin-top: 15px;\n    border: 1px solid;\n    min-height: 5px;\n    background-color: black;\n    border-color: gray;\n    min-width: 5px;\n    display: inline-block;\n}\n\n.eco:hover, .normal:hover, .confort:hover {\n    background-color: darkcyan;\n    cursor: pointer;    \n}\n\n.normal {\n    margin-top: 10px;\n    min-height: 10px;\n}\n\n.confort {\n    margin-top: 5px;\n    min-height: 15px;\n}\n\n.unsaved {\n    background-color: goldenrod;\n}\n\n.plist .row {\n    min-height: 34px;\n}\n\n.plist .row:nth-of-type(odd) {\n    background-color: gainsboro;\n\n}\n\n.plist sup {\n    margin-left: 1px;\n    margin-right: 1px;\n}\n\n.noselect {\n    -webkit-touch-callout: none; /* iOS Safari */\n      -webkit-user-select: none; /* Safari */\n       -khtml-user-select: none; /* Konqueror HTML */\n         -moz-user-select: none; /* Old versions of Firefox */\n          -ms-user-select: none; /* Internet Explorer/Edge */\n              user-select: none; /* Non-prefixed version, currently\n                                    supported by Chrome, Opera and Firefox */\n}\n\n.mirror {\n    height: 100%;\n    width: 100%;\n    max-width: 390px;\n    max-height: 195px;\n}\n\n.terminal {\n    height: 100%;\n\n}\n"]}]);
// Exports
module.exports = exports;


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(1);
            var content = __webpack_require__(12);

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(2);
exports = ___CSS_LOADER_API_IMPORT___(true);
// Module
exports.push([module.i, "@keyframes pulse {\n  0% {\n    box-shadow: 0 0 0px #73eaff;\n  }\n  50% {\n    box-shadow: 0 0 20px #73eaff;\n  }\n  100% {\n    box-shadow: 0 0 0px #73eaff;\n  }\n}\n.room-name {\n  text-align: center;\n  color: lightgrey;\n  padding: 10px;\n}\n.temperature-indicator {\n  width: 200px;\n  height: 200px;\n  background-color: transparent;\n  border-radius: 50%;\n  margin: 0 auto;\n  line-height: 200px;\n  text-align: center;\n  font-size: 65px;\n  animation: pulse 3s ease-in-out 2s infinite;\n}\n.temp-pick {\n  margin-top: -70px;\n  width: 100%;\n  text-align: center;\n}\n.temp-pick div {\n  font-size: 25px;\n  font-weight: 100;\n  display: inline;\n  padding: 10px;\n}\n.fah {\n  color: lightgrey;\n}\n.button-container {\n  width: 100%;\n  text-align: center;\n  padding-top: 20px;\n}\n.button-container .decrease,\n.increase {\n  width: 80px;\n  height: 80px;\n  margin: 20px 10px;\n  background: white;\n  border: none;\n  border-radius: 50%;\n  font-size: 40px;\n  line-height: 80px;\n  font-weight: 100;\n}\n.decrease {\n  color: #2a2a35;\n  transition: box-shadow ease-in-out;\n}\n.decrease:hover {\n  -webkit-box-shadow: 0px 0px 2px 0px #ff757c;\n  -moz-box-shadow: 0px 0px 2px 0px #ff757c;\n  box-shadow: 0px 0px 2px 0px #ff757c;\n}\n.increase {\n  color: #2a2a35;\n  transition: box-shadow ease-in-out;\n}\n.increase:hover {\n  -webkit-box-shadow: 0px 0px 2px 0px #73eaff;\n  -moz-box-shadow: 0px 0px 2px 0 #73eaff;\n  box-shadow: 0 0 2px 0 #73eaff;\n}\n.auto-mode {\n  width: 100%;\n  text-align: center;\n  font-size: 20px;\n  font-weight: 500;\n}\n.fa-thermometer-quarter {\n  font-size: 30px;\n}\n", "",{"version":3,"sources":["climate.less"],"names":[],"mappings":"AAAA;EACE;IACE,2BAA2B;EAC7B;EACA;IACE,4BAA4B;EAC9B;EACA;IACE,2BAA2B;EAC7B;AACF;AACA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,aAAa;AACf;AACA;EACE,YAAY;EACZ,aAAa;EACb,6BAA6B;EAC7B,kBAAkB;EAClB,cAAc;EACd,kBAAkB;EAClB,kBAAkB;EAClB,eAAe;EACf,2CAA2C;AAC7C;AACA;EACE,iBAAiB;EACjB,WAAW;EACX,kBAAkB;AACpB;AACA;EACE,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,aAAa;AACf;AACA;EACE,gBAAgB;AAClB;AACA;EACE,WAAW;EACX,kBAAkB;EAClB,iBAAiB;AACnB;AACA;;EAEE,WAAW;EACX,YAAY;EACZ,iBAAiB;EACjB,iBAAiB;EACjB,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,iBAAiB;EACjB,gBAAgB;AAClB;AACA;EACE,cAAc;EACd,kCAAkC;AACpC;AACA;EACE,2CAA2C;EAC3C,wCAAwC;EACxC,mCAAmC;AACrC;AACA;EACE,cAAc;EACd,kCAAkC;AACpC;AACA;EACE,2CAA2C;EAC3C,sCAAsC;EACtC,6BAA6B;AAC/B;AACA;EACE,WAAW;EACX,kBAAkB;EAClB,eAAe;EACf,gBAAgB;AAClB;AACA;EACE,eAAe;AACjB","file":"climate.less","sourcesContent":["@keyframes pulse {\n  0% {\n    box-shadow: 0 0 0px #73eaff;\n  }\n  50% {\n    box-shadow: 0 0 20px #73eaff;\n  }\n  100% {\n    box-shadow: 0 0 0px #73eaff;\n  }\n}\n.room-name {\n  text-align: center;\n  color: lightgrey;\n  padding: 10px;\n}\n.temperature-indicator {\n  width: 200px;\n  height: 200px;\n  background-color: transparent;\n  border-radius: 50%;\n  margin: 0 auto;\n  line-height: 200px;\n  text-align: center;\n  font-size: 65px;\n  animation: pulse 3s ease-in-out 2s infinite;\n}\n.temp-pick {\n  margin-top: -70px;\n  width: 100%;\n  text-align: center;\n}\n.temp-pick div {\n  font-size: 25px;\n  font-weight: 100;\n  display: inline;\n  padding: 10px;\n}\n.fah {\n  color: lightgrey;\n}\n.button-container {\n  width: 100%;\n  text-align: center;\n  padding-top: 20px;\n}\n.button-container .decrease,\n.increase {\n  width: 80px;\n  height: 80px;\n  margin: 20px 10px;\n  background: white;\n  border: none;\n  border-radius: 50%;\n  font-size: 40px;\n  line-height: 80px;\n  font-weight: 100;\n}\n.decrease {\n  color: #2a2a35;\n  transition: box-shadow ease-in-out;\n}\n.decrease:hover {\n  -webkit-box-shadow: 0px 0px 2px 0px #ff757c;\n  -moz-box-shadow: 0px 0px 2px 0px #ff757c;\n  box-shadow: 0px 0px 2px 0px #ff757c;\n}\n.increase {\n  color: #2a2a35;\n  transition: box-shadow ease-in-out;\n}\n.increase:hover {\n  -webkit-box-shadow: 0px 0px 2px 0px #73eaff;\n  -moz-box-shadow: 0px 0px 2px 0 #73eaff;\n  box-shadow: 0 0 2px 0 #73eaff;\n}\n.auto-mode {\n  width: 100%;\n  text-align: center;\n  font-size: 20px;\n  font-weight: 500;\n}\n.fa-thermometer-quarter {\n  font-size: 30px;\n}\n"]}]);
// Exports
module.exports = exports;


/***/ }),
/* 13 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/mini.css/src/flavors/mini-default.scss
var mini_default = __webpack_require__(4);

// EXTERNAL MODULE: ./src/node/flaticon.lineal.font.js
var flaticon_lineal_font = __webpack_require__(6);

// EXTERNAL MODULE: ./src/node/debug.css
var debug = __webpack_require__(7);

// EXTERNAL MODULE: ./src/node/holds.css
var holds = __webpack_require__(9);

// EXTERNAL MODULE: ./src/node/climate.less
var climate = __webpack_require__(11);

// CONCATENATED MODULE: ./src/node/favicon.ico
/* harmony default export */ var favicon = (__webpack_require__.p + "favicon.ico");
// CONCATENATED MODULE: ./node_modules/reconnecting-websocket/dist/reconnecting-websocket-mjs.js
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

function __values(o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
    if (m) return m.call(o);
    return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

var Event = /** @class */ (function () {
    function Event(type, target) {
        this.target = target;
        this.type = type;
    }
    return Event;
}());
var ErrorEvent = /** @class */ (function (_super) {
    __extends(ErrorEvent, _super);
    function ErrorEvent(error, target) {
        var _this = _super.call(this, 'error', target) || this;
        _this.message = error.message;
        _this.error = error;
        return _this;
    }
    return ErrorEvent;
}(Event));
var CloseEvent = /** @class */ (function (_super) {
    __extends(CloseEvent, _super);
    function CloseEvent(code, reason, target) {
        if (code === void 0) { code = 1000; }
        if (reason === void 0) { reason = ''; }
        var _this = _super.call(this, 'close', target) || this;
        _this.wasClean = true;
        _this.code = code;
        _this.reason = reason;
        return _this;
    }
    return CloseEvent;
}(Event));

/*!
 * Reconnecting WebSocket
 * by Pedro Ladaria <pedro.ladaria@gmail.com>
 * https://github.com/pladaria/reconnecting-websocket
 * License MIT
 */
var getGlobalWebSocket = function () {
    if (typeof WebSocket !== 'undefined') {
        // @ts-ignore
        return WebSocket;
    }
};
/**
 * Returns true if given argument looks like a WebSocket class
 */
var isWebSocket = function (w) { return typeof w !== 'undefined' && !!w && w.CLOSING === 2; };
var DEFAULT = {
    maxReconnectionDelay: 10000,
    minReconnectionDelay: 1000 + Math.random() * 4000,
    minUptime: 5000,
    reconnectionDelayGrowFactor: 1.3,
    connectionTimeout: 4000,
    maxRetries: Infinity,
    maxEnqueuedMessages: Infinity,
    startClosed: false,
    debug: false,
};
var ReconnectingWebSocket = /** @class */ (function () {
    function ReconnectingWebSocket(url, protocols, options) {
        var _this = this;
        if (options === void 0) { options = {}; }
        this._listeners = {
            error: [],
            message: [],
            open: [],
            close: [],
        };
        this._retryCount = -1;
        this._shouldReconnect = true;
        this._connectLock = false;
        this._binaryType = 'blob';
        this._closeCalled = false;
        this._messageQueue = [];
        /**
         * An event listener to be called when the WebSocket connection's readyState changes to CLOSED
         */
        this.onclose = null;
        /**
         * An event listener to be called when an error occurs
         */
        this.onerror = null;
        /**
         * An event listener to be called when a message is received from the server
         */
        this.onmessage = null;
        /**
         * An event listener to be called when the WebSocket connection's readyState changes to OPEN;
         * this indicates that the connection is ready to send and receive data
         */
        this.onopen = null;
        this._handleOpen = function (event) {
            _this._debug('open event');
            var _a = _this._options.minUptime, minUptime = _a === void 0 ? DEFAULT.minUptime : _a;
            clearTimeout(_this._connectTimeout);
            _this._uptimeTimeout = setTimeout(function () { return _this._acceptOpen(); }, minUptime);
            _this._ws.binaryType = _this._binaryType;
            // send enqueued messages (messages sent before websocket open event)
            _this._messageQueue.forEach(function (message) { return _this._ws.send(message); });
            _this._messageQueue = [];
            if (_this.onopen) {
                _this.onopen(event);
            }
            _this._listeners.open.forEach(function (listener) { return _this._callEventListener(event, listener); });
        };
        this._handleMessage = function (event) {
            _this._debug('message event');
            if (_this.onmessage) {
                _this.onmessage(event);
            }
            _this._listeners.message.forEach(function (listener) { return _this._callEventListener(event, listener); });
        };
        this._handleError = function (event) {
            _this._debug('error event', event.message);
            _this._disconnect(undefined, event.message === 'TIMEOUT' ? 'timeout' : undefined);
            if (_this.onerror) {
                _this.onerror(event);
            }
            _this._debug('exec error listeners');
            _this._listeners.error.forEach(function (listener) { return _this._callEventListener(event, listener); });
            _this._connect();
        };
        this._handleClose = function (event) {
            _this._debug('close event');
            _this._clearTimeouts();
            if (_this._shouldReconnect) {
                _this._connect();
            }
            if (_this.onclose) {
                _this.onclose(event);
            }
            _this._listeners.close.forEach(function (listener) { return _this._callEventListener(event, listener); });
        };
        this._url = url;
        this._protocols = protocols;
        this._options = options;
        if (this._options.startClosed) {
            this._shouldReconnect = false;
        }
        this._connect();
    }
    Object.defineProperty(ReconnectingWebSocket, "CONNECTING", {
        get: function () {
            return 0;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket, "OPEN", {
        get: function () {
            return 1;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket, "CLOSING", {
        get: function () {
            return 2;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket, "CLOSED", {
        get: function () {
            return 3;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "CONNECTING", {
        get: function () {
            return ReconnectingWebSocket.CONNECTING;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "OPEN", {
        get: function () {
            return ReconnectingWebSocket.OPEN;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "CLOSING", {
        get: function () {
            return ReconnectingWebSocket.CLOSING;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "CLOSED", {
        get: function () {
            return ReconnectingWebSocket.CLOSED;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "binaryType", {
        get: function () {
            return this._ws ? this._ws.binaryType : this._binaryType;
        },
        set: function (value) {
            this._binaryType = value;
            if (this._ws) {
                this._ws.binaryType = value;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "retryCount", {
        /**
         * Returns the number or connection retries
         */
        get: function () {
            return Math.max(this._retryCount, 0);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "bufferedAmount", {
        /**
         * The number of bytes of data that have been queued using calls to send() but not yet
         * transmitted to the network. This value resets to zero once all queued data has been sent.
         * This value does not reset to zero when the connection is closed; if you keep calling send(),
         * this will continue to climb. Read only
         */
        get: function () {
            var bytes = this._messageQueue.reduce(function (acc, message) {
                if (typeof message === 'string') {
                    acc += message.length; // not byte size
                }
                else if (message instanceof Blob) {
                    acc += message.size;
                }
                else {
                    acc += message.byteLength;
                }
                return acc;
            }, 0);
            return bytes + (this._ws ? this._ws.bufferedAmount : 0);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "extensions", {
        /**
         * The extensions selected by the server. This is currently only the empty string or a list of
         * extensions as negotiated by the connection
         */
        get: function () {
            return this._ws ? this._ws.extensions : '';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "protocol", {
        /**
         * A string indicating the name of the sub-protocol the server selected;
         * this will be one of the strings specified in the protocols parameter when creating the
         * WebSocket object
         */
        get: function () {
            return this._ws ? this._ws.protocol : '';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "readyState", {
        /**
         * The current state of the connection; this is one of the Ready state constants
         */
        get: function () {
            if (this._ws) {
                return this._ws.readyState;
            }
            return this._options.startClosed
                ? ReconnectingWebSocket.CLOSED
                : ReconnectingWebSocket.CONNECTING;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket.prototype, "url", {
        /**
         * The URL as resolved by the constructor
         */
        get: function () {
            return this._ws ? this._ws.url : '';
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Closes the WebSocket connection or connection attempt, if any. If the connection is already
     * CLOSED, this method does nothing
     */
    ReconnectingWebSocket.prototype.close = function (code, reason) {
        if (code === void 0) { code = 1000; }
        this._closeCalled = true;
        this._shouldReconnect = false;
        this._clearTimeouts();
        if (!this._ws) {
            this._debug('close enqueued: no ws instance');
            return;
        }
        if (this._ws.readyState === this.CLOSED) {
            this._debug('close: already closed');
            return;
        }
        this._ws.close(code, reason);
    };
    /**
     * Closes the WebSocket connection or connection attempt and connects again.
     * Resets retry counter;
     */
    ReconnectingWebSocket.prototype.reconnect = function (code, reason) {
        this._shouldReconnect = true;
        this._closeCalled = false;
        this._retryCount = -1;
        if (!this._ws || this._ws.readyState === this.CLOSED) {
            this._connect();
        }
        else {
            this._disconnect(code, reason);
            this._connect();
        }
    };
    /**
     * Enqueue specified data to be transmitted to the server over the WebSocket connection
     */
    ReconnectingWebSocket.prototype.send = function (data) {
        if (this._ws && this._ws.readyState === this.OPEN) {
            this._debug('send', data);
            this._ws.send(data);
        }
        else {
            var _a = this._options.maxEnqueuedMessages, maxEnqueuedMessages = _a === void 0 ? DEFAULT.maxEnqueuedMessages : _a;
            if (this._messageQueue.length < maxEnqueuedMessages) {
                this._debug('enqueue', data);
                this._messageQueue.push(data);
            }
        }
    };
    /**
     * Register an event handler of a specific event type
     */
    ReconnectingWebSocket.prototype.addEventListener = function (type, listener) {
        if (this._listeners[type]) {
            // @ts-ignore
            this._listeners[type].push(listener);
        }
    };
    ReconnectingWebSocket.prototype.dispatchEvent = function (event) {
        var e_1, _a;
        var listeners = this._listeners[event.type];
        if (listeners) {
            try {
                for (var listeners_1 = __values(listeners), listeners_1_1 = listeners_1.next(); !listeners_1_1.done; listeners_1_1 = listeners_1.next()) {
                    var listener = listeners_1_1.value;
                    this._callEventListener(event, listener);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (listeners_1_1 && !listeners_1_1.done && (_a = listeners_1.return)) _a.call(listeners_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
        return true;
    };
    /**
     * Removes an event listener
     */
    ReconnectingWebSocket.prototype.removeEventListener = function (type, listener) {
        if (this._listeners[type]) {
            // @ts-ignore
            this._listeners[type] = this._listeners[type].filter(function (l) { return l !== listener; });
        }
    };
    ReconnectingWebSocket.prototype._debug = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        if (this._options.debug) {
            // not using spread because compiled version uses Symbols
            // tslint:disable-next-line
            console.log.apply(console, __spread(['RWS>'], args));
        }
    };
    ReconnectingWebSocket.prototype._getNextDelay = function () {
        var _a = this._options, _b = _a.reconnectionDelayGrowFactor, reconnectionDelayGrowFactor = _b === void 0 ? DEFAULT.reconnectionDelayGrowFactor : _b, _c = _a.minReconnectionDelay, minReconnectionDelay = _c === void 0 ? DEFAULT.minReconnectionDelay : _c, _d = _a.maxReconnectionDelay, maxReconnectionDelay = _d === void 0 ? DEFAULT.maxReconnectionDelay : _d;
        var delay = 0;
        if (this._retryCount > 0) {
            delay =
                minReconnectionDelay * Math.pow(reconnectionDelayGrowFactor, this._retryCount - 1);
            if (delay > maxReconnectionDelay) {
                delay = maxReconnectionDelay;
            }
        }
        this._debug('next delay', delay);
        return delay;
    };
    ReconnectingWebSocket.prototype._wait = function () {
        var _this = this;
        return new Promise(function (resolve) {
            setTimeout(resolve, _this._getNextDelay());
        });
    };
    ReconnectingWebSocket.prototype._getNextUrl = function (urlProvider) {
        if (typeof urlProvider === 'string') {
            return Promise.resolve(urlProvider);
        }
        if (typeof urlProvider === 'function') {
            var url = urlProvider();
            if (typeof url === 'string') {
                return Promise.resolve(url);
            }
            if (!!url.then) {
                return url;
            }
        }
        throw Error('Invalid URL');
    };
    ReconnectingWebSocket.prototype._connect = function () {
        var _this = this;
        if (this._connectLock || !this._shouldReconnect) {
            return;
        }
        this._connectLock = true;
        var _a = this._options, _b = _a.maxRetries, maxRetries = _b === void 0 ? DEFAULT.maxRetries : _b, _c = _a.connectionTimeout, connectionTimeout = _c === void 0 ? DEFAULT.connectionTimeout : _c, _d = _a.WebSocket, WebSocket = _d === void 0 ? getGlobalWebSocket() : _d;
        if (this._retryCount >= maxRetries) {
            this._debug('max retries reached', this._retryCount, '>=', maxRetries);
            return;
        }
        this._retryCount++;
        this._debug('connect', this._retryCount);
        this._removeListeners();
        if (!isWebSocket(WebSocket)) {
            throw Error('No valid WebSocket class provided');
        }
        this._wait()
            .then(function () { return _this._getNextUrl(_this._url); })
            .then(function (url) {
            // close could be called before creating the ws
            if (_this._closeCalled) {
                return;
            }
            _this._debug('connect', { url: url, protocols: _this._protocols });
            _this._ws = _this._protocols
                ? new WebSocket(url, _this._protocols)
                : new WebSocket(url);
            _this._ws.binaryType = _this._binaryType;
            _this._connectLock = false;
            _this._addListeners();
            _this._connectTimeout = setTimeout(function () { return _this._handleTimeout(); }, connectionTimeout);
        });
    };
    ReconnectingWebSocket.prototype._handleTimeout = function () {
        this._debug('timeout event');
        this._handleError(new ErrorEvent(Error('TIMEOUT'), this));
    };
    ReconnectingWebSocket.prototype._disconnect = function (code, reason) {
        if (code === void 0) { code = 1000; }
        this._clearTimeouts();
        if (!this._ws) {
            return;
        }
        this._removeListeners();
        try {
            this._ws.close(code, reason);
            this._handleClose(new CloseEvent(code, reason, this));
        }
        catch (error) {
            // ignore
        }
    };
    ReconnectingWebSocket.prototype._acceptOpen = function () {
        this._debug('accept open');
        this._retryCount = 0;
    };
    ReconnectingWebSocket.prototype._callEventListener = function (event, listener) {
        if ('handleEvent' in listener) {
            // @ts-ignore
            listener.handleEvent(event);
        }
        else {
            // @ts-ignore
            listener(event);
        }
    };
    ReconnectingWebSocket.prototype._removeListeners = function () {
        if (!this._ws) {
            return;
        }
        this._debug('removeListeners');
        this._ws.removeEventListener('open', this._handleOpen);
        this._ws.removeEventListener('close', this._handleClose);
        this._ws.removeEventListener('message', this._handleMessage);
        // @ts-ignore
        this._ws.removeEventListener('error', this._handleError);
    };
    ReconnectingWebSocket.prototype._addListeners = function () {
        if (!this._ws) {
            return;
        }
        this._debug('addListeners');
        this._ws.addEventListener('open', this._handleOpen);
        this._ws.addEventListener('close', this._handleClose);
        this._ws.addEventListener('message', this._handleMessage);
        // @ts-ignore
        this._ws.addEventListener('error', this._handleError);
    };
    ReconnectingWebSocket.prototype._clearTimeouts = function () {
        clearTimeout(this._connectTimeout);
        clearTimeout(this._uptimeTimeout);
    };
    return ReconnectingWebSocket;
}());

/* harmony default export */ var reconnecting_websocket_mjs = (ReconnectingWebSocket);

// EXTERNAL MODULE: ./node_modules/cash-dom/dist/cash.js
var cash = __webpack_require__(0);
var cash_default = /*#__PURE__*/__webpack_require__.n(cash);

// EXTERNAL MODULE: ./node_modules/populate.js/populate.js
var populate = __webpack_require__(3);
var populate_default = /*#__PURE__*/__webpack_require__.n(populate);

// CONCATENATED MODULE: ./src/node/index.js

//import "mini.css/src/flavors/mini-dark.scss"
//import "mini.css/src/flavors/mini-nord.scss"










const CPROG = ['eco', 'normal', 'confort'];
const DAY_NAMES = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

let displayTimeout;

function reload() {
    fetch("load")
        .then(response => response.json())
        .then(jdata => {
            populate_default()(cash_default()("#configForm")[0], jdata);
            cash_default()("#saveButtons").show();
        })
        .catch(err => console.error(err));
}
window.reload = reload;

function reloadWifi() {
    fetch("loadW")
        .then(response => response.json())
        .then(jdata => {
            populate_default()(cash_default()("#wifiConfigForm")[0], jdata);
            cash_default()("#connectButtons").show();
        })
        .catch(err => console.error(err));
}

function scanWifi() {
    cash_default()("#wifiScanButton").hide();
    cash_default()("#wifiScanResult").hide();
    cash_default()("#wifiScanTable").html("");
    cash_default()("#wifiScanSpinner").show();
    fetch("scanW")
        //  .then(response => response.json())  
        //  .then(jdata => {
        //    console.log(jdata);
        //  })
        .catch(err => console.error(err));
}

window.scanWifi = scanWifi;

function validateWifi() {
    //  console.log("Validate! ",$("#ssid").val() !== "" ,$("#wkey").val() !== "");
    if (cash_default()("#ssid").val() !== "" && cash_default()("#wkey").val() !== "") {
        cash_default()("#wifiConnectButton").removeAttr("disabled");
    } else {
        cash_default()("#wifiConnectButton").attr("disabled", "disabled");
    }
}
window.validateWifi = validateWifi;

async function saveConfig() {
    console.log(cash_default()("#configForm")[0]);
    const data = new URLSearchParams(new FormData(cash_default()("#configForm")[0]));
    console.log(data);
    await fetch("save", {
        method: 'POST',
        body: data
    });
    reload();
}

function save() {
    const currentPanel = cash_default()("#saveButtons").attr("data");
    console.log("Save on panel: ", currentPanel);
    if (currentPanel == "home") {
        // No save action
    } else if (currentPanel == "config") {
        saveConfig();
    }
}
window.save = save;

function change(day, hq) {
    cash_default()("#C" + day + "_" + hq).removeClass("unsaved");
    let cls = cash_default()("#C" + day + "_" + hq).attr("class");
    let p = CPROG.indexOf(cls);
    console.log("Letto", cls, p, CPROG);
    p = (p + 1) % 3;
    console.log(p, CPROG[p]);
    cash_default()("#C" + day + "_" + hq).attr("class", CPROG[p] + " unsaved");
}

window.change = change;

function show(currentPanel) {
    cash_default()(".panel").hide();
    cash_default()('header a').removeClass('bordered');
    cash_default()("#saveButtons").hide();
    cash_default()("#saveButtons").attr("data", currentPanel);
    cash_default()("#connectButtons").hide();
    cash_default()("footer").show();
    cash_default()("#" + currentPanel + "Tab").toggleClass("bordered");
    cash_default()("#" + currentPanel).show();
    if (currentPanel == "home") {
        refreshDisplayFromMap();
    } else if (currentPanel == "config") {
        clearTimeout(displayTimeout);
        reload();
    } else if (currentPanel == "wificonfig") {
        clearTimeout(displayTimeout);
        reloadWifi();
    } else if (currentPanel == "debug") {
        clearTimeout(displayTimeout);
        cash_default()("footer").hide();
        cash_default()("#debug-view")[0].scrollTop = cash_default()("#debug-view")[0].scrollHeight;
    }
}
window.show = show;

/*
async function wps() {
    console.log("WPS!");
    await fetch("wps");
    location.reload(true);
}
window.wps = wps;
*/

async function connect() {
    console.log(cash_default()("#wifiConfigForm")[0]);
    const data = new URLSearchParams(new FormData(cash_default()("#wifiConfigForm")[0]));
    console.log(data);
    await fetch("saveW", {
        method: 'POST',
        body: data
    });
    location.reload(true);
}
window.connect = connect;

function refreshDisplayFromMap() {
    var oReq = new XMLHttpRequest();
    oReq.open("GET", "screenpbm", true);
    oReq.responseType = "arraybuffer";

    oReq.onload = function(oEvent) {
        var BreakException = {};
        var arrayBuffer = oReq.response; // Note: not oReq.responseText
        if (arrayBuffer) {
            var byteArray = new Uint8Array(arrayBuffer);
            if (byteArray[0] != 0x50 || byteArray[1] != 0x34) {
                console.error("Only BPM P4 (Binary) are supported!")
                throw BreakException;
            }
            let x_size = 0,
                y_size = 0;
            let ascii_text = "";
            for (var i = 3; i < byteArray.byteLength; i++) {
                if (x_size == 0 && byteArray[i] == 0x0A) {
                    x_size = parseInt(ascii_text);
                    ascii_text = "";
                } else if (y_size == 0 && byteArray[i] == 0x20) {
                    y_size = parseInt(ascii_text);
                } else if (x_size == 0 || y_size == 0) {
                    ascii_text = ascii_text + String.fromCharCode(byteArray[i]);
                } else {
                    byteArray = byteArray.subarray(i);
                    break;
                }
            }
            //console.log("BPM Size " + x_size + "x" + y_size);

            let ctx = cash_default()("#screen")[0].getContext('2d');
            ctx.fillStyle = 'rgb(0, 0, 0)';
            let pos = 0;
            for (let y = 0; y < y_size; y++) {
                for (let x = 0; x < x_size; x += 8) {
                    for (var i = 7; i >= 0; i--) {
                        var bit = (byteArray[pos] & (1 << i)) > 0 ? 1 : 0;
                        if (bit == 1) ctx.fillStyle = 'rgb(0, 0, 0)';
                        else ctx.fillStyle = 'rgb(255, 255, 255)';
                        ctx.fillRect(x + (7 - i), y, 1, 1);
                    }
                    pos++;
                }
            }
            displayTimeout = setTimeout(refreshDisplayFromMap, 500);
        }
    };
    oReq.send(null);
}

function cmd(button) {
    fetch("cmd?cmd=" + cash_default()(button).attr("id").split("-")[0] + "&value=" + cash_default()(button).val())
        .then(result => reloadOstat(false))
        .catch(err => console.error(err));
}

window.cmd = cmd;

function reloadOstat(changePage = false) {
    // StartPage
    fetch("ostat")
        .then(response => response.json())
        .then(data => {
            if (changePage) {
                console.log(data, "First tab", data.otab);
                show(data.otab);
                if (data.bdg) {
                    alert(data.bdg);
                }
            }
            cash_default()("button[id|='mode'],button[id|='hold'],button[id|='away']").removeClass("primary").removeClass("secondary").removeClass("tertiary");
            cash_default()("button[id|='mode'][value='" + data.mode + "']").addClass(cash_default()("button[id|='mode'][value='" + data.mode + "']").data('onclass'));
            //            $("button[id|='hold'][value='" + data.hold + "']").addClass($("button[id|='hold'][value='" + data.hold + "']").data('onclass'));
            //            $("#away-" + (data.away ? "on" : 'off')).addClass("primary");
        })
        .catch(err => console.error(err));
}

function node_debug(message) {
    cash_default()("#debug-view").val(cash_default()("#debug-view").val() + message);
    if (cash_default()("#autoscroll").is(":checked")) {
        cash_default()("#debug-view")[0].scrollTop = cash_default()("#debug-view")[0].scrollHeight;
    }
}


cash_default()().ready(function() {

    reloadOstat(true);

    // WebSockets
    var debug_service = new reconnecting_websocket_mjs('ws://' + window.location.host + '/log');
    debug_service.onmessage = function(event) {
        //        console.log("Messaggio", event);
        node_debug(event.data);
    }
    debug_service.onopen = function(event) {
        //        console.log(event);
        node_debug('Connected\n');
        debug_service.send("CSL");
    }
    debug_service.onclose = function() {
        node_debug('Disconnected\n');
    }
    debug_service.onerror = function() {
        node_debug('Error!\n');
    }
    cash_default()("#debug-view").on("scroll", (elem) => {
        //    console.log(elem);
        //    console.log($("#debug-view")[0].scrollTop + $("#debug-view").height(), $("#debug-view")[0].scrollHeight)
        if (cash_default()("#debug-view")[0].scrollTop + cash_default()("#debug-view").height() <= cash_default()("#debug-view")[0].scrollHeight - 4) {
            cash_default()("#autoscroll")[0].checked = false;
        }
    });


    var scan_service = new reconnecting_websocket_mjs('ws://' + window.location.host + '/scan');
    scan_service.onmessage = function(event) {
        let item = JSON.parse(event.data);
        console.log("Got Scan Result", event.data);
        cash_default()("#wifiScanSpinner").hide();
        if (item.end) {
            cash_default()("#wifiScanButton").show();
            validateWifi();
        } else {
            // Search networks
            //      console.log($("#wifiScanTable tr td[data-ssid='"+item.ssid+"'][data-label='SSID']"));
            if (cash_default()("#wifiScanTable tr td[data-ssid='" + item.ssid + "'][data-label='SSID']").length != 0) {
                console.log("Duplicate Network", item);
                let str = cash_default()("#wifiScanTable tr td[data-ssid='" + item.ssid + "'][data-label='Strength']");
                str.text(str.text() + "/" + item.dBm + "dBm");
            } else {
                let html = "<tr id=\"netw" + item.i + "\">";
                html += "<td data-label=\"SSID\" data-ssid=\"" + item.ssid + "\">" + item.ssid + "</td>";
                html += "<td data-Label=\"Strength\" data-ssid=\"" + item.ssid + "\">" + item.dBm + "dBm</td>";
                html += "<td data-label=\"Type\" data-ssid=\"" + item.ssid + "\">" + (item.open ? "" : "<span class=\"icon-lock\"></span>") + "</td>";
                html += "</tr>";
                cash_default()("#wifiScanTable").append(html);
                cash_default()("#netw" + item.i).on('click', event => {
                    console.log(item.ssid);
                    cash_default()("#ssid").val(item.ssid)[0].scrollIntoView();
                    cash_default()("#wkey")[0].focus();
                });
                cash_default()("#wifiScanResult").show();
            }
        }
    }
    scan_service.onopen = function(event) {
        console.log("Connect WS /scan", event);
        scan_service.send("CSL2");
    }
    scan_service.onclose = function() {
        console.log("Disconect WS /scan");
    }
    scan_service.onerror = function() {
        console.log("Error WS /scan");
    }

});

/***/ })
/******/ ]);